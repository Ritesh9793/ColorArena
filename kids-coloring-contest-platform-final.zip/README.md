# 🎨 ColorArena - Interactive Coloring Platform for Kids & Teens

A gamified coloring platform inspired by LeetCode, where children and teenagers can practice coloring, participate in contests, and compete on leaderboards.

![ColorArena Banner](https://via.placeholder.com/1200x400/22c55e/ffffff?text=ColorArena+-+Where+Creativity+Meets+Competition)

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Database Schema](#database-schema)
- [API Documentation](#api-documentation)
- [Authentication Flow](#authentication-flow)
- [Backend Setup](#backend-setup)
- [Frontend Setup](#frontend-setup)
- [Deployment](#deployment)
- [Environment Variables](#environment-variables)
- [COPPA Compliance](#coppa-compliance)

---

## 🎯 Overview

ColorArena is a web-based platform designed for children (ages 6-17) to:
- Practice coloring with curated outline artworks
- Participate in timed coloring contests
- Track daily streaks and earn achievements
- Compete on country-wise and global leaderboards
- Subscribe to premium content

### User Types
1. **Regular Users** - Children/Teens who color and compete
2. **Admin Users** - Platform managers who create content and moderate

---

## ✨ Features

### For Users
- 🖌️ **Practice Mode** - Color at your own pace
- 🏆 **Contests** - Timed competitions with prizes
- 🔥 **Streak Tracking** - Daily activity rewards
- 📊 **Leaderboards** - Country-wise and global rankings
- 👤 **Profile** - Avatar upload, achievements, statistics
- 💎 **Subscriptions** - Free trial and premium plans

### For Admins
- 📝 **Contest Management** - Create, edit, schedule contests
- 🎨 **Activity Management** - Add practice artworks (free/premium)
- 👥 **User Management** - View and manage users
- 📈 **Analytics Dashboard** - Platform statistics
- 🔧 **Platform Settings** - Configure site settings

---

## 🛠️ Tech Stack

### Frontend
| Technology | Purpose |
|------------|---------|
| React 18 | UI Framework |
| TypeScript | Type Safety |
| Vite | Build Tool |
| Tailwind CSS | Styling |
| Framer Motion | Animations |
| Fabric.js | Canvas Coloring |
| Radix UI | Accessible Components |

### Backend
| Technology | Purpose |
|------------|---------|
| Next.js API Routes | REST API |
| Supabase | Database & Auth |
| Redis | Caching & Sessions |
| Socket.io | Real-time Features |

### Services
| Service | Purpose |
|---------|---------|
| Cloudinary | Image Storage |
| Auth0 | Authentication |
| SendGrid | Transactional Emails |
| Stripe | Payment Processing |

### Deployment
| Platform | Purpose |
|----------|---------|
| Vercel | Frontend & API Hosting |
| Supabase Cloud | Database Hosting |
| Upstash | Redis Hosting |

---

## 📁 Project Structure

### Frontend Structure

```
colorarena/
├── public/
│   ├── favicon.ico
│   ├── logo.svg
│   └── assets/
│       ├── outlines/          # Coloring outline images
│       └── backgrounds/       # UI background images
│
├── src/
│   ├── components/
│   │   ├── ui/                # Reusable UI components
│   │   │   ├── button.tsx
│   │   │   ├── card.tsx
│   │   │   ├── badge.tsx
│   │   │   ├── progress.tsx
│   │   │   ├── avatar.tsx
│   │   │   ├── tooltip.tsx
│   │   │   ├── Calendar.tsx
│   │   │   ├── Select.tsx
│   │   │   └── DatePicker.tsx
│   │   │
│   │   ├── AnimatedComponents.tsx  # Animation wrappers
│   │   ├── Header.tsx              # Navigation header
│   │   ├── Footer.tsx              # Site footer
│   │   ├── AuthModal.tsx           # Login/Signup modal
│   │   └── NotificationDropdown.tsx # Notification system
│   │
│   ├── pages/
│   │   ├── HomePage.tsx        # Landing page
│   │   ├── PracticePage.tsx    # Practice activities list
│   │   ├── GalleryPage.tsx     # User artwork gallery
│   │   ├── ContestPage.tsx     # Contests listing
│   │   ├── ColoringPage.tsx    # Canvas coloring interface
│   │   ├── LeaderboardPage.tsx # Rankings page
│   │   ├── ProfilePage.tsx     # User profile
│   │   ├── SettingsPage.tsx    # User/Admin settings
│   │   ├── AdminPage.tsx       # Admin dashboard
│   │   └── SubscriptionPage.tsx # Subscription plans
│   │
│   ├── hooks/
│   │   ├── useAuth.ts          # Authentication hook
│   │   ├── useCanvas.ts        # Fabric.js canvas hook
│   │   ├── useStreak.ts        # Streak tracking hook
│   │   └── useNotifications.ts # Notifications hook
│   │
│   ├── services/
│   │   ├── api.ts              # API client
│   │   ├── supabase.ts         # Supabase client
│   │   ├── cloudinary.ts       # Image upload service
│   │   └── socket.ts           # Socket.io client
│   │
│   ├── utils/
│   │   ├── helpers.ts          # Utility functions
│   │   ├── constants.ts        # App constants
│   │   └── validators.ts       # Form validators
│   │
│   ├── types/
│   │   └── index.ts            # TypeScript types
│   │
│   ├── App.tsx                 # Root component
│   ├── main.tsx                # Entry point
│   └── index.css               # Global styles
│
├── index.html
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── vite.config.ts
└── README.md
```

### Backend Structure (Next.js API)

```
backend/
├── app/
│   └── api/
│       ├── auth/
│       │   ├── login/route.ts
│       │   ├── register/route.ts
│       │   ├── logout/route.ts
│       │   ├── verify-email/route.ts
│       │   └── parental-consent/route.ts
│       │
│       ├── users/
│       │   ├── route.ts                 # GET all, POST create
│       │   ├── [id]/route.ts            # GET, PUT, DELETE user
│       │   ├── [id]/avatar/route.ts     # Upload avatar
│       │   ├── [id]/streak/route.ts     # Get/Update streak
│       │   └── [id]/subscription/route.ts
│       │
│       ├── activities/
│       │   ├── route.ts                 # GET all, POST create
│       │   ├── [id]/route.ts            # GET, PUT, DELETE
│       │   └── categories/route.ts      # GET categories
│       │
│       ├── contests/
│       │   ├── route.ts                 # GET all, POST create
│       │   ├── [id]/route.ts            # GET, PUT, DELETE
│       │   ├── [id]/join/route.ts       # Join contest
│       │   ├── [id]/submit/route.ts     # Submit entry
│       │   └── [id]/leaderboard/route.ts
│       │
│       ├── submissions/
│       │   ├── route.ts                 # GET all submissions
│       │   ├── [id]/route.ts            # GET submission
│       │   └── [id]/rate/route.ts       # Rate submission
│       │
│       ├── leaderboard/
│       │   ├── route.ts                 # GET global leaderboard
│       │   ├── country/[code]/route.ts  # Country leaderboard
│       │   └── contest/[id]/route.ts    # Contest leaderboard
│       │
│       ├── notifications/
│       │   ├── route.ts                 # GET user notifications
│       │   ├── [id]/read/route.ts       # Mark as read
│       │   └── clear/route.ts           # Clear all
│       │
│       ├── subscriptions/
│       │   ├── route.ts                 # GET plans
│       │   ├── subscribe/route.ts       # Create subscription
│       │   ├── cancel/route.ts          # Cancel subscription
│       │   └── webhook/route.ts         # Stripe webhook
│       │
│       ├── admin/
│       │   ├── stats/route.ts           # Dashboard stats
│       │   ├── users/route.ts           # Manage users
│       │   ├── moderation/route.ts      # Content moderation
│       │   └── settings/route.ts        # Platform settings
│       │
│       └── upload/
│           └── route.ts                 # Cloudinary upload
│
├── lib/
│   ├── supabase.ts              # Supabase client
│   ├── redis.ts                 # Redis client
│   ├── stripe.ts                # Stripe client
│   ├── sendgrid.ts              # SendGrid client
│   ├── cloudinary.ts            # Cloudinary client
│   └── socket.ts                # Socket.io server
│
├── middleware/
│   ├── auth.ts                  # Auth middleware
│   ├── admin.ts                 # Admin check middleware
│   ├── rateLimit.ts             # Rate limiting
│   └── validation.ts            # Request validation
│
├── utils/
│   ├── helpers.ts
│   ├── constants.ts
│   └── errors.ts
│
└── types/
    └── index.ts
```

---

## 🗄️ Database Schema

### Supabase PostgreSQL Schema

#### 1. Users Table
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    avatar_url TEXT,
    
    -- Demographics
    birth_date DATE NOT NULL,
    age_group VARCHAR(10) CHECK (age_group IN ('6-8', '9-12', '13-17')),
    country_code VARCHAR(3) NOT NULL,
    country_name VARCHAR(100) NOT NULL,
    
    -- Role & Status
    role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('user', 'admin', 'moderator')),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'deleted')),
    is_verified BOOLEAN DEFAULT FALSE,
    
    -- Parental Consent (for under 13)
    requires_parental_consent BOOLEAN DEFAULT FALSE,
    parental_consent_given BOOLEAN DEFAULT FALSE,
    parent_email VARCHAR(255),
    parent_name VARCHAR(100),
    consent_given_at TIMESTAMP WITH TIME ZONE,
    
    -- Gamification
    xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login_at TIMESTAMP WITH TIME ZONE,
    
    -- Indexes
    INDEX idx_users_email (email),
    INDEX idx_users_country (country_code),
    INDEX idx_users_age_group (age_group),
    INDEX idx_users_xp (xp DESC)
);

-- Trigger to auto-calculate age_group
CREATE OR REPLACE FUNCTION calculate_age_group()
RETURNS TRIGGER AS $$
DECLARE
    user_age INTEGER;
BEGIN
    user_age := DATE_PART('year', AGE(NEW.birth_date));
    IF user_age >= 6 AND user_age <= 8 THEN
        NEW.age_group := '6-8';
    ELSIF user_age >= 9 AND user_age <= 12 THEN
        NEW.age_group := '9-12';
    ELSIF user_age >= 13 AND user_age <= 17 THEN
        NEW.age_group := '13-17';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_age_group
    BEFORE INSERT OR UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION calculate_age_group();
```

#### 2. Admin Users Table (Extended)
```sql
CREATE TABLE admin_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    -- Admin Permissions
    can_manage_users BOOLEAN DEFAULT TRUE,
    can_manage_contests BOOLEAN DEFAULT TRUE,
    can_manage_activities BOOLEAN DEFAULT TRUE,
    can_manage_subscriptions BOOLEAN DEFAULT TRUE,
    can_view_analytics BOOLEAN DEFAULT TRUE,
    can_moderate_content BOOLEAN DEFAULT TRUE,
    can_manage_settings BOOLEAN DEFAULT TRUE,
    
    -- Admin Info
    admin_code VARCHAR(50) NOT NULL,
    department VARCHAR(100),
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);
```

#### 3. Streaks Table
```sql
CREATE TABLE user_streaks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    total_active_days INTEGER DEFAULT 0,
    
    last_activity_date DATE,
    streak_start_date DATE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);

-- Daily activity log for streak calculation
CREATE TABLE daily_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    activity_date DATE NOT NULL,
    activity_count INTEGER DEFAULT 1,
    xp_earned INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id, activity_date),
    INDEX idx_daily_activities_user_date (user_id, activity_date DESC)
);
```

#### 4. Practice Activities Table
```sql
CREATE TABLE practice_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Basic Info
    title VARCHAR(200) NOT NULL,
    description TEXT,
    image_url TEXT NOT NULL,
    thumbnail_url TEXT,
    
    -- Categorization
    category VARCHAR(50) NOT NULL CHECK (category IN (
        'animals', 'nature', 'fantasy', 'vehicles', 
        'food', 'space', 'ocean', 'sports', 'characters'
    )),
    difficulty VARCHAR(20) NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
    age_group VARCHAR(10) NOT NULL CHECK (age_group IN ('6-8', '9-12', '13-17', 'all')),
    
    -- Metadata
    estimated_time INTEGER NOT NULL, -- in minutes
    color_count INTEGER DEFAULT 10,
    xp_reward INTEGER DEFAULT 10,
    
    -- Access Control
    is_premium BOOLEAN DEFAULT FALSE,
    
    -- Status
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    
    -- Stats
    play_count INTEGER DEFAULT 0,
    completion_count INTEGER DEFAULT 0,
    average_rating DECIMAL(3,2) DEFAULT 0,
    
    -- Admin
    created_by UUID REFERENCES users(id),
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    published_at TIMESTAMP WITH TIME ZONE,
    
    INDEX idx_activities_category (category),
    INDEX idx_activities_difficulty (difficulty),
    INDEX idx_activities_premium (is_premium),
    INDEX idx_activities_status (status)
);
```

#### 5. User Activity Progress Table
```sql
CREATE TABLE user_activity_progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    activity_id UUID REFERENCES practice_activities(id) ON DELETE CASCADE,
    
    -- Progress
    status VARCHAR(20) DEFAULT 'not_started' CHECK (status IN (
        'not_started', 'in_progress', 'completed'
    )),
    progress_percentage INTEGER DEFAULT 0,
    
    -- Saved Work
    canvas_data JSONB, -- Fabric.js canvas state
    
    -- Completion
    completed_at TIMESTAMP WITH TIME ZONE,
    time_spent INTEGER DEFAULT 0, -- in seconds
    xp_earned INTEGER DEFAULT 0,
    
    -- Rating
    user_rating INTEGER CHECK (user_rating >= 1 AND user_rating <= 5),
    
    -- Timestamps
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id, activity_id),
    INDEX idx_progress_user (user_id),
    INDEX idx_progress_status (status)
);
```

#### 6. Contests Table
```sql
CREATE TABLE contests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Basic Info
    title VARCHAR(200) NOT NULL,
    description TEXT,
    banner_image_url TEXT,
    
    -- Schedule
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE NOT NULL,
    time_limit INTEGER NOT NULL, -- in minutes per submission
    
    -- Configuration
    age_group VARCHAR(10) NOT NULL CHECK (age_group IN ('6-8', '9-12', '13-17', 'all')),
    difficulty VARCHAR(20) NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
    max_participants INTEGER,
    
    -- Activities for contest
    activity_ids UUID[] NOT NULL, -- Array of activity IDs
    
    -- Prizes
    prizes JSONB DEFAULT '[]', -- [{rank: 1, prize: "Gold Medal", xp: 500}]
    
    -- Status
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN (
        'draft', 'scheduled', 'live', 'ended', 'cancelled'
    )),
    
    -- Stats
    participant_count INTEGER DEFAULT 0,
    submission_count INTEGER DEFAULT 0,
    
    -- Admin
    created_by UUID REFERENCES users(id),
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    INDEX idx_contests_status (status),
    INDEX idx_contests_start (start_time),
    INDEX idx_contests_age_group (age_group)
);
```

#### 7. Contest Participants Table
```sql
CREATE TABLE contest_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contest_id UUID REFERENCES contests(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    -- Registration
    registered_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Submission
    has_submitted BOOLEAN DEFAULT FALSE,
    submission_id UUID,
    
    -- Ranking
    rank INTEGER,
    score DECIMAL(10,2),
    xp_earned INTEGER DEFAULT 0,
    
    UNIQUE(contest_id, user_id),
    INDEX idx_participants_contest (contest_id),
    INDEX idx_participants_rank (contest_id, rank)
);
```

#### 8. Contest Submissions Table
```sql
CREATE TABLE contest_submissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contest_id UUID REFERENCES contests(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    activity_id UUID REFERENCES practice_activities(id),
    
    -- Submission
    image_url TEXT NOT NULL, -- Final colored image
    canvas_data JSONB, -- Fabric.js state
    
    -- Timing
    started_at TIMESTAMP WITH TIME ZONE,
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    time_taken INTEGER, -- in seconds
    
    -- Scoring
    score DECIMAL(10,2),
    judge_scores JSONB DEFAULT '[]', -- [{judge_id, score, feedback}]
    
    -- Status
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN (
        'pending', 'reviewing', 'approved', 'rejected'
    )),
    
    INDEX idx_submissions_contest (contest_id),
    INDEX idx_submissions_user (user_id),
    INDEX idx_submissions_score (contest_id, score DESC)
);
```

#### 9. Subscriptions Table
```sql
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    -- Plan Details
    plan VARCHAR(20) NOT NULL CHECK (plan IN (
        'free', 'monthly', 'quarterly', 'half-yearly', 'annual'
    )),
    
    -- Status
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN (
        'active', 'cancelled', 'expired', 'past_due'
    )),
    
    -- Dates
    start_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    end_date TIMESTAMP WITH TIME ZONE,
    trial_end_date TIMESTAMP WITH TIME ZONE,
    cancelled_at TIMESTAMP WITH TIME ZONE,
    
    -- Payment
    stripe_subscription_id VARCHAR(255),
    stripe_customer_id VARCHAR(255),
    amount DECIMAL(10,2),
    currency VARCHAR(3) DEFAULT 'USD',
    
    -- Auto Renew
    auto_renew BOOLEAN DEFAULT TRUE,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    INDEX idx_subscriptions_user (user_id),
    INDEX idx_subscriptions_status (status),
    INDEX idx_subscriptions_end_date (end_date)
);

-- Subscription Plans Reference
CREATE TABLE subscription_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    name VARCHAR(50) NOT NULL,
    plan_code VARCHAR(20) UNIQUE NOT NULL,
    
    -- Pricing
    price DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    billing_period VARCHAR(20), -- 'month', 'quarter', 'half-year', 'year'
    
    -- Features
    features JSONB DEFAULT '[]',
    
    -- Stripe
    stripe_price_id VARCHAR(255),
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default plans
INSERT INTO subscription_plans (name, plan_code, price, billing_period, features) VALUES
('Free Trial', 'free', 0, NULL, '["14-day access", "Free activities only", "Basic features"]'),
('Monthly', 'monthly', 9.99, 'month', '["Unlimited access", "All premium activities", "Contest entry", "Priority support"]'),
('Quarterly', 'quarterly', 24.99, 'quarter', '["Everything in Monthly", "15% savings", "Exclusive content"]'),
('Half-Yearly', 'half-yearly', 44.99, 'half-year', '["Everything in Quarterly", "25% savings", "Early access"]'),
('Annual', 'annual', 79.99, 'year', '["Everything in Half-Yearly", "35% savings", "VIP badge", "Bonus XP"]');
```

#### 10. Notifications Table
```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    -- Content
    type VARCHAR(50) NOT NULL CHECK (type IN (
        'streak', 'contest', 'achievement', 'activity', 
        'subscription', 'system', 'user', 'moderation'
    )),
    title VARCHAR(200) NOT NULL,
    message TEXT,
    
    -- Action
    action_url TEXT,
    action_label VARCHAR(50),
    
    -- Status
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    
    -- Metadata
    metadata JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    
    INDEX idx_notifications_user (user_id),
    INDEX idx_notifications_read (user_id, is_read),
    INDEX idx_notifications_created (created_at DESC)
);
```

#### 11. Achievements Table
```sql
CREATE TABLE achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Info
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(10), -- Emoji
    
    -- Requirements
    requirement_type VARCHAR(50) NOT NULL, -- 'streak', 'xp', 'contests', 'activities'
    requirement_value INTEGER NOT NULL,
    
    -- Rewards
    xp_reward INTEGER DEFAULT 0,
    badge_color VARCHAR(50),
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User Achievements (Junction)
CREATE TABLE user_achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    achievement_id UUID REFERENCES achievements(id) ON DELETE CASCADE,
    
    earned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id, achievement_id),
    INDEX idx_user_achievements_user (user_id)
);

-- Insert default achievements
INSERT INTO achievements (name, description, icon, requirement_type, requirement_value, xp_reward) VALUES
('First Steps', 'Complete your first activity', '🎨', 'activities', 1, 10),
('Color Master', 'Complete 50 activities', '🏆', 'activities', 50, 100),
('Week Warrior', 'Maintain a 7-day streak', '🔥', 'streak', 7, 50),
('Month Master', 'Maintain a 30-day streak', '⭐', 'streak', 30, 200),
('Contest Champion', 'Win your first contest', '👑', 'contests_won', 1, 150),
('XP Hunter', 'Earn 1000 XP', '💎', 'xp', 1000, 100);
```

#### 12. Leaderboard Views
```sql
-- Global Leaderboard View
CREATE VIEW global_leaderboard AS
SELECT 
    u.id,
    u.name,
    u.avatar_url,
    u.country_code,
    u.country_name,
    u.xp,
    u.level,
    us.current_streak,
    us.longest_streak,
    (SELECT COUNT(*) FROM user_achievements ua WHERE ua.user_id = u.id) as badge_count,
    (SELECT COUNT(*) FROM contest_participants cp WHERE cp.user_id = u.id AND cp.rank = 1) as contest_wins,
    RANK() OVER (ORDER BY u.xp DESC) as global_rank
FROM users u
LEFT JOIN user_streaks us ON u.id = us.user_id
WHERE u.role = 'user' AND u.status = 'active'
ORDER BY u.xp DESC;

-- Country Leaderboard View
CREATE VIEW country_leaderboard AS
SELECT 
    u.id,
    u.name,
    u.avatar_url,
    u.country_code,
    u.country_name,
    u.xp,
    u.level,
    us.current_streak,
    RANK() OVER (PARTITION BY u.country_code ORDER BY u.xp DESC) as country_rank,
    RANK() OVER (ORDER BY u.xp DESC) as global_rank
FROM users u
LEFT JOIN user_streaks us ON u.id = us.user_id
WHERE u.role = 'user' AND u.status = 'active'
ORDER BY u.country_code, u.xp DESC;

-- Weekly Leaderboard (based on XP earned this week)
CREATE VIEW weekly_leaderboard AS
SELECT 
    u.id,
    u.name,
    u.avatar_url,
    u.country_code,
    COALESCE(SUM(da.xp_earned), 0) as weekly_xp,
    RANK() OVER (ORDER BY COALESCE(SUM(da.xp_earned), 0) DESC) as weekly_rank
FROM users u
LEFT JOIN daily_activities da ON u.id = da.user_id 
    AND da.activity_date >= DATE_TRUNC('week', CURRENT_DATE)
WHERE u.role = 'user' AND u.status = 'active'
GROUP BY u.id
ORDER BY weekly_xp DESC;
```

#### 13. Platform Settings Table (Admin)
```sql
CREATE TABLE platform_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    key VARCHAR(100) UNIQUE NOT NULL,
    value JSONB NOT NULL,
    description TEXT,
    
    updated_by UUID REFERENCES users(id),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default settings
INSERT INTO platform_settings (key, value, description) VALUES
('site_name', '"ColorArena"', 'Platform name'),
('maintenance_mode', 'false', 'Enable maintenance mode'),
('registration_enabled', 'true', 'Allow new registrations'),
('default_age_group', '"9-12"', 'Default age group for new users'),
('max_upload_size_mb', '5', 'Maximum upload size in MB'),
('free_trial_days', '14', 'Free trial duration in days'),
('streak_reset_hour', '0', 'Hour (UTC) when streak resets');
```

---

## 🔐 Authentication Flow

### Regular User Registration
```
1. User fills signup form (name, email, password, birth date, country)
2. System calculates age from birth date
3. If age < 13:
   a. Show parental consent form
   b. Collect parent email and name
   c. Send verification code via SendGrid
   d. Parent enters verification code
   e. Store consent in database
4. Create user in Supabase Auth
5. Create user profile in users table
6. Initialize streak record
7. Create 14-day free trial subscription
8. Send welcome email
9. Redirect to home page
```

### Admin Login
```
1. Admin toggles "Admin Login" mode
2. Enter email, password, admin code
3. Verify credentials against Supabase Auth
4. Verify admin_code in admin_profiles table
5. Check admin permissions
6. Create session with admin role
7. Redirect to admin dashboard
```

### Password Reset
```
1. User requests password reset
2. Generate reset token (store in Redis with 1hr expiry)
3. Send reset email via SendGrid
4. User clicks link and enters new password
5. Verify token and update password
6. Invalidate all existing sessions
7. Redirect to login
```

---

## 🔧 Backend Setup

### 1. Supabase Setup

```bash
# Install Supabase CLI
npm install -g supabase

# Login to Supabase
supabase login

# Initialize project
supabase init

# Link to your project
supabase link --project-ref your-project-ref

# Run migrations
supabase db push

# Generate TypeScript types
supabase gen types typescript --local > src/types/supabase.ts
```

### 2. Redis Setup (Upstash)

```typescript
// lib/redis.ts
import { Redis } from '@upstash/redis'

export const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

// Cache user session
export async function cacheUserSession(userId: string, sessionData: object) {
  await redis.set(`session:${userId}`, JSON.stringify(sessionData), {
    ex: 60 * 60 * 24 * 7 // 7 days
  })
}

// Get cached leaderboard
export async function getCachedLeaderboard(type: string) {
  const cached = await redis.get(`leaderboard:${type}`)
  return cached ? JSON.parse(cached as string) : null
}
```

### 3. Cloudinary Setup

```typescript
// lib/cloudinary.ts
import { v2 as cloudinary } from 'cloudinary'

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
})

export async function uploadImage(file: Buffer, folder: string) {
  return new Promise((resolve, reject) => {
    cloudinary.uploader.upload_stream(
      {
        folder: `colorarena/${folder}`,
        resource_type: 'image',
        transformation: [
          { width: 1200, height: 1200, crop: 'limit' },
          { quality: 'auto' },
          { fetch_format: 'auto' }
        ]
      },
      (error, result) => {
        if (error) reject(error)
        else resolve(result)
      }
    ).end(file)
  })
}

export async function uploadAvatar(file: Buffer, userId: string) {
  return uploadImage(file, `avatars/${userId}`)
}

export async function uploadActivityOutline(file: Buffer, activityId: string) {
  return uploadImage(file, `activities/${activityId}`)
}
```

### 4. SendGrid Setup

```typescript
// lib/sendgrid.ts
import sgMail from '@sendgrid/mail'

sgMail.setApiKey(process.env.SENDGRID_API_KEY!)

export async function sendParentalConsentEmail(
  parentEmail: string,
  parentName: string,
  childName: string,
  verificationCode: string
) {
  await sgMail.send({
    to: parentEmail,
    from: 'noreply@colorarena.com',
    subject: 'Parental Consent Required - ColorArena',
    html: `
      <h1>Hello ${parentName},</h1>
      <p>${childName} wants to join ColorArena, a creative coloring platform for kids.</p>
      <p>As ${childName} is under 13, we need your consent to create their account.</p>
      <p>Your verification code is: <strong>${verificationCode}</strong></p>
      <p>This code expires in 24 hours.</p>
    `
  })
}

export async function sendWelcomeEmail(email: string, name: string) {
  await sgMail.send({
    to: email,
    from: 'welcome@colorarena.com',
    templateId: 'd-welcome-template-id',
    dynamicTemplateData: { name }
  })
}

export async function sendContestReminder(email: string, contestTitle: string) {
  // Implementation
}
```

### 5. Stripe Setup

```typescript
// lib/stripe.ts
import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16'
})

export async function createSubscription(
  customerId: string,
  priceId: string
) {
  return stripe.subscriptions.create({
    customer: customerId,
    items: [{ price: priceId }],
    payment_behavior: 'default_incomplete',
    expand: ['latest_invoice.payment_intent']
  })
}

export async function cancelSubscription(subscriptionId: string) {
  return stripe.subscriptions.update(subscriptionId, {
    cancel_at_period_end: true
  })
}

// Webhook handler
export async function handleWebhook(event: Stripe.Event) {
  switch (event.type) {
    case 'customer.subscription.created':
      // Update subscription in database
      break
    case 'customer.subscription.deleted':
      // Mark subscription as cancelled
      break
    case 'invoice.payment_failed':
      // Handle failed payment
      break
  }
}
```

### 6. Socket.io Setup (Real-time)

```typescript
// lib/socket.ts
import { Server } from 'socket.io'

export function initializeSocket(server: any) {
  const io = new Server(server, {
    cors: {
      origin: process.env.FRONTEND_URL,
      methods: ['GET', 'POST']
    }
  })

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id)

    // Join user's personal room
    socket.on('join', (userId: string) => {
      socket.join(`user:${userId}`)
    })

    // Join contest room
    socket.on('join-contest', (contestId: string) => {
      socket.join(`contest:${contestId}`)
    })

    // Broadcast contest updates
    socket.on('contest-update', (contestId: string, data: any) => {
      io.to(`contest:${contestId}`).emit('update', data)
    })

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id)
    })
  })

  return io
}

// Send notification to user
export function sendNotification(io: Server, userId: string, notification: any) {
  io.to(`user:${userId}`).emit('notification', notification)
}

// Broadcast leaderboard update
export function broadcastLeaderboardUpdate(io: Server, leaderboard: any) {
  io.emit('leaderboard-update', leaderboard)
}
```

---

## 🖥️ Frontend Setup

### Installation

```bash
# Clone repository
git clone https://github.com/your-org/colorarena.git
cd colorarena

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Required Dependencies

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "fabric": "^5.3.0",
    "framer-motion": "^10.16.0",
    "@radix-ui/react-dialog": "^1.0.5",
    "@radix-ui/react-select": "^2.0.0",
    "@radix-ui/react-tooltip": "^1.0.7",
    "@radix-ui/react-tabs": "^1.0.4",
    "@radix-ui/react-progress": "^1.0.3",
    "@radix-ui/react-avatar": "^1.0.4",
    "@radix-ui/react-slot": "^1.0.2",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "tailwind-merge": "^2.0.0",
    "tailwindcss-animate": "^1.0.7",
    "lucide-react": "^0.294.0",
    "@supabase/supabase-js": "^2.38.0",
    "stripe": "^14.5.0",
    "socket.io-client": "^4.7.2"
  }
}
```

---

## 🚀 Deployment

### Vercel Deployment

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

### Environment Variables (Vercel)

Set these in your Vercel dashboard:

```
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_CLOUDINARY_CLOUD_NAME=your-cloud-name
VITE_STRIPE_PUBLIC_KEY=your-stripe-public-key
VITE_SOCKET_URL=your-socket-server-url
```

---

## 🔑 Environment Variables

### Frontend (.env)
```env
# Supabase
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Cloudinary
VITE_CLOUDINARY_CLOUD_NAME=colorarena

# Stripe
VITE_STRIPE_PUBLIC_KEY=pk_test_xxxxx

# Socket.io
VITE_SOCKET_URL=wss://socket.colorarena.com
```

### Backend (.env)
```env
# Supabase
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Redis (Upstash)
UPSTASH_REDIS_REST_URL=https://xxxxx.upstash.io
UPSTASH_REDIS_REST_TOKEN=xxxxx

# Cloudinary
CLOUDINARY_CLOUD_NAME=colorarena
CLOUDINARY_API_KEY=123456789
CLOUDINARY_API_SECRET=xxxxx

# SendGrid
SENDGRID_API_KEY=SG.xxxxx

# Stripe
STRIPE_SECRET_KEY=sk_test_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx

# Auth
JWT_SECRET=your-super-secret-jwt-key
ADMIN_CODE=ARENA2024

# App
FRONTEND_URL=https://colorarena.com
NODE_ENV=production
```

---

## 👶 COPPA Compliance

ColorArena is fully COPPA (Children's Online Privacy Protection Act) compliant:

1. **Parental Consent**: Required for users under 13
2. **Data Minimization**: Only collect necessary data
3. **Parental Controls**: Parents can manage their child's account
4. **Data Access**: Parents can request their child's data
5. **Account Deletion**: Parents can request account deletion
6. **Privacy Policy**: Clear, child-friendly privacy policy
7. **No Behavioral Advertising**: No targeted ads for children

### Parental Controls Features
- Screen time limits
- Contest participation toggle
- Chat/messaging disable
- Content approval requirements
- Activity monitoring dashboard

---

## 📄 License

MIT License - see LICENSE file for details.

---

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📞 Support

- Email: support@colorarena.com
- Documentation: https://docs.colorarena.com
- Discord: https://discord.gg/colorarena

---

Made with ❤️ for creative kids worldwide
