import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CalendarDays, ChevronLeft, ChevronRight, X } from 'lucide-react';

interface DatePickerProps {
  value?: Date;
  onChange?: (date: Date | undefined) => void;
  placeholder?: string;
  label?: string;
  error?: string;
  minDate?: Date;
  maxDate?: Date;
  disabled?: boolean;
  clearable?: boolean;
  className?: string;
}

const DAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export function DatePicker({
  value,
  onChange,
  placeholder = 'Select a date',
  label,
  error,
  minDate,
  maxDate,
  disabled = false,
  clearable = true,
  className = ''
}: DatePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [viewDate, setViewDate] = useState(value || new Date());
  const [viewMode, setViewMode] = useState<'days' | 'months' | 'years'>('days');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setViewMode('days');
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    const days: (Date | null)[] = [];
    
    for (let i = 0; i < startingDay; i++) {
      days.push(null);
    }
    
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    
    return days;
  };

  const isDateDisabled = (date: Date) => {
    if (minDate && date < new Date(minDate.setHours(0, 0, 0, 0))) return true;
    if (maxDate && date > new Date(maxDate.setHours(23, 59, 59, 999))) return true;
    return false;
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const isSelected = (date: Date) => {
    return value && date.toDateString() === value.toDateString();
  };

  const handleSelectDate = (date: Date) => {
    if (isDateDisabled(date)) return;
    onChange?.(date);
    setIsOpen(false);
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange?.(undefined);
  };

  const goToPreviousMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1));
  };

  const goToNextMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1));
  };

  const goToPreviousYear = () => {
    setViewDate(new Date(viewDate.getFullYear() - 1, viewDate.getMonth(), 1));
  };

  const goToNextYear = () => {
    setViewDate(new Date(viewDate.getFullYear() + 1, viewDate.getMonth(), 1));
  };

  const goToPreviousDecade = () => {
    setViewDate(new Date(viewDate.getFullYear() - 10, viewDate.getMonth(), 1));
  };

  const goToNextDecade = () => {
    setViewDate(new Date(viewDate.getFullYear() + 10, viewDate.getMonth(), 1));
  };

  const selectMonth = (month: number) => {
    setViewDate(new Date(viewDate.getFullYear(), month, 1));
    setViewMode('days');
  };

  const selectYear = (year: number) => {
    setViewDate(new Date(year, viewDate.getMonth(), 1));
    setViewMode('months');
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const days = getDaysInMonth(viewDate);
  const years = Array.from({ length: 12 }, (_, i) => {
    const startYear = Math.floor(viewDate.getFullYear() / 10) * 10 - 1;
    return startYear + i;
  });

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-1.5">
          {label}
        </label>
      )}

      {/* Trigger Button */}
      <motion.button
        type="button"
        whileTap={!disabled ? { scale: 0.98 } : {}}
        onClick={() => !disabled && setIsOpen(!isOpen)}
        className={`
          w-full flex items-center justify-between gap-2 px-4 py-2.5 rounded-xl border-2 
          bg-white transition-all duration-200 text-left
          ${isOpen ? 'border-green-500 ring-4 ring-green-100' : 'border-gray-200 hover:border-green-300'}
          ${disabled ? 'bg-gray-50 cursor-not-allowed opacity-60' : 'cursor-pointer'}
          ${error ? 'border-red-500 hover:border-red-500' : ''}
        `}
      >
        <div className="flex items-center gap-2 flex-1">
          <CalendarDays className={`w-5 h-5 ${value ? 'text-green-500' : 'text-gray-400'}`} />
          <span className={value ? 'text-gray-900' : 'text-gray-400'}>
            {value ? formatDate(value) : placeholder}
          </span>
        </div>

        <div className="flex items-center gap-1">
          {clearable && value && (
            <motion.button
              type="button"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleClear}
              className="p-1 hover:bg-gray-100 rounded-full"
            >
              <X className="w-4 h-4 text-gray-400" />
            </motion.button>
          )}
        </div>
      </motion.button>

      {error && (
        <p className="mt-1 text-sm text-red-500">{error}</p>
      )}

      {/* Calendar Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 mt-2 bg-white rounded-xl border-2 border-gray-200 shadow-xl p-4 w-80"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <motion.button
                type="button"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={viewMode === 'days' ? goToPreviousMonth : viewMode === 'months' ? goToPreviousYear : goToPreviousDecade}
                className="p-2 rounded-lg hover:bg-gray-100 text-gray-600 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </motion.button>

              <motion.button
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setViewMode(viewMode === 'days' ? 'months' : viewMode === 'months' ? 'years' : 'years')}
                className="text-lg font-bold text-gray-800 hover:text-green-600 transition-colors"
              >
                {viewMode === 'days' && `${MONTHS[viewDate.getMonth()]} ${viewDate.getFullYear()}`}
                {viewMode === 'months' && viewDate.getFullYear()}
                {viewMode === 'years' && `${years[1]} - ${years[10]}`}
              </motion.button>

              <motion.button
                type="button"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={viewMode === 'days' ? goToNextMonth : viewMode === 'months' ? goToNextYear : goToNextDecade}
                className="p-2 rounded-lg hover:bg-gray-100 text-gray-600 transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </motion.button>
            </div>

            {/* Days View */}
            <AnimatePresence mode="wait">
              {viewMode === 'days' && (
                <motion.div
                  key="days"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  {/* Day headers */}
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {DAYS.map(day => (
                      <div key={day} className="text-center text-xs font-medium text-gray-500 py-2">
                        {day}
                      </div>
                    ))}
                  </div>

                  {/* Calendar grid */}
                  <div className="grid grid-cols-7 gap-1">
                    {days.map((date, index) => {
                      if (!date) {
                        return <div key={`empty-${index}`} className="h-9" />;
                      }

                      const disabled = isDateDisabled(date);
                      const today = isToday(date);
                      const selected = isSelected(date);

                      return (
                        <motion.button
                          key={date.toISOString()}
                          type="button"
                          whileHover={!disabled ? { scale: 1.1 } : {}}
                          whileTap={!disabled ? { scale: 0.95 } : {}}
                          onClick={() => handleSelectDate(date)}
                          disabled={disabled}
                          className={`
                            h-9 w-9 rounded-lg text-sm font-medium transition-all duration-200
                            ${disabled ? 'text-gray-300 cursor-not-allowed' : 'cursor-pointer'}
                            ${today && !selected ? 'ring-2 ring-green-500 ring-offset-1' : ''}
                            ${selected ? 'bg-green-500 text-white shadow-lg' : ''}
                            ${!selected && !disabled ? 'hover:bg-green-100 text-gray-700' : ''}
                          `}
                        >
                          {date.getDate()}
                        </motion.button>
                      );
                    })}
                  </div>
                </motion.div>
              )}

              {/* Months View */}
              {viewMode === 'months' && (
                <motion.div
                  key="months"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="grid grid-cols-3 gap-2"
                >
                  {MONTHS.map((month, index) => (
                    <motion.button
                      key={month}
                      type="button"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => selectMonth(index)}
                      className={`
                        py-3 rounded-lg text-sm font-medium transition-all duration-200
                        ${viewDate.getMonth() === index ? 'bg-green-500 text-white' : 'hover:bg-green-100 text-gray-700'}
                      `}
                    >
                      {month.substring(0, 3)}
                    </motion.button>
                  ))}
                </motion.div>
              )}

              {/* Years View */}
              {viewMode === 'years' && (
                <motion.div
                  key="years"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="grid grid-cols-3 gap-2"
                >
                  {years.map((year) => (
                    <motion.button
                      key={year}
                      type="button"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => selectYear(year)}
                      className={`
                        py-3 rounded-lg text-sm font-medium transition-all duration-200
                        ${viewDate.getFullYear() === year ? 'bg-green-500 text-white' : 'hover:bg-green-100 text-gray-700'}
                      `}
                    >
                      {year}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Quick Actions */}
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
              <motion.button
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  const today = new Date();
                  setViewDate(today);
                  handleSelectDate(today);
                }}
                className="text-sm text-green-600 font-medium hover:text-green-700"
              >
                Today
              </motion.button>

              <motion.button
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setIsOpen(false);
                  setViewMode('days');
                }}
                className="text-sm text-gray-500 font-medium hover:text-gray-700"
              >
                Close
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
