import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/utils/cn"

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold transition-all duration-300 hover:scale-110",
  {
    variants: {
      variant: {
        default:
          "border-transparent bg-green-500 text-white shadow-md hover:shadow-lg hover:shadow-green-500/30",
        secondary:
          "border-transparent bg-green-100 text-green-700 hover:bg-green-200",
        destructive:
          "border-transparent bg-red-500 text-white hover:bg-red-600",
        outline: 
          "border-green-200 text-green-700 hover:bg-green-50",
        success:
          "border-transparent bg-emerald-500 text-white hover:bg-emerald-600",
        warning:
          "border-transparent bg-yellow-500 text-white hover:bg-yellow-600",
        info:
          "border-transparent bg-blue-500 text-white hover:bg-blue-600",
        glow:
          "border-transparent bg-green-500 text-white shadow-lg shadow-green-500/50 animate-pulse",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props} />
  )
}

export { Badge, badgeVariants }
