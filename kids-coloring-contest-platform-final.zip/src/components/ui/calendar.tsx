import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CalendarProps {
  selectedDate?: Date;
  onSelectDate?: (date: Date) => void;
  minDate?: Date;
  maxDate?: Date;
  highlightedDates?: { date: Date; intensity: number }[];
  streakData?: { [key: string]: number };
  mode?: 'picker' | 'streak' | 'range';
  className?: string;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export function Calendar({
  selectedDate,
  onSelectDate,
  minDate,
  maxDate,
  streakData = {},
  mode = 'picker',
  className = ''
}: CalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(selectedDate || new Date());
  const [hoveredDate, setHoveredDate] = useState<Date | null>(null);

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    const days: (Date | null)[] = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDay; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    
    return days;
  };

  const goToPreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const isDateDisabled = (date: Date) => {
    if (minDate && date < minDate) return true;
    if (maxDate && date > maxDate) return true;
    return false;
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const isSelected = (date: Date) => {
    return selectedDate && date.toDateString() === selectedDate.toDateString();
  };

  const getStreakIntensity = (date: Date): number => {
    const dateKey = date.toISOString().split('T')[0];
    return streakData[dateKey] || 0;
  };

  const getIntensityColor = (intensity: number) => {
    if (intensity === 0) return 'bg-gray-100 dark:bg-gray-800';
    if (intensity === 1) return 'bg-green-200';
    if (intensity === 2) return 'bg-green-300';
    if (intensity === 3) return 'bg-green-400';
    if (intensity >= 4) return 'bg-green-500';
    return 'bg-gray-100';
  };

  const days = getDaysInMonth(currentMonth);

  return (
    <div className={`bg-white rounded-2xl shadow-lg border border-gray-200 p-4 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={goToPreviousMonth}
          className="p-2 rounded-lg hover:bg-gray-100 text-gray-600 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
        </motion.button>
        
        <motion.h3 
          key={currentMonth.toISOString()}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-lg font-bold text-gray-800"
        >
          {MONTHS[currentMonth.getMonth()]} {currentMonth.getFullYear()}
        </motion.h3>
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={goToNextMonth}
          className="p-2 rounded-lg hover:bg-gray-100 text-gray-600 transition-colors"
        >
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 gap-1 mb-2">
        {DAYS.map(day => (
          <div key={day} className="text-center text-xs font-medium text-gray-500 py-2">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentMonth.toISOString()}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="grid grid-cols-7 gap-1"
        >
          {days.map((date, index) => {
            if (!date) {
              return <div key={`empty-${index}`} className="h-10" />;
            }

            const disabled = isDateDisabled(date);
            const today = isToday(date);
            const selected = isSelected(date);
            const intensity = mode === 'streak' ? getStreakIntensity(date) : 0;
            const isHovered = hoveredDate?.toDateString() === date.toDateString();

            return (
              <motion.button
                key={date.toISOString()}
                whileHover={!disabled ? { scale: 1.1 } : {}}
                whileTap={!disabled ? { scale: 0.95 } : {}}
                onClick={() => !disabled && onSelectDate?.(date)}
                onMouseEnter={() => setHoveredDate(date)}
                onMouseLeave={() => setHoveredDate(null)}
                disabled={disabled}
                className={`
                  relative h-10 rounded-lg text-sm font-medium transition-all duration-200
                  ${disabled ? 'text-gray-300 cursor-not-allowed' : 'cursor-pointer'}
                  ${today && !selected ? 'ring-2 ring-green-500 ring-offset-1' : ''}
                  ${selected ? 'bg-green-500 text-white shadow-lg' : ''}
                  ${!selected && !disabled && mode === 'picker' ? 'hover:bg-green-100 text-gray-700' : ''}
                  ${mode === 'streak' ? getIntensityColor(intensity) : ''}
                  ${mode === 'streak' && intensity > 0 ? 'text-white' : ''}
                `}
              >
                {date.getDate()}
                
                {/* Tooltip for streak mode */}
                {mode === 'streak' && isHovered && intensity > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-xs rounded-lg whitespace-nowrap z-10"
                  >
                    {intensity} artwork{intensity > 1 ? 's' : ''} completed
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900" />
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </motion.div>
      </AnimatePresence>

      {/* Legend for streak mode */}
      {mode === 'streak' && (
        <div className="flex items-center justify-end gap-2 mt-4 pt-4 border-t border-gray-100">
          <span className="text-xs text-gray-500">Less</span>
          {[0, 1, 2, 3, 4].map(level => (
            <div
              key={level}
              className={`w-4 h-4 rounded ${getIntensityColor(level)}`}
            />
          ))}
          <span className="text-xs text-gray-500">More</span>
        </div>
      )}
    </div>
  );
}

// Streak Calendar - Full Year View (LeetCode style)
interface StreakCalendarProps {
  streakData: { [key: string]: number };
  currentStreak: number;
  longestStreak: number;
  totalActiveDays: number;
  className?: string;
}

export function StreakCalendar({
  streakData,
  currentStreak,
  longestStreak,
  totalActiveDays,
  className = ''
}: StreakCalendarProps) {
  const [hoveredDay, setHoveredDay] = useState<{ date: string; count: number } | null>(null);
  
  // Generate last 365 days
  const generateYearData = () => {
    const days: { date: Date; count: number }[] = [];
    const today = new Date();
    
    for (let i = 364; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateKey = date.toISOString().split('T')[0];
      days.push({
        date,
        count: streakData[dateKey] || 0
      });
    }
    
    return days;
  };

  const yearData = generateYearData();
  
  // Group by weeks
  const weeks: { date: Date; count: number }[][] = [];
  let currentWeek: { date: Date; count: number }[] = [];
  
  // Pad the first week if needed
  const firstDayOfWeek = yearData[0].date.getDay();
  for (let i = 0; i < firstDayOfWeek; i++) {
    currentWeek.push({ date: new Date(0), count: -1 }); // -1 indicates empty cell
  }
  
  yearData.forEach(day => {
    currentWeek.push(day);
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
  });
  
  if (currentWeek.length > 0) {
    weeks.push(currentWeek);
  }

  const getIntensityColor = (count: number) => {
    if (count === -1) return 'bg-transparent';
    if (count === 0) return 'bg-gray-100 hover:bg-gray-200';
    if (count === 1) return 'bg-green-200 hover:bg-green-300';
    if (count === 2) return 'bg-green-300 hover:bg-green-400';
    if (count === 3) return 'bg-green-400 hover:bg-green-500';
    return 'bg-green-500 hover:bg-green-600';
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  // Get month labels
  const getMonthLabels = () => {
    const labels: { month: string; index: number }[] = [];
    let lastMonth = -1;
    
    weeks.forEach((week, weekIndex) => {
      const validDay = week.find(d => d.count !== -1);
      if (validDay) {
        const month = validDay.date.getMonth();
        if (month !== lastMonth) {
          labels.push({ 
            month: MONTHS[month].substring(0, 3), 
            index: weekIndex 
          });
          lastMonth = month;
        }
      }
    });
    
    return labels;
  };

  const monthLabels = getMonthLabels();

  return (
    <div className={`bg-white rounded-2xl shadow-lg border border-gray-200 p-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
          <span className="text-2xl">📅</span> Activity Calendar
        </h3>
        
        <div className="flex items-center gap-4">
          <div className="text-center px-4 py-2 bg-orange-50 rounded-xl border border-orange-200">
            <div className="flex items-center gap-1">
              <span className="text-xl">🔥</span>
              <span className="text-2xl font-bold text-orange-500">{currentStreak}</span>
            </div>
            <p className="text-xs text-orange-600 font-medium">Current</p>
          </div>
          
          <div className="text-center px-4 py-2 bg-yellow-50 rounded-xl border border-yellow-200">
            <div className="flex items-center gap-1">
              <span className="text-xl">🏆</span>
              <span className="text-2xl font-bold text-yellow-600">{longestStreak}</span>
            </div>
            <p className="text-xs text-yellow-700 font-medium">Longest</p>
          </div>
          
          <div className="text-center px-4 py-2 bg-green-50 rounded-xl border border-green-200">
            <div className="flex items-center gap-1">
              <span className="text-xl">📅</span>
              <span className="text-2xl font-bold text-green-600">{totalActiveDays}</span>
            </div>
            <p className="text-xs text-green-700 font-medium">Active Days</p>
          </div>
        </div>
      </div>

      {/* Month labels */}
      <div className="flex mb-2 ml-8">
        {monthLabels.map((label, i) => (
          <div
            key={i}
            className="text-xs text-gray-500 font-medium"
            style={{ 
              position: 'relative',
              left: `${label.index * 14}px`,
              marginRight: i < monthLabels.length - 1 
                ? `${(monthLabels[i + 1]?.index - label.index - 1) * 14 - 20}px` 
                : 0
            }}
          >
            {label.month}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="flex gap-1">
        {/* Day labels */}
        <div className="flex flex-col gap-1 pr-2">
          {['', 'Mon', '', 'Wed', '', 'Fri', ''].map((day, i) => (
            <div key={i} className="h-3 text-xs text-gray-500 font-medium flex items-center">
              {day}
            </div>
          ))}
        </div>

        {/* Weeks */}
        <div className="flex gap-1 relative">
          {weeks.map((week, weekIndex) => (
            <div key={weekIndex} className="flex flex-col gap-1">
              {week.map((day, dayIndex) => (
                <motion.div
                  key={`${weekIndex}-${dayIndex}`}
                  whileHover={day.count !== -1 ? { scale: 1.3 } : {}}
                  onMouseEnter={() => day.count !== -1 && setHoveredDay({ 
                    date: formatDate(day.date), 
                    count: day.count 
                  })}
                  onMouseLeave={() => setHoveredDay(null)}
                  className={`
                    w-3 h-3 rounded-sm cursor-pointer transition-colors duration-200
                    ${getIntensityColor(day.count)}
                  `}
                />
              ))}
            </div>
          ))}

          {/* Tooltip */}
          <AnimatePresence>
            {hoveredDay && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute -top-12 left-1/2 transform -translate-x-1/2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg whitespace-nowrap z-20 shadow-xl"
              >
                <p className="font-medium">{hoveredDay.count} artwork{hoveredDay.count !== 1 ? 's' : ''} completed</p>
                <p className="text-gray-400">{hoveredDay.date}</p>
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full border-4 border-transparent border-t-gray-900" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-between mt-6 pt-4 border-t border-gray-100">
        <p className="text-sm text-gray-500">
          {currentStreak >= 7 
            ? "🔥 You're on fire! Amazing streak!" 
            : currentStreak >= 3 
              ? "💪 Great progress! Keep it up!" 
              : "✨ Color something today to start your streak!"}
        </p>
        
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">Less</span>
          {[0, 1, 2, 3, 4].map(level => (
            <div
              key={level}
              className={`w-3 h-3 rounded-sm ${level === 0 ? 'bg-gray-100' : `bg-green-${200 + level * 100}`}`}
              style={{ backgroundColor: level === 0 ? '#f3f4f6' : `rgb(${134 - level * 20}, ${239 - level * 20}, ${172 - level * 20})` }}
            />
          ))}
          <span className="text-xs text-gray-500">More</span>
        </div>
      </div>
    </div>
  );
}
