import * as React from "react"
import { motion } from "framer-motion"
import { cn } from "@/utils/cn"

interface AnimatedCardProps {
  children: React.ReactNode
  className?: string
  hoverEffect?: "lift" | "scale" | "tilt" | "glow" | "bounce"
  delay?: number
  onClick?: () => void
  onMouseEnter?: () => void
  onMouseLeave?: () => void
}

const AnimatedCard: React.FC<AnimatedCardProps> = ({ 
  className, 
  children, 
  hoverEffect = "lift", 
  delay = 0,
  onClick,
  onMouseEnter,
  onMouseLeave
}) => {
  const hoverAnimations = {
    lift: {
      y: -8,
      boxShadow: "0 25px 50px -12px rgba(34, 197, 94, 0.25)",
    },
    scale: {
      scale: 1.05,
      boxShadow: "0 25px 50px -12px rgba(34, 197, 94, 0.25)",
    },
    tilt: {
      rotateX: -5,
      rotateY: 5,
      scale: 1.02,
    },
    glow: {
      boxShadow: "0 0 30px rgba(34, 197, 94, 0.4), 0 0 60px rgba(34, 197, 94, 0.2)",
      scale: 1.02,
    },
    bounce: {
      y: -5,
      scale: 1.02,
    },
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      whileHover={hoverAnimations[hoverEffect]}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      className={cn(
        "rounded-2xl bg-white shadow-lg border border-gray-100 overflow-hidden cursor-pointer",
        className
      )}
      style={{ transformStyle: "preserve-3d", perspective: 1000 }}
    >
      {children}
    </motion.div>
  )
}

// Magnetic button that follows cursor
interface MagneticButtonProps {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

const MagneticButton: React.FC<MagneticButtonProps> = ({ 
  className, 
  children,
  onClick
}) => {
  const buttonRef = React.useRef<HTMLButtonElement>(null)
  const [position, setPosition] = React.useState({ x: 0, y: 0 })

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    const button = buttonRef.current
    if (!button) return

    const rect = button.getBoundingClientRect()
    const x = e.clientX - rect.left - rect.width / 2
    const y = e.clientY - rect.top - rect.height / 2

    setPosition({ x: x * 0.3, y: y * 0.3 })
  }

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 })
  }

  return (
    <motion.button
      ref={buttonRef}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 150, damping: 15 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      className={cn(
        "relative inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold rounded-full shadow-lg transition-shadow hover:shadow-xl hover:shadow-green-500/25",
        className
      )}
    >
      {children}
    </motion.button>
  )
}

// Ripple effect button
interface RippleButtonProps {
  children: React.ReactNode
  className?: string
  variant?: "primary" | "secondary" | "outline"
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void
}

const RippleButton: React.FC<RippleButtonProps> = ({ 
  className, 
  children, 
  variant = "primary", 
  onClick
}) => {
  const [ripples, setRipples] = React.useState<{ x: number; y: number; id: number }[]>([])

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const button = e.currentTarget
    const rect = button.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    const id = Date.now()

    setRipples((prev) => [...prev, { x, y, id }])

    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id))
    }, 600)

    onClick?.(e)
  }

  const variants = {
    primary: "bg-gradient-to-r from-green-500 to-emerald-600 text-white",
    secondary: "bg-green-100 text-green-700",
    outline: "border-2 border-green-500 text-green-600 bg-transparent",
  }

  return (
    <button
      onClick={handleClick}
      className={cn(
        "relative overflow-hidden px-6 py-3 font-semibold rounded-full transition-all duration-300 hover:scale-105 active:scale-95",
        variants[variant],
        className
      )}
    >
      {ripples.map((ripple) => (
        <span
          key={ripple.id}
          className="absolute bg-white/30 rounded-full animate-ripple"
          style={{
            left: ripple.x,
            top: ripple.y,
            transform: "translate(-50%, -50%)",
          }}
        />
      ))}
      <span className="relative z-10">{children}</span>
    </button>
  )
}

// Shimmer effect wrapper
interface ShimmerProps {
  children: React.ReactNode
  className?: string
}

const Shimmer: React.FC<ShimmerProps> = ({ children, className }) => (
  <div className={cn("relative overflow-hidden group", className)}>
    {children}
    <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
  </div>
)

// Floating animation wrapper
interface FloatingProps {
  children: React.ReactNode
  className?: string
  duration?: number
  distance?: number
}

const Floating: React.FC<FloatingProps> = ({ 
  children, 
  className, 
  duration = 3, 
  distance = 10 
}) => (
  <motion.div
    animate={{ y: [-distance, distance, -distance] }}
    transition={{ duration, repeat: Infinity, ease: "easeInOut" }}
    className={className}
  >
    {children}
  </motion.div>
)

// Pulse glow effect
interface PulseGlowProps {
  children: React.ReactNode
  className?: string
  color?: string
}

const PulseGlow: React.FC<PulseGlowProps> = ({ 
  children, 
  className,
  color = "rgba(34, 197, 94, 0.5)" 
}) => (
  <div className={cn("relative", className)}>
    <div 
      className="absolute inset-0 rounded-full animate-pulse-glow"
      style={{ boxShadow: `0 0 20px ${color}, 0 0 40px ${color}` }}
    />
    <div className="relative">{children}</div>
  </div>
)

// Interactive icon button with pop effect
interface IconButtonProps {
  icon: React.ReactNode
  className?: string
  onClick?: () => void
  tooltip?: string
}

const IconButton: React.FC<IconButtonProps> = ({ 
  icon, 
  className,
  onClick 
}) => (
  <motion.button
    whileHover={{ scale: 1.2, rotate: 5 }}
    whileTap={{ scale: 0.9 }}
    onClick={onClick}
    className={cn(
      "p-2 rounded-xl bg-white shadow-md border border-gray-100 hover:shadow-lg hover:border-green-200 transition-colors",
      className
    )}
  >
    {icon}
  </motion.button>
)

// Staggered list animation
interface StaggeredListProps {
  children: React.ReactNode[]
  className?: string
  staggerDelay?: number
}

const StaggeredList: React.FC<StaggeredListProps> = ({ 
  children, 
  className,
  staggerDelay = 0.1 
}) => (
  <div className={className}>
    {React.Children.map(children, (child, index) => (
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: index * staggerDelay }}
      >
        {child}
      </motion.div>
    ))}
  </div>
)

export { 
  AnimatedCard, 
  MagneticButton, 
  RippleButton, 
  Shimmer, 
  Floating, 
  PulseGlow,
  IconButton,
  StaggeredList
}
