import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Palette,
  Home,
  ImageIcon,
  Trophy,
  BarChart3,
  Menu,
  X,
  LogOut,
  Flame,
  Brush,
  Shield,
  Settings,
  PlusCircle
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import NotificationDropdown, { Notification } from './NotificationDropdown';

type HeaderProps = {
  currentPage: string;
  onNavigate: (page: string) => void;
  user: string | null;
  isAdmin?: boolean;
  onLogout: () => void;
  onLoginClick: () => void;
  streakDays?: number;
  notifications?: Notification[];
  onMarkNotificationAsRead?: (id: string) => void;
  onMarkAllNotificationsAsRead?: () => void;
  onClearAllNotifications?: () => void;
  onNotificationClick?: (notification: Notification) => void;
};

export function Header({ 
  currentPage, 
  onNavigate, 
  user, 
  isAdmin, 
  onLogout, 
  onLoginClick, 
  streakDays = 0,
  notifications = [],
  onMarkNotificationAsRead,
  onMarkAllNotificationsAsRead,
  onClearAllNotifications,
  onNotificationClick
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const userNavItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'practice', icon: Brush, label: 'Practice' },
    { id: 'gallery', icon: ImageIcon, label: 'Gallery' },
    { id: 'contests', icon: Trophy, label: 'Contests' },
    { id: 'leaderboard', icon: BarChart3, label: 'Leaderboard' },
  ];

  const adminNavItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'admin', icon: Settings, label: 'Dashboard' },
    { id: 'practice', icon: Brush, label: 'Practice' },
    { id: 'contests', icon: Trophy, label: 'Contests' },
    { id: 'leaderboard', icon: BarChart3, label: 'Leaderboard' },
  ];

  const navItems = isAdmin ? adminNavItems : userNavItems;

  return (
    <TooltipProvider>
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-green-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <motion.button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 group"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                className={`p-2 rounded-xl shadow-md ${
                  isAdmin 
                    ? 'bg-gradient-to-br from-gray-800 to-gray-900' 
                    : 'bg-gradient-to-br from-green-500 to-emerald-600'
                }`}
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                {isAdmin ? (
                  <Shield className="w-6 h-6 text-white" />
                ) : (
                  <Palette className="w-6 h-6 text-white" />
                )}
              </motion.div>
              <div>
                <span className="font-bold text-xl text-gray-800">
                  Color<span className={isAdmin ? 'text-gray-600' : 'text-green-600'}>Arena</span>
                </span>
                {isAdmin && (
                  <span className="ml-2 px-2 py-0.5 bg-gray-800 text-white text-xs font-medium rounded-full">
                    ADMIN
                  </span>
                )}
              </div>
            </motion.button>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <Tooltip key={item.id}>
                  <TooltipTrigger asChild>
                    <motion.button
                      onClick={() => onNavigate(item.id)}
                      className={`relative px-4 py-2 rounded-xl font-medium transition-all duration-200 flex items-center gap-2 group ${
                        currentPage === item.id
                          ? isAdmin
                            ? 'bg-gray-100 text-gray-800'
                            : 'bg-green-100 text-green-700'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                      whileHover={{ y: -2 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <item.icon
                        className={`w-5 h-5 transition-transform duration-200 ${
                          currentPage === item.id ? 'animate-wiggle' : 'group-hover:scale-110'
                        }`}
                      />
                      <span className="hidden lg:inline">{item.label}</span>
                      {currentPage === item.id && (
                        <motion.div
                          layoutId="activeNav"
                          className={`absolute inset-0 rounded-xl -z-10 ${
                            isAdmin ? 'bg-gray-100' : 'bg-green-100'
                          }`}
                          transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                        />
                      )}
                    </motion.button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{item.label}</p>
                  </TooltipContent>
                </Tooltip>
              ))}
            </nav>

            {/* Right Section */}
            <div className="flex items-center gap-3">
              {/* Streak Badge - Always visible for logged in non-admin users */}
              {user && !isAdmin && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <motion.button
                      onClick={() => onNavigate('profile')}
                      className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all duration-300 ${
                        streakDays > 0 
                          ? 'bg-gradient-to-r from-orange-500 via-red-500 to-orange-600 text-white shadow-lg shadow-orange-500/30' 
                          : 'bg-gray-100 text-gray-400 border border-gray-200'
                      }`}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', bounce: 0.5 }}
                    >
                      {streakDays > 0 ? (
                        /* Active Flame - Animated and colorful */
                        <>
                          <div className="relative">
                            <motion.div
                              animate={{ 
                                scale: [1, 1.3, 1],
                                rotate: [0, -10, 10, 0]
                              }}
                              transition={{ 
                                repeat: Infinity, 
                                duration: 0.8,
                                ease: "easeInOut"
                              }}
                            >
                              <Flame className="w-5 h-5 text-yellow-200 drop-shadow-lg" />
                            </motion.div>
                            {/* Fire glow effect */}
                            <motion.div 
                              className="absolute inset-0 blur-sm"
                              animate={{ opacity: [0.5, 1, 0.5] }}
                              transition={{ repeat: Infinity, duration: 0.5 }}
                            >
                              <Flame className="w-5 h-5 text-yellow-400" />
                            </motion.div>
                            {/* Sparks */}
                            <motion.div
                              className="absolute -top-1 left-1/2 w-1 h-1 bg-yellow-300 rounded-full"
                              animate={{ 
                                y: [-2, -8],
                                opacity: [1, 0],
                                scale: [1, 0.5]
                              }}
                              transition={{ repeat: Infinity, duration: 0.8, delay: 0 }}
                            />
                            <motion.div
                              className="absolute -top-0.5 left-1 w-0.5 h-0.5 bg-orange-300 rounded-full"
                              animate={{ 
                                y: [-2, -6],
                                x: [-2, -4],
                                opacity: [1, 0],
                                scale: [1, 0.3]
                              }}
                              transition={{ repeat: Infinity, duration: 0.7, delay: 0.2 }}
                            />
                            <motion.div
                              className="absolute -top-0.5 right-1 w-0.5 h-0.5 bg-red-300 rounded-full"
                              animate={{ 
                                y: [-2, -6],
                                x: [2, 4],
                                opacity: [1, 0],
                                scale: [1, 0.3]
                              }}
                              transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                            />
                          </div>
                          <span className="font-bold text-sm text-white">{streakDays}</span>
                          {/* Pulsing indicator */}
                          <motion.div
                            className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-yellow-300 rounded-full shadow-lg shadow-yellow-500/50"
                            animate={{ scale: [1, 1.4, 1] }}
                            transition={{ repeat: Infinity, duration: 0.8 }}
                          />
                        </>
                      ) : (
                        /* Inactive Flame - Dull and static */
                        <>
                          <Flame className="w-5 h-5 text-gray-300" />
                          <span className="font-medium text-sm text-gray-400">{streakDays}</span>
                        </>
                      )}
                    </motion.button>
                  </TooltipTrigger>
                  <TooltipContent>
                    {streakDays > 0 ? (
                      <p className="flex items-center gap-1">
                        <span className="animate-pulse">🔥</span> {streakDays} Day Streak! Keep coloring daily!
                      </p>
                    ) : (
                      <p className="text-gray-500">
                        😴 No streak yet. Color today to ignite the flame! 🎨
                      </p>
                    )}
                  </TooltipContent>
                </Tooltip>
              )}

              {/* Notification Bell - Only for logged in users */}
              {user && (
                <NotificationDropdown
                  notifications={notifications}
                  onMarkAsRead={onMarkNotificationAsRead || (() => {})}
                  onMarkAllAsRead={onMarkAllNotificationsAsRead || (() => {})}
                  onClearAll={onClearAllNotifications || (() => {})}
                  onNotificationClick={onNotificationClick || (() => {})}
                  isAdmin={isAdmin}
                />
              )}

              {user ? (
                <div className="flex items-center gap-2">
                  {/* Admin Quick Actions */}
                  {isAdmin && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <motion.button
                          onClick={() => onNavigate('admin')}
                          className="p-2 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <PlusCircle className="w-5 h-5 text-gray-600" />
                        </motion.button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Create New</p>
                      </TooltipContent>
                    </Tooltip>
                  )}

                  {/* User Profile Button */}
                  <motion.button
                    onClick={() => onNavigate('profile')}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-xl transition-all ${
                      isAdmin 
                        ? 'bg-gray-100 hover:bg-gray-200' 
                        : 'bg-green-100 hover:bg-green-200'
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isAdmin 
                        ? 'bg-gradient-to-br from-gray-700 to-gray-900' 
                        : 'bg-gradient-to-br from-green-500 to-emerald-600'
                    }`}>
                      {isAdmin ? (
                        <Shield className="w-4 h-4 text-white" />
                      ) : (
                        <span className="text-white text-sm font-bold">
                          {user.charAt(0).toUpperCase()}
                        </span>
                      )}
                    </div>
                    <span className="hidden sm:inline font-medium text-gray-700">{user}</span>
                  </motion.button>

                  {/* Logout Button */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <motion.button
                        onClick={onLogout}
                        className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                        whileHover={{ scale: 1.1, rotate: 15 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <LogOut className="w-5 h-5" />
                      </motion.button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Logout</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
              ) : (
                <motion.button
                  onClick={onLoginClick}
                  className="px-5 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl shadow-md hover:shadow-lg transition-shadow"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Login
                </motion.button>
              )}

              {/* Mobile Menu Button */}
              <motion.button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 hover:bg-gray-100 rounded-xl"
                whileTap={{ scale: 0.9 }}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </motion.button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-gray-100"
            >
              <nav className="p-4 space-y-2">
                {navItems.map((item) => (
                  <motion.button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                      currentPage === item.id
                        ? isAdmin
                          ? 'bg-gray-100 text-gray-800'
                          : 'bg-green-100 text-green-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                    whileTap={{ scale: 0.98 }}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </motion.button>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </TooltipProvider>
  );
}
