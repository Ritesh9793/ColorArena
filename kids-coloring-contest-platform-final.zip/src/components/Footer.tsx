import { motion } from 'framer-motion';
import { 
  Palette, 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube,
  Linkedin,
  Send,
  Heart,
  Shield,
  FileText,
  HelpCircle,
  Users,
  Award,
  BookOpen,
  Newspaper,
  Briefcase,
  MessageCircle,
  Globe,
  ChevronRight
} from 'lucide-react';
import { useState } from 'react';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const currentYear = new Date().getFullYear();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  const footerLinks = {
    product: {
      title: 'Product',
      icon: Palette,
      links: [
        { name: 'Features', href: '#' },
        { name: 'Gallery', href: '#' },
        { name: 'Contests', href: '#' },
        { name: 'Leaderboard', href: '#' },
        { name: 'Pricing', href: '#' },
        { name: 'Enterprise', href: '#' },
      ]
    },
    resources: {
      title: 'Resources',
      icon: BookOpen,
      links: [
        { name: 'Help Center', href: '#' },
        { name: 'Tutorials', href: '#' },
        { name: 'Blog', href: '#' },
        { name: 'Community', href: '#' },
        { name: 'Webinars', href: '#' },
        { name: 'API Docs', href: '#' },
      ]
    },
    company: {
      title: 'Company',
      icon: Briefcase,
      links: [
        { name: 'About Us', href: '#' },
        { name: 'Careers', href: '#' },
        { name: 'Press Kit', href: '#' },
        { name: 'Partners', href: '#' },
        { name: 'Contact', href: '#' },
        { name: 'Investors', href: '#' },
      ]
    },
    legal: {
      title: 'Legal',
      icon: Shield,
      links: [
        { name: 'Privacy Policy', href: '#' },
        { name: 'Terms of Service', href: '#' },
        { name: 'Cookie Policy', href: '#' },
        { name: 'COPPA Compliance', href: '#' },
        { name: 'GDPR', href: '#' },
        { name: 'Accessibility', href: '#' },
      ]
    }
  };

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook', color: 'hover:bg-blue-600' },
    { icon: Twitter, href: '#', label: 'Twitter', color: 'hover:bg-sky-500' },
    { icon: Instagram, href: '#', label: 'Instagram', color: 'hover:bg-pink-600' },
    { icon: Youtube, href: '#', label: 'YouTube', color: 'hover:bg-red-600' },
    { icon: Linkedin, href: '#', label: 'LinkedIn', color: 'hover:bg-blue-700' },
  ];

  const certifications = [
    { name: 'COPPA Compliant', icon: Shield },
    { name: 'GDPR Ready', icon: Globe },
    { name: 'Kid Safe', icon: Users },
    { name: 'Award Winning', icon: Award },
  ];

  return (
    <footer className="bg-gradient-to-b from-gray-900 via-gray-900 to-black text-white">
      {/* Newsletter Section */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="bg-gradient-to-r from-green-600/20 via-emerald-600/20 to-teal-600/20 rounded-2xl p-8 md:p-12 border border-green-500/20">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="flex items-center gap-3 mb-4"
                >
                  <div className="p-3 bg-green-500 rounded-xl">
                    <Newspaper className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold">Stay in the Loop</h3>
                </motion.div>
                <p className="text-gray-400">
                  Get weekly updates on new coloring pages, contests, tips, and exclusive offers. 
                  Perfect for parents and educators!
                </p>
              </div>
              <motion.form 
                onSubmit={handleSubscribe}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="flex flex-col sm:flex-row gap-3"
              >
                <div className="relative flex-1">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-gray-800/50 border border-gray-700 rounded-xl focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-500/20 transition-all"
                  />
                </div>
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-green-500/25 transition-all"
                >
                  {subscribed ? (
                    <>
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                      >
                        ✓
                      </motion.span>
                      Subscribed!
                    </>
                  ) : (
                    <>
                      Subscribe
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </motion.button>
              </motion.form>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="col-span-2">
            <motion.div 
              className="flex items-center gap-3 mb-6"
              whileHover={{ scale: 1.02 }}
            >
              <div className="p-2 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl">
                <Palette className="w-8 h-8 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                ColorArena
              </span>
            </motion.div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              The world's most engaging coloring platform for kids and teens. 
              Learn, create, compete, and have fun in a safe, moderated environment.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3 mb-6">
              <a href="mailto:hello@colorarena.com" className="flex items-center gap-3 text-gray-400 hover:text-green-400 transition-colors group">
                <div className="p-2 bg-gray-800 rounded-lg group-hover:bg-green-500/20 transition-colors">
                  <Mail className="w-4 h-4" />
                </div>
                hello@colorarena.com
              </a>
              <a href="tel:+1234567890" className="flex items-center gap-3 text-gray-400 hover:text-green-400 transition-colors group">
                <div className="p-2 bg-gray-800 rounded-lg group-hover:bg-green-500/20 transition-colors">
                  <Phone className="w-4 h-4" />
                </div>
                +1 (234) 567-890
              </a>
              <div className="flex items-center gap-3 text-gray-400">
                <div className="p-2 bg-gray-800 rounded-lg">
                  <MapPin className="w-4 h-4" />
                </div>
                San Francisco, CA, USA
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-2">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className={`p-3 bg-gray-800 rounded-xl text-gray-400 hover:text-white ${social.color} transition-all`}
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Link Columns */}
          {Object.values(footerLinks).map((section, sectionIndex) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: sectionIndex * 0.1 }}
            >
              <div className="flex items-center gap-2 mb-4">
                <section.icon className="w-4 h-4 text-green-500" />
                <h4 className="font-semibold text-white">{section.title}</h4>
              </div>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      className="text-gray-400 hover:text-green-400 transition-colors flex items-center gap-1 group"
                    >
                      <ChevronRight className="w-3 h-3 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Certifications */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex flex-wrap justify-center gap-6 md:gap-12">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="flex items-center gap-2 text-gray-500"
              >
                <cert.icon className="w-5 h-5 text-green-500" />
                <span className="text-sm font-medium">{cert.name}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800 bg-black/50">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            {/* Copyright */}
            <div className="flex items-center gap-1 text-gray-500 text-sm">
              <span>© {currentYear} ColorArena, Inc. All rights reserved.</span>
            </div>

            {/* Made with love */}
            <div className="flex items-center gap-1 text-gray-500 text-sm">
              <span>Made with</span>
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <Heart className="w-4 h-4 text-red-500 fill-red-500" />
              </motion.div>
              <span>for creative kids worldwide</span>
            </div>

            {/* Legal Links */}
            <div className="flex items-center gap-4 text-sm">
              <a href="#" className="text-gray-500 hover:text-green-400 transition-colors flex items-center gap-1">
                <FileText className="w-3 h-3" />
                Terms
              </a>
              <a href="#" className="text-gray-500 hover:text-green-400 transition-colors flex items-center gap-1">
                <Shield className="w-3 h-3" />
                Privacy
              </a>
              <a href="#" className="text-gray-500 hover:text-green-400 transition-colors flex items-center gap-1">
                <HelpCircle className="w-3 h-3" />
                Support
              </a>
              <a href="#" className="text-gray-500 hover:text-green-400 transition-colors flex items-center gap-1">
                <MessageCircle className="w-3 h-3" />
                Feedback
              </a>
            </div>
          </div>

          {/* Additional Legal Text */}
          <div className="mt-6 pt-6 border-t border-gray-800/50 text-center">
            <p className="text-xs text-gray-600 max-w-4xl mx-auto leading-relaxed">
              ColorArena is committed to protecting children's privacy online. We comply with the Children's Online Privacy Protection Act (COPPA) 
              and the General Data Protection Regulation (GDPR). All content is moderated and age-appropriate. 
              Parental consent is required for users under 13. For more information, please read our{' '}
              <a href="#" className="text-green-500 hover:underline">Privacy Policy</a> and{' '}
              <a href="#" className="text-green-500 hover:underline">Terms of Service</a>.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
