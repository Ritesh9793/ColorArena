import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Select } from '../components/ui/Select';

interface User {
  name: string;
  email: string;
  isAdmin?: boolean;
  age?: number;
  country?: string;
  avatar?: string;
}

interface SettingsPageProps {
  user: User | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  onUpdateUser?: (updates: Partial<User>) => void;
}

type SettingsTab = 'account' | 'notifications' | 'privacy' | 'appearance' | 'parental' | 'security' | 'platform' | 'users' | 'content' | 'emails' | 'api' | 'backup';

export default function SettingsPage({ user, onNavigate, onLogout, onUpdateUser }: SettingsPageProps) {
  const [activeTab, setActiveTab] = useState<SettingsTab>('account');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showSaveNotification, setShowSaveNotification] = useState(false);
  
  // Countries list
  const countries = [
    'United States', 'United Kingdom', 'Canada', 'Australia', 'India',
    'Germany', 'France', 'Japan', 'Brazil', 'Mexico', 'Spain', 'Italy',
    'Netherlands', 'Sweden', 'Norway', 'Denmark', 'Finland', 'Poland',
    'South Korea', 'Singapore', 'Malaysia', 'Indonesia', 'Philippines',
    'Thailand', 'Vietnam', 'South Africa', 'Nigeria', 'Egypt', 'UAE',
    'Saudi Arabia', 'Turkey', 'Russia', 'China', 'New Zealand', 'Ireland',
    'Belgium', 'Switzerland', 'Austria', 'Portugal', 'Greece', 'Czech Republic',
    'Argentina', 'Chile', 'Colombia', 'Peru', 'Venezuela', 'Pakistan',
    'Bangladesh', 'Sri Lanka', 'Nepal', 'Other'
  ];
  
  // Form states
  const [accountForm, setAccountForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    country: user?.country || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const [notifications, setNotifications] = useState({
    emailContests: true,
    emailNewArtwork: false,
    emailWeeklyDigest: true,
    pushContests: true,
    pushAchievements: true,
    pushReminders: false
  });
  
  const [privacy, setPrivacy] = useState({
    profilePublic: true,
    showInLeaderboard: true,
    showArtwork: true,
    allowMessages: false
  });
  
  const [appearance, setAppearance] = useState({
    theme: 'light',
    fontSize: 'medium',
    animations: true,
    soundEffects: true
  });
  
  const [parental, setParental] = useState({
    screenTimeLimit: 60,
    contestsAllowed: true,
    chatEnabled: false,
    requireApproval: true
  });
  
  // Admin settings
  const [platform, setPlatform] = useState({
    siteName: 'ColorArena',
    maintenanceMode: false,
    registrationEnabled: true,
    maxUploadSize: 10,
    defaultAgeGroup: '9-12'
  });
  
  const [emailTemplates, setEmailTemplates] = useState({
    welcomeEmail: true,
    contestReminder: true,
    weeklyDigest: true,
    parentalConsent: true
  });
  
  const [apiSettings, setApiSettings] = useState({
    rateLimit: 1000,
    webhooksEnabled: false,
    apiKey: 'sk_live_xxxxxxxxxxxxxxxxxxxxx'
  });

  const userTabs = [
    { id: 'account', label: 'Account', icon: '👤' },
    { id: 'notifications', label: 'Notifications', icon: '🔔' },
    { id: 'privacy', label: 'Privacy', icon: '🔒' },
    { id: 'appearance', label: 'Appearance', icon: '🎨' },
    ...(user?.age && user.age < 13 ? [{ id: 'parental', label: 'Parental Controls', icon: '👨‍👩‍👧' }] : [])
  ];

  const adminTabs = [
    { id: 'account', label: 'Account', icon: '👤' },
    { id: 'platform', label: 'Platform', icon: '⚙️' },
    { id: 'users', label: 'User Management', icon: '👥' },
    { id: 'content', label: 'Content Moderation', icon: '🛡️' },
    { id: 'emails', label: 'Email Templates', icon: '📧' },
    { id: 'api', label: 'API & Integrations', icon: '🔌' },
    { id: 'security', label: 'Security', icon: '🔐' },
    { id: 'backup', label: 'Backup & Export', icon: '💾' }
  ];

  const tabs = user?.isAdmin ? adminTabs : userTabs;

  const handleSave = () => {
    // Update user data including country
    if (onUpdateUser) {
      onUpdateUser({
        name: accountForm.name,
        country: accountForm.country,
      });
    }
    setShowSaveNotification(true);
    setTimeout(() => setShowSaveNotification(false), 3000);
  };

  const handleDeleteAccount = () => {
    setShowDeleteModal(false);
    onLogout();
    onNavigate('home');
  };

  const renderAccountSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Profile Information</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
            <input
              type="text"
              value={accountForm.name}
              onChange={(e) => setAccountForm({ ...accountForm, name: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
            <input
              type="email"
              value={accountForm.email}
              onChange={(e) => setAccountForm({ ...accountForm, email: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
        </div>
        
        {/* Country Selection - Important for Leaderboard */}
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Country <span className="text-xs text-gray-500">(Used for leaderboard rankings)</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xl">🌍</span>
            <select
              value={accountForm.country}
              onChange={(e) => setAccountForm({ ...accountForm, country: e.target.value })}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none bg-white"
            >
              <option value="">Select your country</option>
              {countries.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
          {!accountForm.country && (
            <p className="text-amber-600 text-sm mt-2 flex items-center gap-1">
              <span>⚠️</span>
              Set your country to appear in country-specific leaderboard rankings
            </p>
          )}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Change Password</h3>
        <div className="space-y-4 max-w-md">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
            <input
              type="password"
              value={accountForm.currentPassword}
              onChange={(e) => setAccountForm({ ...accountForm, currentPassword: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="••••••••"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
            <input
              type="password"
              value={accountForm.newPassword}
              onChange={(e) => setAccountForm({ ...accountForm, newPassword: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="••••••••"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
            <input
              type="password"
              value={accountForm.confirmPassword}
              onChange={(e) => setAccountForm({ ...accountForm, confirmPassword: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="••••••••"
            />
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-red-600 mb-4">Danger Zone</h3>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-red-800">Delete Account</p>
              <p className="text-sm text-red-600">Permanently delete your account and all associated data</p>
            </div>
            <button
              onClick={() => setShowDeleteModal(true)}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Email Notifications</h3>
        <div className="space-y-3">
          {[
            { key: 'emailContests', label: 'Contest announcements and reminders', desc: 'Get notified about new contests and deadlines' },
            { key: 'emailNewArtwork', label: 'New artwork added', desc: 'Be the first to know when new coloring pages are available' },
            { key: 'emailWeeklyDigest', label: 'Weekly digest', desc: 'A summary of your activity and achievements' }
          ].map((item) => (
            <label key={item.key} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
              <input
                type="checkbox"
                checked={notifications[item.key as keyof typeof notifications]}
                onChange={(e) => setNotifications({ ...notifications, [item.key]: e.target.checked })}
                className="mt-1 w-5 h-5 text-green-600 rounded focus:ring-green-500"
              />
              <div>
                <p className="font-medium text-gray-800">{item.label}</p>
                <p className="text-sm text-gray-500">{item.desc}</p>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Push Notifications</h3>
        <div className="space-y-3">
          {[
            { key: 'pushContests', label: 'Live contest alerts', desc: 'Get notified when contests start' },
            { key: 'pushAchievements', label: 'Achievement unlocked', desc: 'Celebrate when you earn new badges' },
            { key: 'pushReminders', label: 'Daily streak reminders', desc: 'Reminder to maintain your streak' }
          ].map((item) => (
            <label key={item.key} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
              <input
                type="checkbox"
                checked={notifications[item.key as keyof typeof notifications]}
                onChange={(e) => setNotifications({ ...notifications, [item.key]: e.target.checked })}
                className="mt-1 w-5 h-5 text-green-600 rounded focus:ring-green-500"
              />
              <div>
                <p className="font-medium text-gray-800">{item.label}</p>
                <p className="text-sm text-gray-500">{item.desc}</p>
              </div>
            </label>
          ))}
        </div>
      </div>
    </div>
  );

  const renderPrivacySettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Profile Visibility</h3>
        <div className="space-y-3">
          {[
            { key: 'profilePublic', label: 'Public profile', desc: 'Allow others to view your profile' },
            { key: 'showInLeaderboard', label: 'Show in leaderboard', desc: 'Display your name in public rankings' },
            { key: 'showArtwork', label: 'Public artwork gallery', desc: 'Allow others to view your colored artwork' },
            { key: 'allowMessages', label: 'Allow messages', desc: 'Let other users send you messages' }
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-800">{item.label}</p>
                <p className="text-sm text-gray-500">{item.desc}</p>
              </div>
              <button
                onClick={() => setPrivacy({ ...privacy, [item.key]: !privacy[item.key as keyof typeof privacy] })}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  privacy[item.key as keyof typeof privacy] ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                    privacy[item.key as keyof typeof privacy] ? 'translate-x-8' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Data & Privacy</h3>
        <div className="space-y-3">
          <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <div className="text-left">
              <p className="font-medium text-gray-800">Download my data</p>
              <p className="text-sm text-gray-500">Get a copy of all your data in JSON format</p>
            </div>
            <span className="text-2xl">📥</span>
          </button>
          <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <div className="text-left">
              <p className="font-medium text-gray-800">Privacy policy</p>
              <p className="text-sm text-gray-500">Read our privacy policy</p>
            </div>
            <span className="text-2xl">📄</span>
          </button>
        </div>
      </div>
    </div>
  );

  const renderAppearanceSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Theme</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            { value: 'light', label: 'Light', icon: '☀️', bg: 'bg-white border-gray-200' },
            { value: 'dark', label: 'Dark', icon: '🌙', bg: 'bg-gray-800 border-gray-700' },
            { value: 'auto', label: 'System', icon: '💻', bg: 'bg-gradient-to-r from-white to-gray-800 border-gray-400' }
          ].map((theme) => (
            <button
              key={theme.value}
              onClick={() => setAppearance({ ...appearance, theme: theme.value })}
              className={`p-4 rounded-xl border-2 transition-all ${
                appearance.theme === theme.value
                  ? 'border-green-500 ring-2 ring-green-200'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className={`w-full h-16 rounded-lg mb-3 ${theme.bg} border`} />
              <div className="flex items-center justify-center gap-2">
                <span>{theme.icon}</span>
                <span className="font-medium">{theme.label}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Font Size</h3>
        <div className="flex gap-3">
          {['small', 'medium', 'large'].map((size) => (
            <button
              key={size}
              onClick={() => setAppearance({ ...appearance, fontSize: size })}
              className={`flex-1 py-3 px-4 rounded-lg border-2 font-medium capitalize transition-all ${
                appearance.fontSize === size
                  ? 'border-green-500 bg-green-50 text-green-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              style={{ fontSize: size === 'small' ? '14px' : size === 'large' ? '18px' : '16px' }}
            >
              {size}
            </button>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Effects</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Animations</p>
              <p className="text-sm text-gray-500">Enable smooth animations and transitions</p>
            </div>
            <button
              onClick={() => setAppearance({ ...appearance, animations: !appearance.animations })}
              className={`relative w-14 h-7 rounded-full transition-colors ${
                appearance.animations ? 'bg-green-500' : 'bg-gray-300'
              }`}
            >
              <span
                className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                  appearance.animations ? 'translate-x-8' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Sound Effects</p>
              <p className="text-sm text-gray-500">Play sounds for achievements and actions</p>
            </div>
            <button
              onClick={() => setAppearance({ ...appearance, soundEffects: !appearance.soundEffects })}
              className={`relative w-14 h-7 rounded-full transition-colors ${
                appearance.soundEffects ? 'bg-green-500' : 'bg-gray-300'
              }`}
            >
              <span
                className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                  appearance.soundEffects ? 'translate-x-8' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderParentalSettings = () => (
    <div className="space-y-6">
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
        <div className="flex items-start gap-3">
          <span className="text-2xl">👨‍👩‍👧</span>
          <div>
            <p className="font-medium text-amber-800">Parental Controls</p>
            <p className="text-sm text-amber-700">These settings can only be changed by a parent or guardian with the parental PIN.</p>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Screen Time</h3>
        <div className="p-4 bg-gray-50 rounded-lg">
          <label className="block text-sm font-medium text-gray-700 mb-2">Daily time limit (minutes)</label>
          <input
            type="range"
            min="15"
            max="180"
            step="15"
            value={parental.screenTimeLimit}
            onChange={(e) => setParental({ ...parental, screenTimeLimit: parseInt(e.target.value) })}
            className="w-full accent-green-500"
          />
          <div className="flex justify-between text-sm text-gray-500 mt-1">
            <span>15 min</span>
            <span className="font-medium text-green-600">{parental.screenTimeLimit} minutes</span>
            <span>3 hours</span>
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Features</h3>
        <div className="space-y-3">
          {[
            { key: 'contestsAllowed', label: 'Allow contests', desc: 'Let your child participate in coloring contests' },
            { key: 'chatEnabled', label: 'Enable chat', desc: 'Allow messaging with other users (monitored)' },
            { key: 'requireApproval', label: 'Require approval', desc: 'Approve artwork before public sharing' }
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-800">{item.label}</p>
                <p className="text-sm text-gray-500">{item.desc}</p>
              </div>
              <button
                onClick={() => setParental({ ...parental, [item.key]: !parental[item.key as keyof typeof parental] })}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  parental[item.key as keyof typeof parental] ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                    parental[item.key as keyof typeof parental] ? 'translate-x-8' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Parental PIN</h3>
        <button className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors">
          Change Parental PIN
        </button>
      </div>
    </div>
  );

  // Admin-specific settings
  const renderPlatformSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">General Settings</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Site Name</label>
            <input
              type="text"
              value={platform.siteName}
              onChange={(e) => setPlatform({ ...platform, siteName: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
            />
          </div>
          <Select
            label="Default Age Group"
            options={[
              { value: '6-8', label: '6-8 years' },
              { value: '9-12', label: '9-12 years' },
              { value: '13-17', label: '13-17 years' }
            ]}
            value={platform.defaultAgeGroup}
            onChange={(value) => setPlatform({ ...platform, defaultAgeGroup: value })}
          />
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Max Upload Size (MB)</label>
            <input
              type="number"
              value={platform.maxUploadSize}
              onChange={(e) => setPlatform({ ...platform, maxUploadSize: parseInt(e.target.value) })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
            />
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Platform Status</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Maintenance Mode</p>
              <p className="text-sm text-gray-500">Temporarily disable the platform for maintenance</p>
            </div>
            <button
              onClick={() => setPlatform({ ...platform, maintenanceMode: !platform.maintenanceMode })}
              className={`relative w-14 h-7 rounded-full transition-colors ${
                platform.maintenanceMode ? 'bg-red-500' : 'bg-gray-300'
              }`}
            >
              <span
                className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                  platform.maintenanceMode ? 'translate-x-8' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Registration Enabled</p>
              <p className="text-sm text-gray-500">Allow new users to sign up</p>
            </div>
            <button
              onClick={() => setPlatform({ ...platform, registrationEnabled: !platform.registrationEnabled })}
              className={`relative w-14 h-7 rounded-full transition-colors ${
                platform.registrationEnabled ? 'bg-green-500' : 'bg-gray-300'
              }`}
            >
              <span
                className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                  platform.registrationEnabled ? 'translate-x-8' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderUserManagement = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-800">User Management</h3>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Search users..."
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
          />
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            Search
          </button>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-8 text-center">
        <span className="text-6xl mb-4 block">👥</span>
        <p className="text-gray-600">Connect to Supabase to manage users</p>
        <p className="text-sm text-gray-500 mt-2">User data will appear here once the backend is connected</p>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Bulk Actions</h3>
        <div className="flex gap-3">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Export Users CSV
          </button>
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Send Mass Email
          </button>
          <button className="px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50">
            Purge Inactive Users
          </button>
        </div>
      </div>
    </div>
  );

  const renderContentModeration = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Pending Review</h3>
        <div className="bg-gray-50 rounded-lg p-8 text-center">
          <span className="text-6xl mb-4 block">🛡️</span>
          <p className="text-gray-600">No content pending review</p>
          <p className="text-sm text-gray-500 mt-2">User-submitted artwork will appear here for approval</p>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Moderation Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Auto-approve verified users</p>
              <p className="text-sm text-gray-500">Skip review for users with good standing</p>
            </div>
            <button className="relative w-14 h-7 rounded-full bg-green-500">
              <span className="absolute top-1 translate-x-8 w-5 h-5 bg-white rounded-full shadow" />
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">AI content filter</p>
              <p className="text-sm text-gray-500">Automatically flag inappropriate content</p>
            </div>
            <button className="relative w-14 h-7 rounded-full bg-green-500">
              <span className="absolute top-1 translate-x-8 w-5 h-5 bg-white rounded-full shadow" />
            </button>
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Reported Content</h3>
        <div className="text-center py-6 text-gray-500">
          No reported content at this time
        </div>
      </div>
    </div>
  );

  const renderEmailTemplates = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Email Templates</h3>
        <div className="space-y-3">
          {[
            { key: 'welcomeEmail', label: 'Welcome Email', desc: 'Sent when a new user signs up' },
            { key: 'contestReminder', label: 'Contest Reminder', desc: 'Sent 24 hours before contest starts' },
            { key: 'weeklyDigest', label: 'Weekly Digest', desc: 'Weekly summary of platform activity' },
            { key: 'parentalConsent', label: 'Parental Consent', desc: 'Sent for users under 13' }
          ].map((template) => (
            <div key={template.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-4">
                <span className="text-2xl">📧</span>
                <div>
                  <p className="font-medium text-gray-800">{template.label}</p>
                  <p className="text-sm text-gray-500">{template.desc}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setEmailTemplates({ ...emailTemplates, [template.key]: !emailTemplates[template.key as keyof typeof emailTemplates] })}
                  className={`relative w-14 h-7 rounded-full transition-colors ${
                    emailTemplates[template.key as keyof typeof emailTemplates] ? 'bg-green-500' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                      emailTemplates[template.key as keyof typeof emailTemplates] ? 'translate-x-8' : 'translate-x-1'
                    }`}
                  />
                </button>
                <button className="px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-100">
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">SendGrid Configuration</h3>
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-amber-800">⚠️ Configure SendGrid API key in environment variables</p>
        </div>
      </div>
    </div>
  );

  const renderApiSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">API Configuration</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">API Key</label>
            <div className="flex gap-2">
              <input
                type="password"
                value={apiSettings.apiKey}
                readOnly
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
              />
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                Show
              </button>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                Regenerate
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Rate Limit (requests/hour)</label>
            <input
              type="number"
              value={apiSettings.rateLimit}
              onChange={(e) => setApiSettings({ ...apiSettings, rateLimit: parseInt(e.target.value) })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
            />
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Integrations</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {[
            { name: 'Cloudinary', status: 'connected', icon: '☁️' },
            { name: 'Auth0', status: 'connected', icon: '🔐' },
            { name: 'Supabase', status: 'pending', icon: '🗄️' },
            { name: 'Stripe', status: 'not connected', icon: '💳' },
            { name: 'SendGrid', status: 'not connected', icon: '📧' },
            { name: 'Redis', status: 'pending', icon: '⚡' }
          ].map((integration) => (
            <div key={integration.name} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{integration.icon}</span>
                <span className="font-medium">{integration.name}</span>
              </div>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                integration.status === 'connected' 
                  ? 'bg-green-100 text-green-700'
                  : integration.status === 'pending'
                  ? 'bg-amber-100 text-amber-700'
                  : 'bg-gray-200 text-gray-600'
              }`}>
                {integration.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div>
            <p className="font-medium text-gray-800">Webhooks</p>
            <p className="text-sm text-gray-500">Enable webhook notifications for events</p>
          </div>
          <button
            onClick={() => setApiSettings({ ...apiSettings, webhooksEnabled: !apiSettings.webhooksEnabled })}
            className={`relative w-14 h-7 rounded-full transition-colors ${
              apiSettings.webhooksEnabled ? 'bg-green-500' : 'bg-gray-300'
            }`}
          >
            <span
              className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                apiSettings.webhooksEnabled ? 'translate-x-8' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Authentication</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Two-Factor Authentication</p>
              <p className="text-sm text-gray-500">Require 2FA for admin accounts</p>
            </div>
            <button className="relative w-14 h-7 rounded-full bg-green-500">
              <span className="absolute top-1 translate-x-8 w-5 h-5 bg-white rounded-full shadow" />
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">Session Timeout</p>
              <p className="text-sm text-gray-500">Auto logout after inactivity</p>
            </div>
            <select className="px-3 py-2 border border-gray-300 rounded-lg">
              <option>30 minutes</option>
              <option>1 hour</option>
              <option>4 hours</option>
              <option>Never</option>
            </select>
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Security Logs</h3>
        <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm text-green-400 h-48 overflow-auto">
          <p>[2024-01-15 10:23:45] Admin login successful - admin@colorarena.com</p>
          <p>[2024-01-15 09:15:32] New contest created - Winter Wonderland</p>
          <p>[2024-01-14 18:42:11] User export completed - 1,245 records</p>
          <p>[2024-01-14 14:08:55] API key regenerated</p>
          <p>[2024-01-14 12:30:00] Platform backup completed</p>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">IP Whitelist</h3>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Enter IP address"
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg"
          />
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            Add IP
          </button>
        </div>
      </div>
    </div>
  );

  const renderBackupSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Backup Schedule</h3>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { label: 'Daily', time: '3:00 AM UTC', active: true },
            { label: 'Weekly', time: 'Sunday 3:00 AM UTC', active: true },
            { label: 'Monthly', time: '1st of month 3:00 AM UTC', active: false }
          ].map((backup) => (
            <div key={backup.label} className={`p-4 rounded-lg border-2 ${
              backup.active ? 'border-green-500 bg-green-50' : 'border-gray-200 bg-gray-50'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">{backup.label}</span>
                <span className={`w-3 h-3 rounded-full ${backup.active ? 'bg-green-500' : 'bg-gray-300'}`} />
              </div>
              <p className="text-sm text-gray-500">{backup.time}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Export Data</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <button className="flex items-center justify-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <span className="text-3xl">📊</span>
            <div className="text-left">
              <p className="font-medium">Export Analytics</p>
              <p className="text-sm text-gray-500">Download platform analytics</p>
            </div>
          </button>
          <button className="flex items-center justify-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <span className="text-3xl">👥</span>
            <div className="text-left">
              <p className="font-medium">Export Users</p>
              <p className="text-sm text-gray-500">Download user database</p>
            </div>
          </button>
          <button className="flex items-center justify-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <span className="text-3xl">🎨</span>
            <div className="text-left">
              <p className="font-medium">Export Artworks</p>
              <p className="text-sm text-gray-500">Download all artwork data</p>
            </div>
          </button>
          <button className="flex items-center justify-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <span className="text-3xl">🏆</span>
            <div className="text-left">
              <p className="font-medium">Export Contests</p>
              <p className="text-sm text-gray-500">Download contest history</p>
            </div>
          </button>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Manual Backup</h3>
        <button className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2">
          <span>💾</span>
          Create Backup Now
        </button>
        <p className="text-sm text-gray-500 mt-2">Last backup: 2 hours ago</p>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'account':
        return renderAccountSettings();
      case 'notifications':
        return renderNotificationSettings();
      case 'privacy':
        return renderPrivacySettings();
      case 'appearance':
        return renderAppearanceSettings();
      case 'parental':
        return renderParentalSettings();
      case 'platform':
        return renderPlatformSettings();
      case 'users':
        return renderUserManagement();
      case 'content':
        return renderContentModeration();
      case 'emails':
        return renderEmailTemplates();
      case 'api':
        return renderApiSettings();
      case 'security':
        return renderSecuritySettings();
      case 'backup':
        return renderBackupSettings();
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <button
            onClick={() => onNavigate('profile')}
            className="flex items-center gap-2 text-gray-600 hover:text-green-600 transition-colors mb-4"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Profile
          </button>
          <h1 className="text-3xl font-bold text-gray-800">
            {user?.isAdmin ? '⚙️ Admin Settings' : '⚙️ Settings'}
          </h1>
          <p className="text-gray-600 mt-1">
            {user?.isAdmin ? 'Manage platform settings and configuration' : 'Manage your account preferences'}
          </p>
        </motion.div>

        {/* Settings Layout */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:w-64 flex-shrink-0"
          >
            <div className="bg-white rounded-2xl shadow-lg p-4 sticky top-4">
              <nav className="space-y-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as SettingsTab)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                      activeTab === tab.id
                        ? 'bg-green-100 text-green-700 font-medium'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <span className="text-xl">{tab.icon}</span>
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex-1"
          >
            <div className="bg-white rounded-2xl shadow-lg p-6 lg:p-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {renderTabContent()}
                </motion.div>
              </AnimatePresence>

              {/* Save Button */}
              <div className="mt-8 pt-6 border-t flex items-center justify-between">
                <p className="text-sm text-gray-500">Changes are saved automatically</p>
                <button
                  onClick={handleSave}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Save Changes
                </button>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Save Notification */}
        <AnimatePresence>
          {showSaveNotification && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="fixed bottom-8 right-8 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Settings saved successfully!
            </motion.div>
          )}
        </AnimatePresence>

        {/* Delete Account Modal */}
        <AnimatePresence>
          {showDeleteModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
              onClick={() => setShowDeleteModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl"
              >
                <div className="text-center">
                  <span className="text-6xl mb-4 block">⚠️</span>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Delete Account?</h3>
                  <p className="text-gray-600 mb-6">
                    This action cannot be undone. All your data, artwork, and achievements will be permanently deleted.
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowDeleteModal(false)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleDeleteAccount}
                      className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                    >
                      Delete Account
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
