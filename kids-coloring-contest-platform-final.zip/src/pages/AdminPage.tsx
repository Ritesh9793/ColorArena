import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Trash2,
  Edit3,
  Save,
  X,
  Trophy,
  Palette,
  Calendar,
  Clock,
  Users,
  Star,
  Image,
  AlertCircle,
  CheckCircle,
  Upload,
  Sparkles
} from 'lucide-react';
import { Select } from '../components/ui/Select';
import { DatePicker } from '../components/ui/datepicker';

type Contest = {
  id: string;
  title: string;
  description: string;
  startDate: Date;
  endDate: Date;
  timeLimit: number;
  ageGroup: string;
  difficulty: string;
  maxParticipants: number;
  prizes: string;
  status: 'draft' | 'scheduled' | 'live' | 'ended';
};

type PracticeActivity = {
  id: string;
  title: string;
  category: string;
  difficulty: string;
  ageGroup: string;
  timeEstimate: number;
  colorCount: number;
  xpReward: number;
  imageUrl: string;
  status: 'draft' | 'published';
  isPremium: boolean;
};

const ageGroupOptions = [
  { value: '6-8', label: '6-8 years' },
  { value: '9-12', label: '9-12 years' },
  { value: '13-17', label: '13-17 years' },
  { value: 'all', label: 'All Ages' }
];

const difficultyOptions = [
  { value: 'Easy', label: 'Easy' },
  { value: 'Medium', label: 'Medium' },
  { value: 'Hard', label: 'Hard' }
];

const categoryOptions = [
  { value: 'Animals', label: 'Animals' },
  { value: 'Nature', label: 'Nature' },
  { value: 'Fantasy', label: 'Fantasy' },
  { value: 'Vehicles', label: 'Vehicles' },
  { value: 'Food', label: 'Food' },
  { value: 'Space', label: 'Space' },
  { value: 'Ocean', label: 'Ocean' },
  { value: 'Holidays', label: 'Holidays' }
];

// Premium checkbox is used in the activity form

export function AdminPage() {
  const [activeTab, setActiveTab] = useState<'contests' | 'practice'>('contests');
  const [contests, setContests] = useState<Contest[]>([]);
  const [activities, setActivities] = useState<PracticeActivity[]>([]);
  const [showContestForm, setShowContestForm] = useState(false);
  const [showActivityForm, setShowActivityForm] = useState(false);
  const [editingContest, setEditingContest] = useState<Contest | null>(null);
  const [editingActivity, setEditingActivity] = useState<PracticeActivity | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Contest Form State
  const [contestForm, setContestForm] = useState<{
    title: string;
    description: string;
    startDate: Date | undefined;
    endDate: Date | undefined;
    timeLimit: number;
    ageGroup: string;
    difficulty: string;
    maxParticipants: number;
    prizes: string;
  }>({
    title: '',
    description: '',
    startDate: undefined,
    endDate: undefined,
    timeLimit: 30,
    ageGroup: '6-8',
    difficulty: 'Easy',
    maxParticipants: 100,
    prizes: ''
  });

  // Activity Form State
  const [activityForm, setActivityForm] = useState({
    title: '',
    category: 'Animals',
    difficulty: 'Easy',
    ageGroup: '6-8',
    timeEstimate: 15,
    colorCount: 5,
    xpReward: 100,
    imageUrl: '',
    isPremium: false
  });

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const handleCreateContest = () => {
    if (!contestForm.title || !contestForm.startDate || !contestForm.endDate) {
      showNotification('error', 'Please fill in all required fields');
      return;
    }

    const newContest: Contest = {
      id: Date.now().toString(),
      title: contestForm.title,
      description: contestForm.description,
      startDate: contestForm.startDate,
      endDate: contestForm.endDate,
      timeLimit: contestForm.timeLimit,
      ageGroup: contestForm.ageGroup,
      difficulty: contestForm.difficulty,
      maxParticipants: contestForm.maxParticipants,
      prizes: contestForm.prizes,
      status: 'scheduled'
    };

    if (editingContest) {
      setContests(contests.map(c => c.id === editingContest.id ? { ...newContest, id: editingContest.id } : c));
      showNotification('success', 'Contest updated successfully!');
    } else {
      setContests([...contests, newContest]);
      showNotification('success', 'Contest created successfully!');
    }

    setShowContestForm(false);
    setEditingContest(null);
    setContestForm({
      title: '',
      description: '',
      startDate: undefined,
      endDate: undefined,
      timeLimit: 30,
      ageGroup: '6-8',
      difficulty: 'Easy',
      maxParticipants: 100,
      prizes: ''
    });
  };

  const handleCreateActivity = () => {
    if (!activityForm.title || !activityForm.imageUrl) {
      showNotification('error', 'Please fill in all required fields');
      return;
    }

    const newActivity: PracticeActivity = {
      id: Date.now().toString(),
      ...activityForm,
      status: 'published'
    };

    if (editingActivity) {
      setActivities(activities.map(a => a.id === editingActivity.id ? { ...newActivity, id: editingActivity.id } : a));
      showNotification('success', 'Activity updated successfully!');
    } else {
      setActivities([...activities, newActivity]);
      showNotification('success', 'Practice activity created successfully!');
    }

    setShowActivityForm(false);
    setEditingActivity(null);
    setActivityForm({
      title: '',
      category: 'Animals',
      difficulty: 'Easy',
      ageGroup: '6-8',
      timeEstimate: 15,
      colorCount: 5,
      xpReward: 100,
      imageUrl: '',
      isPremium: false
    });
  };

  const handleEditContest = (contest: Contest) => {
    setEditingContest(contest);
    setContestForm({
      title: contest.title,
      description: contest.description,
      startDate: contest.startDate,
      endDate: contest.endDate,
      timeLimit: contest.timeLimit,
      ageGroup: contest.ageGroup,
      difficulty: contest.difficulty,
      maxParticipants: contest.maxParticipants,
      prizes: contest.prizes
    });
    setShowContestForm(true);
  };

  const handleEditActivity = (activity: PracticeActivity) => {
    setEditingActivity(activity);
    setActivityForm({
      title: activity.title,
      category: activity.category,
      difficulty: activity.difficulty,
      ageGroup: activity.ageGroup,
      timeEstimate: activity.timeEstimate,
      colorCount: activity.colorCount,
      xpReward: activity.xpReward,
      imageUrl: activity.imageUrl,
      isPremium: activity.isPremium
    });
    setShowActivityForm(true);
  };

  const handleDeleteContest = (id: string) => {
    setContests(contests.filter(c => c.id !== id));
    showNotification('success', 'Contest deleted successfully!');
  };

  const handleDeleteActivity = (id: string) => {
    setActivities(activities.filter(a => a.id !== id));
    showNotification('success', 'Activity deleted successfully!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-green-100 text-green-700 border-green-300';
      case 'scheduled': return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'draft': return 'bg-gray-100 text-gray-700 border-gray-300';
      case 'ended': return 'bg-red-100 text-red-700 border-red-300';
      case 'published': return 'bg-green-100 text-green-700 border-green-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-700';
      case 'Medium': return 'bg-yellow-100 text-yellow-700';
      case 'Hard': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
              <p className="text-gray-600">Manage contests and practice activities</p>
            </div>
          </div>
        </motion.div>

        {/* Notification */}
        <AnimatePresence>
          {notification && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`fixed top-24 right-4 z-50 p-4 rounded-xl shadow-lg flex items-center gap-3 ${
                notification.type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
              }`}
            >
              {notification.type === 'success' ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                <AlertCircle className="w-5 h-5" />
              )}
              {notification.message}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Trophy, label: 'Total Contests', value: contests.length, color: 'from-amber-500 to-orange-600' },
            { icon: Palette, label: 'Practice Activities', value: activities.length, color: 'from-green-500 to-emerald-600' },
            { icon: Users, label: 'Total Users', value: 0, color: 'from-blue-500 to-indigo-600' },
            { icon: Star, label: 'Submissions', value: 0, color: 'from-purple-500 to-pink-600' }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
              <p className="text-gray-500 text-sm">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('contests')}
            className={`px-6 py-3 rounded-xl font-medium transition-all flex items-center gap-2 ${
              activeTab === 'contests'
                ? 'bg-gray-900 text-white shadow-lg'
                : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <Trophy className="w-5 h-5" />
            Contests
          </button>
          <button
            onClick={() => setActiveTab('practice')}
            className={`px-6 py-3 rounded-xl font-medium transition-all flex items-center gap-2 ${
              activeTab === 'practice'
                ? 'bg-gray-900 text-white shadow-lg'
                : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <Palette className="w-5 h-5" />
            Practice Activities
          </button>
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'contests' ? (
            <motion.div
              key="contests"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              {/* Add Contest Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setEditingContest(null);
                  setContestForm({
                    title: '',
                    description: '',
                    startDate: undefined,
                    endDate: undefined,
                    timeLimit: 30,
                    ageGroup: '6-8',
                    difficulty: 'Easy',
                    maxParticipants: 100,
                    prizes: ''
                  });
                  setShowContestForm(true);
                }}
                className="mb-6 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl shadow-lg hover:shadow-xl transition-shadow flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Create New Contest
              </motion.button>

              {/* Contests List */}
              {contests.length === 0 ? (
                <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
                  <Trophy className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">No Contests Yet</h3>
                  <p className="text-gray-400">Create your first contest to get started!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {contests.map((contest, index) => (
                    <motion.div
                      key={contest.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-shadow"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold text-gray-800">{contest.title}</h3>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(contest.status)}`}>
                              {contest.status.charAt(0).toUpperCase() + contest.status.slice(1)}
                            </span>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(contest.difficulty)}`}>
                              {contest.difficulty}
                            </span>
                          </div>
                          <p className="text-gray-500 text-sm mb-3">{contest.description || 'No description'}</p>
                          <div className="flex items-center gap-6 text-sm text-gray-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {formatDate(contest.startDate)} - {formatDate(contest.endDate)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {contest.timeLimit} min
                            </span>
                            <span className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              Max {contest.maxParticipants}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleEditContest(contest)}
                            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-5 h-5 text-gray-500" />
                          </button>
                          <button
                            onClick={() => handleDeleteContest(contest.id)}
                            className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-5 h-5 text-red-500" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="practice"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              {/* Add Activity Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setEditingActivity(null);
                  setActivityForm({
                    title: '',
                    category: 'Animals',
                    difficulty: 'Easy',
                    ageGroup: '6-8',
                    timeEstimate: 15,
                    colorCount: 5,
                    xpReward: 100,
                    imageUrl: '',
                    isPremium: false
                  });
                  setShowActivityForm(true);
                }}
                className="mb-6 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl shadow-lg hover:shadow-xl transition-shadow flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add Practice Activity
              </motion.button>

              {/* Activities List */}
              {activities.length === 0 ? (
                <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
                  <Palette className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">No Activities Yet</h3>
                  <p className="text-gray-400">Add practice activities for users to enjoy!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activities.map((activity, index) => (
                    <motion.div
                      key={activity.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow"
                    >
                      <div className="h-40 bg-gradient-to-br from-green-100 to-emerald-100 flex items-center justify-center relative">
                        {activity.imageUrl ? (
                          <img src={activity.imageUrl} alt={activity.title} className="w-full h-full object-cover" />
                        ) : (
                          <Image className="w-16 h-16 text-green-300" />
                        )}
                        <span className={`absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(activity.status)}`}>
                          {activity.status}
                        </span>
                        {activity.isPremium && (
                          <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-amber-400 to-amber-500 text-white shadow-lg flex items-center gap-1">
                            👑 Premium
                          </span>
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-gray-800 mb-2">{activity.title}</h3>
                        <div className="flex items-center gap-2 mb-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(activity.difficulty)}`}>
                            {activity.difficulty}
                          </span>
                          <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                            {activity.category}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                          <span>{activity.timeEstimate} min</span>
                          <span>{activity.colorCount} colors</span>
                          <span className="text-green-600 font-medium">+{activity.xpReward} XP</span>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEditActivity(activity)}
                            className="flex-1 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors flex items-center justify-center gap-1"
                          >
                            <Edit3 className="w-4 h-4" />
                            Edit
                          </button>
                          <button
                            onClick={() => handleDeleteActivity(activity.id)}
                            className="py-2 px-3 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Contest Form Modal */}
        <AnimatePresence>
          {showContestForm && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
              onClick={() => setShowContestForm(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
              >
                <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-800">
                    {editingContest ? 'Edit Contest' : 'Create New Contest'}
                  </h2>
                  <button
                    onClick={() => setShowContestForm(false)}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Contest Title *</label>
                    <input
                      type="text"
                      value={contestForm.title}
                      onChange={(e) => setContestForm({ ...contestForm, title: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                      placeholder="Weekly Coloring Challenge"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea
                      value={contestForm.description}
                      onChange={(e) => setContestForm({ ...contestForm, description: e.target.value })}
                      rows={3}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400 resize-none"
                      placeholder="Describe the contest theme and rules..."
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <DatePicker
                      label="Start Date *"
                      value={contestForm.startDate}
                      onChange={(date) => setContestForm({ ...contestForm, startDate: date })}
                      placeholder="Select start date"
                      minDate={new Date()}
                    />
                    <DatePicker
                      label="End Date *"
                      value={contestForm.endDate}
                      onChange={(date) => setContestForm({ ...contestForm, endDate: date })}
                      placeholder="Select end date"
                      minDate={contestForm.startDate || new Date()}
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Time Limit (min)</label>
                      <input
                        type="number"
                        value={contestForm.timeLimit}
                        onChange={(e) => setContestForm({ ...contestForm, timeLimit: parseInt(e.target.value) })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                      />
                    </div>
                    <Select
                      label="Age Group"
                      options={ageGroupOptions}
                      value={contestForm.ageGroup}
                      onChange={(value) => setContestForm({ ...contestForm, ageGroup: value })}
                    />
                    <Select
                      label="Difficulty"
                      options={difficultyOptions}
                      value={contestForm.difficulty}
                      onChange={(value) => setContestForm({ ...contestForm, difficulty: value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Max Participants</label>
                      <input
                        type="number"
                        value={contestForm.maxParticipants}
                        onChange={(e) => setContestForm({ ...contestForm, maxParticipants: parseInt(e.target.value) })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Prizes</label>
                      <input
                        type="text"
                        value={contestForm.prizes}
                        onChange={(e) => setContestForm({ ...contestForm, prizes: e.target.value })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                        placeholder="1st: 1000 XP, 2nd: 500 XP"
                      />
                    </div>
                  </div>
                </div>
                <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
                  <button
                    onClick={() => setShowContestForm(false)}
                    className="px-6 py-3 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleCreateContest}
                    className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl shadow-lg flex items-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    {editingContest ? 'Update Contest' : 'Create Contest'}
                  </motion.button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Activity Form Modal */}
        <AnimatePresence>
          {showActivityForm && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
              onClick={() => setShowActivityForm(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
              >
                <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-800">
                    {editingActivity ? 'Edit Practice Activity' : 'Add Practice Activity'}
                  </h2>
                  <button
                    onClick={() => setShowActivityForm(false)}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Activity Title *</label>
                    <input
                      type="text"
                      value={activityForm.title}
                      onChange={(e) => setActivityForm({ ...activityForm, title: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                      placeholder="Cute Butterfly"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Image URL *</label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={activityForm.imageUrl}
                        onChange={(e) => setActivityForm({ ...activityForm, imageUrl: e.target.value })}
                        className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                        placeholder="https://example.com/outline.png"
                      />
                      <button className="px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center gap-2">
                        <Upload className="w-5 h-5" />
                        Upload
                      </button>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">Upload outline image to Cloudinary and paste URL</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <Select
                      label="Category"
                      options={categoryOptions}
                      value={activityForm.category}
                      onChange={(value) => setActivityForm({ ...activityForm, category: value })}
                    />
                    <Select
                      label="Difficulty"
                      options={difficultyOptions}
                      value={activityForm.difficulty}
                      onChange={(value) => setActivityForm({ ...activityForm, difficulty: value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <Select
                      label="Age Group"
                      options={ageGroupOptions}
                      value={activityForm.ageGroup}
                      onChange={(value) => setActivityForm({ ...activityForm, ageGroup: value })}
                    />
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Time Estimate (min)</label>
                      <input
                        type="number"
                        value={activityForm.timeEstimate}
                        onChange={(e) => setActivityForm({ ...activityForm, timeEstimate: parseInt(e.target.value) })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Number of Colors</label>
                      <input
                        type="number"
                        value={activityForm.colorCount}
                        onChange={(e) => setActivityForm({ ...activityForm, colorCount: parseInt(e.target.value) })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">XP Reward</label>
                      <input
                        type="number"
                        value={activityForm.xpReward}
                        onChange={(e) => setActivityForm({ ...activityForm, xpReward: parseInt(e.target.value) })}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-green-400"
                      />
                    </div>
                  </div>
                  
                  {/* Premium Checkbox */}
                  <div className="pt-2">
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <div className="relative">
                        <input
                          type="checkbox"
                          checked={activityForm.isPremium}
                          onChange={(e) => setActivityForm({ ...activityForm, isPremium: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-6 h-6 border-2 border-gray-300 rounded-lg peer-checked:border-amber-500 peer-checked:bg-amber-500 transition-all flex items-center justify-center">
                          {activityForm.isPremium && (
                            <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">👑</span>
                        <div>
                          <span className="font-medium text-gray-800">Premium Content</span>
                          <p className="text-xs text-gray-500">Only accessible to paid subscribers</p>
                        </div>
                      </div>
                    </label>
                  </div>
                </div>
                <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
                  <button
                    onClick={() => setShowActivityForm(false)}
                    className="px-6 py-3 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleCreateActivity}
                    className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl shadow-lg flex items-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    {editingActivity ? 'Update Activity' : 'Add Activity'}
                  </motion.button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
