import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Check,
  X,
  Crown,
  Sparkles,
  Zap,
  Star,
  Shield,
  Gift,
  Clock,
  Palette,
  Trophy,
  Users,
  ArrowLeft,
  CreditCard,
  Smartphone,
  Building,
  ChevronDown,
} from 'lucide-react';

interface SubscriptionPageProps {
  user: {
    id: string;
    name: string;
    avatar?: string;
    level: number;
    xp: number;
    badges: string[];
    isAdmin?: boolean;
    subscription?: {
      plan: 'free' | 'monthly' | 'quarterly' | 'halfYearly' | 'annual';
      startDate: Date;
      endDate: Date;
      trialEndsAt?: Date;
    };
  } | null;
  onNavigate: (page: string) => void;
  onUpdateUser: (user: any) => void;
}

const plans = [
  {
    id: 'free',
    name: 'Free Trial',
    price: 0,
    period: '14 days',
    description: 'Try ColorArena free for 14 days',
    color: 'gray',
    icon: Gift,
    features: [
      { text: 'Access to free tier practices', included: true },
      { text: '5 coloring pages per day', included: true },
      { text: 'Basic color palettes', included: true },
      { text: 'Community gallery access', included: true },
      { text: 'Premium practices', included: false },
      { text: 'Contest participation', included: false },
      { text: 'Unlimited downloads', included: false },
      { text: 'Ad-free experience', included: false },
    ],
    badge: 'Starter',
    savings: null,
  },
  {
    id: 'monthly',
    name: 'Monthly',
    price: 9.99,
    period: 'month',
    description: 'Perfect for trying premium features',
    color: 'green',
    icon: Zap,
    features: [
      { text: 'All free tier features', included: true },
      { text: 'Unlimited practices', included: true },
      { text: 'Premium color palettes', included: true },
      { text: 'Contest participation', included: true },
      { text: 'Unlimited downloads', included: true },
      { text: 'Ad-free experience', included: true },
      { text: 'Priority support', included: false },
      { text: 'Exclusive content', included: false },
    ],
    badge: 'Popular',
    savings: null,
  },
  {
    id: 'quarterly',
    name: 'Quarterly',
    price: 24.99,
    period: '3 months',
    description: 'Save 17% compared to monthly',
    color: 'emerald',
    icon: Star,
    features: [
      { text: 'All monthly features', included: true },
      { text: 'Priority support', included: true },
      { text: 'Early access to new content', included: true },
      { text: 'Monthly bonus XP', included: true },
      { text: 'Exclusive badges', included: true },
      { text: 'Custom color palettes', included: true },
      { text: 'Family sharing (2 members)', included: false },
      { text: 'Personal art coach', included: false },
    ],
    badge: 'Best Value',
    savings: '17%',
  },
  {
    id: 'halfYearly',
    name: 'Half-Yearly',
    price: 44.99,
    period: '6 months',
    description: 'Save 25% compared to monthly',
    color: 'teal',
    icon: Trophy,
    features: [
      { text: 'All quarterly features', included: true },
      { text: 'Family sharing (3 members)', included: true },
      { text: 'Exclusive workshops', included: true },
      { text: 'Certificate of completion', included: true },
      { text: 'Profile customization', included: true },
      { text: 'Advanced analytics', included: true },
      { text: 'Personal art coach', included: false },
      { text: 'Custom branded exports', included: false },
    ],
    badge: 'Great Deal',
    savings: '25%',
  },
  {
    id: 'annual',
    name: 'Annual',
    price: 79.99,
    period: 'year',
    description: 'Best value - Save 33%',
    color: 'yellow',
    icon: Crown,
    features: [
      { text: 'All half-yearly features', included: true },
      { text: 'Family sharing (5 members)', included: true },
      { text: 'Personal art coach session', included: true },
      { text: 'Custom branded exports', included: true },
      { text: 'VIP contest access', included: true },
      { text: 'Lifetime badge', included: true },
      { text: 'Early feature access', included: true },
      { text: 'Dedicated support line', included: true },
    ],
    badge: 'Premium',
    savings: '33%',
    popular: true,
  },
];

const paymentMethods = [
  { id: 'card', name: 'Credit/Debit Card', icon: CreditCard },
  { id: 'upi', name: 'UPI', icon: Smartphone },
  { id: 'netbanking', name: 'Net Banking', icon: Building },
];

export default function SubscriptionPage({ user, onNavigate, onUpdateUser }: SubscriptionPageProps) {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const currentPlan = user?.subscription?.plan || 'free';

  const handleSelectPlan = (planId: string) => {
    if (planId === 'free') return;
    setSelectedPlan(planId);
    setShowPaymentModal(true);
  };

  const handlePayment = async () => {
    setIsProcessing(true);
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const plan = plans.find(p => p.id === selectedPlan);
    if (plan && user) {
      const startDate = new Date();
      let endDate = new Date();
      
      switch (selectedPlan) {
        case 'monthly':
          endDate.setMonth(endDate.getMonth() + 1);
          break;
        case 'quarterly':
          endDate.setMonth(endDate.getMonth() + 3);
          break;
        case 'halfYearly':
          endDate.setMonth(endDate.getMonth() + 6);
          break;
        case 'annual':
          endDate.setFullYear(endDate.getFullYear() + 1);
          break;
      }

      onUpdateUser({
        ...user,
        subscription: {
          plan: selectedPlan as any,
          startDate,
          endDate,
        },
      });
    }

    setIsProcessing(false);
    setPaymentSuccess(true);
  };

  const faqs = [
    {
      question: 'Can I cancel my subscription anytime?',
      answer: 'Yes, you can cancel your subscription at any time. Your access will continue until the end of your billing period.',
    },
    {
      question: 'What happens after my free trial ends?',
      answer: 'After 14 days, you\'ll be limited to free tier practices only. Upgrade to any paid plan to continue enjoying premium features.',
    },
    {
      question: 'Can I switch between plans?',
      answer: 'Yes, you can upgrade or downgrade your plan at any time. The difference will be prorated.',
    },
    {
      question: 'Is there a family plan?',
      answer: 'Yes! Quarterly plans include sharing for 2 members, half-yearly for 3, and annual for 5 family members.',
    },
    {
      question: 'Do you offer refunds?',
      answer: 'We offer a 7-day money-back guarantee for all paid plans. Contact support for assistance.',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 via-white to-emerald-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('profile')}
            className="p-2 rounded-xl bg-white shadow-md hover:shadow-lg transition-shadow"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </motion.button>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Subscription Plans</h1>
            <p className="text-gray-600">Choose the perfect plan for your creative journey</p>
          </div>
        </div>

        {/* Current Plan Banner */}
        {user && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 p-4 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-500 text-white"
          >
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-xl">
                  <Crown className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-green-100 text-sm">Current Plan</p>
                  <p className="text-xl font-bold capitalize">
                    {currentPlan === 'free' ? 'Free Trial' : currentPlan.replace(/([A-Z])/g, ' $1')}
                  </p>
                </div>
              </div>
              {user.subscription?.endDate && (
                <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-xl">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">
                    {currentPlan === 'free' ? 'Trial ends' : 'Renews'}: {new Date(user.subscription.endDate).toLocaleDateString()}
                  </span>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-12">
          {plans.map((plan, index) => {
            const Icon = plan.icon;
            const isCurrentPlan = currentPlan === plan.id;
            const isPremium = plan.id === 'annual';

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`relative rounded-2xl overflow-hidden ${
                  isPremium 
                    ? 'bg-gradient-to-b from-yellow-400 via-yellow-500 to-orange-500 p-[2px]' 
                    : 'bg-white border-2 border-gray-100'
                }`}
              >
                {isPremium && (
                  <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-center py-1 text-xs font-bold">
                    ⭐ MOST POPULAR ⭐
                  </div>
                )}

                <div className={`h-full bg-white rounded-2xl p-6 ${isPremium ? 'pt-10' : ''}`}>
                  {/* Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      plan.color === 'gray' ? 'bg-gray-100 text-gray-600' :
                      plan.color === 'green' ? 'bg-green-100 text-green-600' :
                      plan.color === 'emerald' ? 'bg-emerald-100 text-emerald-600' :
                      plan.color === 'teal' ? 'bg-teal-100 text-teal-600' :
                      'bg-yellow-100 text-yellow-600'
                    }`}>
                      {plan.badge}
                    </span>
                    {plan.savings && (
                      <span className="px-2 py-1 bg-red-100 text-red-600 rounded-full text-xs font-bold">
                        Save {plan.savings}
                      </span>
                    )}
                  </div>

                  {/* Icon & Name */}
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`p-3 rounded-xl ${
                      plan.color === 'gray' ? 'bg-gray-100' :
                      plan.color === 'green' ? 'bg-green-100' :
                      plan.color === 'emerald' ? 'bg-emerald-100' :
                      plan.color === 'teal' ? 'bg-teal-100' :
                      'bg-yellow-100'
                    }`}>
                      <Icon className={`w-6 h-6 ${
                        plan.color === 'gray' ? 'text-gray-600' :
                        plan.color === 'green' ? 'text-green-600' :
                        plan.color === 'emerald' ? 'text-emerald-600' :
                        plan.color === 'teal' ? 'text-teal-600' :
                        'text-yellow-600'
                      }`} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">{plan.name}</h3>
                  </div>

                  {/* Price */}
                  <div className="mb-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-bold text-gray-800">
                        {plan.price === 0 ? 'Free' : `$${plan.price}`}
                      </span>
                      {plan.price > 0 && (
                        <span className="text-gray-500 text-sm">/{plan.period}</span>
                      )}
                    </div>
                    <p className="text-gray-500 text-sm mt-1">{plan.description}</p>
                  </div>

                  {/* Features */}
                  <ul className="space-y-2 mb-6">
                    {plan.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-start gap-2">
                        {feature.included ? (
                          <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        ) : (
                          <X className="w-4 h-4 text-gray-300 mt-0.5 flex-shrink-0" />
                        )}
                        <span className={`text-sm ${feature.included ? 'text-gray-700' : 'text-gray-400'}`}>
                          {feature.text}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <motion.button
                    whileHover={{ scale: plan.id === 'free' ? 1 : 1.02 }}
                    whileTap={{ scale: plan.id === 'free' ? 1 : 0.98 }}
                    onClick={() => handleSelectPlan(plan.id)}
                    disabled={isCurrentPlan || plan.id === 'free'}
                    className={`w-full py-3 rounded-xl font-semibold transition-all ${
                      isCurrentPlan
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : plan.id === 'free'
                        ? 'bg-gray-100 text-gray-500 cursor-default'
                        : isPremium
                        ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white hover:shadow-lg hover:shadow-yellow-200'
                        : 'bg-gradient-to-r from-green-500 to-emerald-500 text-white hover:shadow-lg hover:shadow-green-200'
                    }`}
                  >
                    {isCurrentPlan ? 'Current Plan' : plan.id === 'free' ? 'Default' : 'Subscribe'}
                  </motion.button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Features Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-2xl p-8 shadow-lg mb-12"
        >
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-yellow-500" />
            Why Go Premium?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Palette, title: 'Unlimited Practices', desc: 'Access all premium coloring pages' },
              { icon: Trophy, title: 'Join Contests', desc: 'Compete and win exciting prizes' },
              { icon: Users, title: 'Family Sharing', desc: 'Share with up to 5 family members' },
              { icon: Shield, title: 'Ad-Free', desc: 'Enjoy uninterrupted coloring' },
            ].map((item, index) => (
              <motion.div
                key={index}
                whileHover={{ y: -5 }}
                className="p-4 rounded-xl bg-gradient-to-br from-green-50 to-emerald-50 border border-green-100"
              >
                <item.icon className="w-8 h-8 text-green-500 mb-3" />
                <h3 className="font-semibold text-gray-800 mb-1">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* FAQs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-2xl p-8 shadow-lg"
        >
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Frequently Asked Questions</h2>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                className="border border-gray-100 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                  className="w-full p-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <span className="font-medium text-gray-800">{faq.question}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 transition-transform ${
                      expandedFaq === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence>
                  {expandedFaq === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="px-4 pb-4"
                    >
                      <p className="text-gray-600">{faq.answer}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Payment Modal */}
      <AnimatePresence>
        {showPaymentModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => !isProcessing && setShowPaymentModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-md overflow-hidden"
            >
              {paymentSuccess ? (
                <div className="p-8 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', bounce: 0.5 }}
                    className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
                  >
                    <Check className="w-10 h-10 text-green-500" />
                  </motion.div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">Payment Successful!</h3>
                  <p className="text-gray-600 mb-6">
                    Welcome to {plans.find(p => p.id === selectedPlan)?.name}! Enjoy your premium features.
                  </p>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      setShowPaymentModal(false);
                      setPaymentSuccess(false);
                      setSelectedPlan(null);
                    }}
                    className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold"
                  >
                    Start Coloring!
                  </motion.button>
                </div>
              ) : (
                <>
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-6 text-white">
                    <h3 className="text-xl font-bold">Complete Your Purchase</h3>
                    <p className="text-green-100">
                      {plans.find(p => p.id === selectedPlan)?.name} - ${plans.find(p => p.id === selectedPlan)?.price}
                    </p>
                  </div>

                  <div className="p-6">
                    <p className="text-sm text-gray-600 mb-4">Select payment method</p>

                    <div className="space-y-3 mb-6">
                      {paymentMethods.map(method => (
                        <motion.button
                          key={method.id}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setPaymentMethod(method.id)}
                          className={`w-full p-4 rounded-xl border-2 flex items-center gap-3 transition-all ${
                            paymentMethod === method.id
                              ? 'border-green-500 bg-green-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <method.icon className={`w-5 h-5 ${
                            paymentMethod === method.id ? 'text-green-500' : 'text-gray-400'
                          }`} />
                          <span className={paymentMethod === method.id ? 'text-green-700 font-medium' : 'text-gray-600'}>
                            {method.name}
                          </span>
                          {paymentMethod === method.id && (
                            <Check className="w-5 h-5 text-green-500 ml-auto" />
                          )}
                        </motion.button>
                      ))}
                    </div>

                    {paymentMethod === 'card' && (
                      <div className="space-y-4 mb-6">
                        <input
                          type="text"
                          placeholder="Card Number"
                          className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <input
                            type="text"
                            placeholder="MM/YY"
                            className="p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                          />
                          <input
                            type="text"
                            placeholder="CVV"
                            className="p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                          />
                        </div>
                      </div>
                    )}

                    {paymentMethod === 'upi' && (
                      <div className="mb-6">
                        <input
                          type="text"
                          placeholder="Enter UPI ID (e.g., name@upi)"
                          className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      </div>
                    )}

                    {paymentMethod === 'netbanking' && (
                      <div className="mb-6">
                        <select className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent">
                          <option value="">Select your bank</option>
                          <option value="sbi">State Bank of India</option>
                          <option value="hdfc">HDFC Bank</option>
                          <option value="icici">ICICI Bank</option>
                          <option value="axis">Axis Bank</option>
                        </select>
                      </div>
                    )}

                    <div className="flex gap-3">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setShowPaymentModal(false)}
                        disabled={isProcessing}
                        className="flex-1 py-3 border border-gray-200 rounded-xl font-semibold text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                      >
                        Cancel
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={handlePayment}
                        disabled={isProcessing}
                        className="flex-1 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {isProcessing ? (
                          <>
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                              className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                            />
                            Processing...
                          </>
                        ) : (
                          `Pay $${plans.find(p => p.id === selectedPlan)?.price}`
                        )}
                      </motion.button>
                    </div>

                    <p className="text-xs text-gray-400 text-center mt-4">
                      🔒 Secured by Stripe. Your payment information is encrypted.
                    </p>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
