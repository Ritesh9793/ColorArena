import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Calendar, Clock, Bell, BellOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

type Tab = 'live' | 'upcoming' | 'past';

export function ContestPage() {
  const [activeTab, setActiveTab] = useState<Tab>('live');
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  const tabs = [
    { id: 'live' as Tab, label: 'Live Contests', icon: '🔴' },
    { id: 'upcoming' as Tab, label: 'Upcoming', icon: '📅' },
    { id: 'past' as Tab, label: 'Past Contests', icon: '🏆' },
  ];

  const renderEmptyState = () => {
    const emptyStates = {
      live: {
        emoji: '🎨',
        title: 'No Live Contests',
        description: 'There are no live contests at the moment. Check back soon or enable notifications to be alerted when a new contest starts!'
      },
      upcoming: {
        emoji: '📅',
        title: 'No Upcoming Contests',
        description: 'New contests are being prepared. Enable notifications to be the first to know when they are announced!'
      },
      past: {
        emoji: '🏆',
        title: 'No Past Contests',
        description: 'Past contests and their results will appear here. Participate in contests to see your history!'
      }
    };

    const state = emptyStates[activeTab];

    return (
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="flex flex-col items-center justify-center py-16 text-center"
      >
        <motion.div
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ duration: 3, repeat: Infinity }}
          className="text-8xl mb-6"
        >
          {state.emoji}
        </motion.div>
        
        <h3 className="text-2xl font-bold text-gray-900 mb-2">
          {state.title}
        </h3>
        <p className="text-gray-500 mb-6 max-w-md">
          {state.description}
        </p>

        <Button
          onClick={() => setNotificationsEnabled(!notificationsEnabled)}
          variant={notificationsEnabled ? "secondary" : "default"}
          className="gap-2"
        >
          {notificationsEnabled ? (
            <>
              <BellOff className="w-5 h-5" />
              Notifications Enabled
            </>
          ) : (
            <>
              <Bell className="w-5 h-5" />
              Enable Notifications
            </>
          )}
        </Button>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Coloring <span className="text-green-600">Contests</span> 🏆
          </h1>
          <p className="text-xl text-gray-600">
            Compete with artists worldwide and win amazing prizes!
          </p>
        </motion.div>

        {/* Contest Info Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid md:grid-cols-3 gap-4 mb-8"
        >
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Trophy className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Weekly Prizes</p>
                <p className="text-xl font-bold text-gray-900">Badges & XP</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Contest Schedule</p>
                <p className="text-xl font-bold text-gray-900">Every Week</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-teal-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Time Limit</p>
                <p className="text-xl font-bold text-gray-900">30-60 mins</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl shadow-lg overflow-hidden"
        >
          {/* Tab Headers */}
          <div className="flex border-b border-gray-100">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-4 px-6 text-center font-medium transition-all relative ${
                  activeTab === tab.id
                    ? 'text-green-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-1 bg-green-500"
                  />
                )}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="p-6">
            <AnimatePresence mode="wait">
              {renderEmptyState()}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* How It Works */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-12 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-8"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            How Contests Work
          </h2>
          
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: 1, title: 'Register', description: 'Sign up for an upcoming contest', emoji: '📝' },
              { step: 2, title: 'Wait for Start', description: 'Contest starts at scheduled time', emoji: '⏰' },
              { step: 3, title: 'Color', description: 'Complete the artwork within time limit', emoji: '🎨' },
              { step: 4, title: 'Win Prizes', description: 'Top artists win badges and XP!', emoji: '🏆' },
            ].map((item) => (
              <motion.div
                key={item.step}
                whileHover={{ scale: 1.05, y: -5 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-white rounded-2xl shadow-lg mx-auto mb-4 flex items-center justify-center">
                  <span className="text-3xl">{item.emoji}</span>
                </div>
                <Badge variant="secondary" className="mb-2">Step {item.step}</Badge>
                <h3 className="font-bold text-gray-900">{item.title}</h3>
                <p className="text-sm text-gray-500">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
