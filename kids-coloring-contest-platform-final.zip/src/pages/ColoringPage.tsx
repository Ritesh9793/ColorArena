import { useState, useRef, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Palette, Undo, Redo, RotateCcw, Download, Save, 
  Clock, Trophy, Star, ChevronLeft, Sparkles, Eraser,
  PaintBucket, Minus, Plus, Check, X
} from 'lucide-react';
import type { User } from '../App';

type ColoringPageProps = {
  user: User;
};

const colorPalettes = {
  basic: ['#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#4B0082', '#8F00FF', '#FF1493', '#00CED1', '#FFD700'],
  pastel: ['#FFB3BA', '#FFDFBA', '#FFFFBA', '#BAFFC9', '#BAE1FF', '#E0BBE4', '#FEC8D8', '#D4A5A5', '#A5D4D4', '#D4D4A5'],
  neon: ['#FF0080', '#FF00FF', '#8000FF', '#0080FF', '#00FFFF', '#00FF80', '#80FF00', '#FFFF00', '#FF8000', '#FF0000'],
  earth: ['#8B4513', '#A0522D', '#D2691E', '#CD853F', '#DEB887', '#556B2F', '#6B8E23', '#808000', '#BDB76B', '#F5DEB3'],
  ocean: ['#001F3F', '#003366', '#004080', '#0059B3', '#0073E6', '#1A8CFF', '#4DA6FF', '#80BFFF', '#B3D9FF', '#E6F2FF'],
};

const brushSizes = [4, 8, 12, 20, 30, 40];

// SVG outline for coloring (simple design that works well)
const outlineSVG = `
<svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
  <!-- Sun -->
  <circle cx="320" cy="80" r="40" fill="none" stroke="#333" stroke-width="2"/>
  <line x1="320" y1="20" x2="320" y2="5" stroke="#333" stroke-width="2"/>
  <line x1="320" y1="140" x2="320" y2="155" stroke="#333" stroke-width="2"/>
  <line x1="260" y1="80" x2="245" y2="80" stroke="#333" stroke-width="2"/>
  <line x1="380" y1="80" x2="395" y2="80" stroke="#333" stroke-width="2"/>
  
  <!-- Cloud -->
  <ellipse cx="100" cy="60" rx="35" ry="25" fill="none" stroke="#333" stroke-width="2"/>
  <ellipse cx="140" cy="65" rx="30" ry="22" fill="none" stroke="#333" stroke-width="2"/>
  <ellipse cx="70" cy="70" rx="25" ry="18" fill="none" stroke="#333" stroke-width="2"/>
  
  <!-- Mountains -->
  <polygon points="0,300 100,180 200,300" fill="none" stroke="#333" stroke-width="2"/>
  <polygon points="120,300 220,150 320,300" fill="none" stroke="#333" stroke-width="2"/>
  <polygon points="250,300 330,200 400,300" fill="none" stroke="#333" stroke-width="2"/>
  
  <!-- Tree -->
  <rect x="50" y="320" width="20" height="50" fill="none" stroke="#333" stroke-width="2"/>
  <polygon points="60,320 20,280 100,280" fill="none" stroke="#333" stroke-width="2"/>
  <polygon points="60,295 30,260 90,260" fill="none" stroke="#333" stroke-width="2"/>
  <polygon points="60,270 40,240 80,240" fill="none" stroke="#333" stroke-width="2"/>
  
  <!-- House -->
  <rect x="280" y="310" width="80" height="60" fill="none" stroke="#333" stroke-width="2"/>
  <polygon points="280,310 320,270 360,310" fill="none" stroke="#333" stroke-width="2"/>
  <rect x="305" y="340" width="30" height="30" fill="none" stroke="#333" stroke-width="2"/>
  
  <!-- Flowers -->
  <circle cx="170" cy="360" r="8" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="162" cy="352" r="6" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="178" cy="352" r="6" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="162" cy="368" r="6" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="178" cy="368" r="6" fill="none" stroke="#333" stroke-width="2"/>
  <line x1="170" y1="375" x2="170" y2="400" stroke="#333" stroke-width="2"/>
  
  <circle cx="210" cy="365" r="6" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="204" cy="359" r="5" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="216" cy="359" r="5" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="204" cy="371" r="5" fill="none" stroke="#333" stroke-width="2"/>
  <circle cx="216" cy="371" r="5" fill="none" stroke="#333" stroke-width="2"/>
  <line x1="210" y1="376" x2="210" y2="400" stroke="#333" stroke-width="2"/>
  
  <!-- Ground -->
  <line x1="0" y1="370" x2="400" y2="370" stroke="#333" stroke-width="2"/>
</svg>
`;

export function ColoringPage({ user }: ColoringPageProps) {
  const { id } = useParams();
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentColor, setCurrentColor] = useState('#22c55e');
  const [brushSize, setBrushSize] = useState(12);
  const [activePalette, setActivePalette] = useState<keyof typeof colorPalettes>('basic');
  const [tool, setTool] = useState<'brush' | 'fill' | 'eraser'>('brush');
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [showSuccess, setShowSuccess] = useState(false);
  const [timeLeft, setTimeLeft] = useState(900); // 15 minutes for contest
  const [isContestMode] = useState(id?.includes('weekly') || id?.includes('c'));
  const [score, setScore] = useState(0);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = 400;
    canvas.height = 400;

    // White background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw SVG outline
    const img = new Image();
    const svgBlob = new Blob([outlineSVG], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(svgBlob);
    
    img.onload = () => {
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      saveToHistory();
    };
    img.src = url;
  }, []);

  // Contest timer
  useEffect(() => {
    if (!isContestMode) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          clearInterval(timer);
          setShowSuccess(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isContestMode]);

  const saveToHistory = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(imageData);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  const undo = () => {
    if (historyIndex > 0) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const newIndex = historyIndex - 1;
      ctx.putImageData(history[newIndex], 0, 0);
      setHistoryIndex(newIndex);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const newIndex = historyIndex + 1;
      ctx.putImageData(history[newIndex], 0, 0);
      setHistoryIndex(newIndex);
    }
  };

  const reset = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const img = new Image();
    const svgBlob = new Blob([outlineSVG], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(svgBlob);
    
    img.onload = () => {
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      saveToHistory();
    };
    img.src = url;
  };

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if ('touches' in e) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getPos(e);
    
    if (tool === 'fill') {
      // Simple flood fill would be complex, instead we just draw a larger circle
      ctx.beginPath();
      ctx.arc(x, y, brushSize * 2, 0, Math.PI * 2);
      ctx.fillStyle = currentColor;
      ctx.fill();
      saveToHistory();
      return;
    }

    setIsDrawing(true);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = brushSize;
    ctx.strokeStyle = tool === 'eraser' ? '#FFFFFF' : currentColor;
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || tool === 'fill') return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getPos(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      saveToHistory();
      setScore((prev) => prev + 1);
    }
  };

  const downloadImage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = 'my-coloring-masterpiece.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const submitEntry = () => {
    setShowSuccess(true);
    setScore((prev) => prev + 100);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen py-4 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-4"
        >
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-green-600 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
            Back
          </button>

          {isContestMode && (
            <div className="flex items-center gap-4">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-full font-bold ${
                timeLeft < 60 ? 'bg-red-100 text-red-600 animate-pulse' : 'bg-green-100 text-green-600'
              }`}>
                <Clock className="w-5 h-5" />
                {formatTime(timeLeft)}
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-yellow-100 text-yellow-700 rounded-full font-bold">
                <Star className="w-5 h-5" />
                {score} pts
              </div>
            </div>
          )}
        </motion.div>

        <div className="grid lg:grid-cols-[1fr,300px] gap-6">
          {/* Canvas Area */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl shadow-xl p-4 md:p-6"
          >
            {/* Toolbar */}
            <div className="flex flex-wrap items-center gap-2 mb-4 pb-4 border-b border-gray-100">
              <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setTool('brush')}
                  className={`p-2 rounded-lg transition-colors ${tool === 'brush' ? 'bg-green-500 text-white' : 'hover:bg-gray-200'}`}
                  title="Brush"
                >
                  <Palette className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setTool('fill')}
                  className={`p-2 rounded-lg transition-colors ${tool === 'fill' ? 'bg-green-500 text-white' : 'hover:bg-gray-200'}`}
                  title="Fill"
                >
                  <PaintBucket className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setTool('eraser')}
                  className={`p-2 rounded-lg transition-colors ${tool === 'eraser' ? 'bg-green-500 text-white' : 'hover:bg-gray-200'}`}
                  title="Eraser"
                >
                  <Eraser className="w-5 h-5" />
                </button>
              </div>

              <div className="h-8 w-px bg-gray-200" />

              <button onClick={undo} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Undo">
                <Undo className="w-5 h-5 text-gray-600" />
              </button>
              <button onClick={redo} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Redo">
                <Redo className="w-5 h-5 text-gray-600" />
              </button>
              <button onClick={reset} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Reset">
                <RotateCcw className="w-5 h-5 text-gray-600" />
              </button>

              <div className="h-8 w-px bg-gray-200" />

              <button onClick={downloadImage} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Download">
                <Download className="w-5 h-5 text-gray-600" />
              </button>

              <div className="flex-1" />

              {isContestMode && user && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={submitEntry}
                  className="px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-semibold rounded-lg flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  Submit Entry
                </motion.button>
              )}
            </div>

            {/* Canvas */}
            <div className="flex justify-center">
              <canvas
                ref={canvasRef}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="border-4 border-green-200 rounded-2xl cursor-crosshair touch-none max-w-full"
                style={{ width: '100%', maxWidth: '400px', aspectRatio: '1/1' }}
              />
            </div>
          </motion.div>

          {/* Tools Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            {/* Current Color */}
            <div className="bg-white rounded-2xl shadow-lg p-4">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-green-500" />
                Current Color
              </h3>
              <div
                className="w-full h-16 rounded-xl border-4 border-gray-200 shadow-inner"
                style={{ backgroundColor: tool === 'eraser' ? '#FFFFFF' : currentColor }}
              />
            </div>

            {/* Brush Size */}
            <div className="bg-white rounded-2xl shadow-lg p-4">
              <h3 className="font-bold text-gray-900 mb-3">Brush Size</h3>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setBrushSize(Math.max(4, brushSize - 4))}
                  className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <div className="flex-1 flex justify-center">
                  <div
                    className="rounded-full bg-gray-800"
                    style={{ width: brushSize, height: brushSize }}
                  />
                </div>
                <button
                  onClick={() => setBrushSize(Math.min(40, brushSize + 4))}
                  className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <div className="flex justify-center gap-2 mt-3">
                {brushSizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setBrushSize(size)}
                    className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      brushSize === size ? 'bg-green-100 border-2 border-green-500' : 'bg-gray-100'
                    }`}
                  >
                    <div
                      className="rounded-full bg-gray-800"
                      style={{ width: Math.min(size, 20), height: Math.min(size, 20) }}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Color Palette */}
            <div className="bg-white rounded-2xl shadow-lg p-4">
              <h3 className="font-bold text-gray-900 mb-3">Color Palette</h3>
              <div className="flex flex-wrap gap-1 mb-3">
                {(Object.keys(colorPalettes) as (keyof typeof colorPalettes)[]).map((palette) => (
                  <button
                    key={palette}
                    onClick={() => setActivePalette(palette)}
                    className={`px-3 py-1 text-xs rounded-full font-medium capitalize ${
                      activePalette === palette
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {palette}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-5 gap-2">
                {colorPalettes[activePalette].map((color) => (
                  <button
                    key={color}
                    onClick={() => {
                      setCurrentColor(color);
                      setTool('brush');
                    }}
                    className={`aspect-square rounded-xl transition-transform hover:scale-110 ${
                      currentColor === color && tool !== 'eraser' ? 'ring-4 ring-green-500 ring-offset-2' : ''
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            {/* Contest Info */}
            {isContestMode && (
              <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl shadow-lg p-4 text-white">
                <h3 className="font-bold mb-2 flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  Contest Mode
                </h3>
                <p className="text-white/80 text-sm mb-3">
                  Color the image before time runs out and submit your entry!
                </p>
                <div className="bg-white/20 rounded-xl p-3">
                  <p className="text-sm">Tips for higher scores:</p>
                  <ul className="text-xs text-white/80 mt-1 space-y-1">
                    <li>• Stay within the lines</li>
                    <li>• Use creative colors</li>
                    <li>• Complete all areas</li>
                  </ul>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>

      {/* Success Modal */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-md text-center shadow-2xl"
            >
              <motion.div
                animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="text-6xl mb-4"
              >
                🎉
              </motion.div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Amazing Work!</h2>
              <p className="text-gray-600 mb-4">
                {isContestMode
                  ? 'Your entry has been submitted to the contest!'
                  : 'You created a beautiful masterpiece!'}
              </p>
              <div className="flex items-center justify-center gap-2 mb-6">
                <Star className="w-6 h-6 text-yellow-500" />
                <span className="text-2xl font-bold text-green-600">+{score} XP</span>
              </div>
              <div className="flex gap-3 justify-center">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowSuccess(false)}
                  className="px-6 py-3 bg-gray-100 text-gray-700 font-semibold rounded-full flex items-center gap-2"
                >
                  <X className="w-4 h-4" />
                  Close
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => navigate('/contests')}
                  className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-semibold rounded-full flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  View Results
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
