import { motion } from 'framer-motion';
import { Palette, Trophy, Star, Users, ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AnimatedCard, MagneticButton, Floating, Shimmer, RippleButton } from '@/components/ui/animated-card';
import type { User } from '../App';

type HomePageProps = {
  user: User;
  onLoginClick: () => void;
  onNavigate: (page: string) => void;
};

const features = [
  {
    icon: Palette,
    title: 'Color Amazing Art',
    description: 'Hundreds of outlines from animals to superheroes!',
    color: 'from-green-500 to-emerald-500',
    emoji: '🎨'
  },
  {
    icon: Trophy,
    title: 'Weekly Contests',
    description: 'Compete with artists worldwide and win prizes!',
    color: 'from-yellow-500 to-orange-500',
    emoji: '🏆'
  },
  {
    icon: Star,
    title: 'Earn Badges',
    description: 'Level up and collect awesome achievements!',
    color: 'from-emerald-500 to-teal-500',
    emoji: '⭐'
  },
  {
    icon: Users,
    title: 'Join Community',
    description: 'Share your art and make friends!',
    color: 'from-teal-500 to-cyan-500',
    emoji: '👥'
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export function HomePage({ user, onLoginClick, onNavigate }: HomePageProps) {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative py-12 md:py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Floating duration={4} distance={5}>
                <Badge variant="secondary" className="mb-6 px-4 py-2 text-sm">
                  <Sparkles className="w-4 h-4 mr-2" />
                  #1 Kids Coloring Platform
                </Badge>
              </Floating>
              
              <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 leading-tight mb-6">
                Unleash Your{' '}
                <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent animate-gradient-shift bg-[length:200%_auto]">
                  Inner Artist
                </span>
                <br />
                <span className="text-3xl md:text-5xl">& Compete to Win! <motion.span 
                  className="inline-block" 
                  animate={{ rotate: [0, 14, -8, 14, -4, 10, 0] }}
                  transition={{ duration: 2.5, repeat: Infinity, repeatDelay: 1 }}
                >
                  🎨
                </motion.span></span>
              </h1>
              
              <p className="text-xl text-gray-600 mb-8">
                Join thousands of young artists in weekly coloring contests. Color beautiful outlines,
                earn badges, climb the leaderboard, and show the world your creativity!
              </p>
              
              <div className="flex flex-wrap gap-4">
                {user ? (
                  <MagneticButton onClick={() => onNavigate('contests')} className="px-8 py-4 text-lg">
                    Enter Contest <Trophy className="w-5 h-5" />
                  </MagneticButton>
                ) : (
                  <RippleButton onClick={onLoginClick} className="px-8 py-4 text-lg">
                    Start Coloring Free <ArrowRight className="w-5 h-5 inline ml-2" />
                  </RippleButton>
                )}
                <Button variant="outline" size="lg" className="px-8 py-4 text-lg h-auto" onClick={() => onNavigate('gallery')}>
                  <Palette className="w-5 h-5 mr-2" />
                  Browse Gallery
                </Button>
              </div>
            </motion.div>

            {/* Hero Illustration */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="relative w-full aspect-square max-w-lg mx-auto">
                {/* Decorative circles */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 20, ease: 'linear' }}
                  className="absolute inset-0 rounded-full border-4 border-dashed border-green-200"
                />
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ repeat: Infinity, duration: 15, ease: 'linear' }}
                  className="absolute inset-8 rounded-full border-4 border-dashed border-emerald-200"
                />
                <Shimmer className="absolute inset-16 rounded-full">
                  <div className="w-full h-full rounded-full bg-gradient-to-br from-green-400 via-emerald-500 to-teal-500 flex items-center justify-center shadow-2xl shadow-green-500/30">
                    <div className="text-center text-white">
                      <motion.div
                        animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                        transition={{ repeat: Infinity, duration: 2 }}
                      >
                        <Palette className="w-20 h-20 mx-auto mb-4" />
                      </motion.div>
                      <p className="text-xl font-bold">Color & Win!</p>
                    </div>
                  </div>
                </Shimmer>
                {/* Floating elements */}
                <Floating duration={4} distance={15}>
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: 15 }}
                    className="absolute top-4 right-4 w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center shadow-lg shadow-yellow-400/50 cursor-pointer text-3xl"
                  >
                    🌟
                  </motion.div>
                </Floating>
                <Floating duration={3} distance={12}>
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: -15 }}
                    className="absolute bottom-4 left-4 w-14 h-14 bg-emerald-400 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-400/50 cursor-pointer text-2xl"
                  >
                    🎨
                  </motion.div>
                </Floating>
                <Floating duration={5} distance={10}>
                  <motion.div
                    whileHover={{ scale: 1.3 }}
                    className="absolute top-1/2 left-0 w-12 h-12 bg-teal-400 rounded-full flex items-center justify-center shadow-lg shadow-teal-400/50 cursor-pointer text-xl"
                  >
                    ✨
                  </motion.div>
                </Floating>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Kids Love <span className="text-green-600">ColorArena</span>
            </h2>
            <p className="text-xl text-gray-600">Everything you need for an amazing coloring experience!</p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
          >
            {features.map((feature, index) => (
              <motion.div key={feature.title} variants={item}>
                <AnimatedCard 
                  hoverEffect="glow" 
                  delay={index * 0.1}
                  className="p-6 h-full"
                >
                  <motion.div 
                    className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-4 shadow-lg`}
                    whileHover={{ rotate: [0, -10, 10, -10, 0], scale: 1.1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <feature.icon className="w-7 h-7 text-white" />
                  </motion.div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                    {feature.title}
                    <span className="text-2xl">{feature.emoji}</span>
                  </h3>
                  <p className="text-gray-600">{feature.description}</p>
                </AnimatedCard>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent to-green-50">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <motion.h2 
              className="text-3xl md:text-5xl font-bold text-gray-900 mb-6"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Ready to Start Your <span className="text-green-600">Coloring Journey</span>?
            </motion.h2>
            <p className="text-xl text-gray-600 mb-8">
              Join young artists and start creating amazing art today!
            </p>
            
            <div className="flex flex-wrap justify-center gap-4">
              {!user ? (
                <MagneticButton onClick={onLoginClick} className="px-10 py-5 text-xl">
                  Join ColorArena - It's Free! 🎨
                </MagneticButton>
              ) : (
                <MagneticButton onClick={() => onNavigate('practice')} className="px-10 py-5 text-xl">
                  Start Practicing Now! 🎨
                </MagneticButton>
              )}
              <Button variant="outline" size="lg" className="px-8 py-5 text-lg h-auto" onClick={() => onNavigate('contests')}>
                <Trophy className="w-5 h-5 mr-2" />
                View Contests
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
