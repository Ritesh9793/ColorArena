import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Filter,
  ImageIcon,
  Grid3X3,
  List,
  LayoutGrid,
  Square,
  Maximize2
} from 'lucide-react';

type ViewMode = 'grid' | 'list' | 'small' | 'medium' | 'large';

type GalleryPageProps = {
  onNavigate: (page: string) => void;
};

export function GalleryPage({ onNavigate }: GalleryPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  const categories = ['All', 'Animals', 'Nature', 'Fantasy', 'Vehicles', 'Food', 'Space', 'Ocean', 'Holidays'];

  const viewOptions: { id: ViewMode; icon: typeof Grid3X3; label: string }[] = [
    { id: 'list', icon: List, label: 'List View' },
    { id: 'small', icon: Grid3X3, label: 'Small Icons' },
    { id: 'medium', icon: LayoutGrid, label: 'Medium Icons' },
    { id: 'large', icon: Maximize2, label: 'Large Icons' },
    { id: 'grid', icon: Square, label: 'Grid View' },
  ];

  const getGridClass = () => {
    switch (viewMode) {
      case 'list':
        return 'grid-cols-1';
      case 'small':
        return 'grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8';
      case 'medium':
        return 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5';
      case 'large':
        return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3';
      case 'grid':
      default:
        return 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Art <span className="text-green-600">Gallery</span> 🖼️
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explore amazing artworks created by our community
          </p>
        </motion.div>

        {/* Filters */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search gallery..."
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-green-400 transition-colors"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0">
            <Filter className="w-5 h-5 text-gray-400 flex-shrink-0" />
            {categories.map((category) => (
              <motion.button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  selectedCategory === category
                    ? 'bg-green-500 text-white shadow-md'
                    : 'bg-white text-gray-600 hover:bg-green-50 border border-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>

        {/* View Options Row */}
        <div className="flex items-center justify-end gap-4 mb-8">
          {/* View Options */}
          <div className="flex items-center gap-1 bg-white rounded-xl p-1 border border-gray-200">
            {viewOptions.map((option) => (
              <motion.button
                key={option.id}
                onClick={() => setViewMode(option.id)}
                className={`p-2 rounded-lg transition-all ${
                  viewMode === option.id
                    ? 'bg-green-500 text-white shadow-md'
                    : 'text-gray-500 hover:bg-gray-100'
                }`}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                title={option.label}
              >
                <option.icon className="w-5 h-5" />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Empty State */}
        <AnimatePresence mode="wait">
          <motion.div
            key="empty"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`grid ${getGridClass()} gap-4`}
          >
            <div className={`${viewMode === 'list' ? 'col-span-1' : 'col-span-full'}`}>
              <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                >
                  <ImageIcon className="w-20 h-20 text-gray-300 mx-auto mb-4" />
                </motion.div>
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No Artworks Yet</h3>
                <p className="text-gray-400 mb-6">Be the first to create and share your masterpiece!</p>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onNavigate('practice')}
                  className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl shadow-lg"
                >
                  Start Coloring
                </motion.button>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* View Mode Info */}
        <div className="mt-8 text-center text-sm text-gray-400">
          Currently viewing: <span className="font-medium text-gray-600">{viewOptions.find(v => v.id === viewMode)?.label}</span>
        </div>
      </div>
    </div>
  );
}
