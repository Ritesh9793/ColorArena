import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Trophy,
  Crown,
  Medal,
  Star,
  Grid3X3,
  List,
  LayoutGrid,
  Square,
  Maximize2,
  Users,
  Globe,
  MapPin,
  Calendar,
  Flame,
  Target,
  TrendingUp,
  ChevronDown,
  Search,
  Filter
} from 'lucide-react';
import { Select } from '../components/ui/Select';

type ViewMode = 'grid' | 'list' | 'small' | 'medium' | 'large';

interface User {
  name: string;
  email: string;
  avatar?: string;
  ageGroup: string;
  isAdmin?: boolean;
  country?: string;
  subscription?: {
    plan: 'free' | 'monthly' | 'quarterly' | 'halfYearly' | 'annual';
    startDate: Date;
    endDate: Date;
  };
}

interface LeaderboardPageProps {
  user: User | null;
}

// Country list with flags - using full names as codes for consistency with Settings
const countries = [
  { code: 'global', name: 'Global', flag: '🌍' },
  { code: 'United States', name: 'United States', flag: '🇺🇸' },
  { code: 'United Kingdom', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'Canada', name: 'Canada', flag: '🇨🇦' },
  { code: 'Australia', name: 'Australia', flag: '🇦🇺' },
  { code: 'Germany', name: 'Germany', flag: '🇩🇪' },
  { code: 'France', name: 'France', flag: '🇫🇷' },
  { code: 'India', name: 'India', flag: '🇮🇳' },
  { code: 'Japan', name: 'Japan', flag: '🇯🇵' },
  { code: 'Brazil', name: 'Brazil', flag: '🇧🇷' },
  { code: 'Mexico', name: 'Mexico', flag: '🇲🇽' },
  { code: 'Spain', name: 'Spain', flag: '🇪🇸' },
  { code: 'Italy', name: 'Italy', flag: '🇮🇹' },
  { code: 'South Korea', name: 'South Korea', flag: '🇰🇷' },
  { code: 'China', name: 'China', flag: '🇨🇳' },
  { code: 'Singapore', name: 'Singapore', flag: '🇸🇬' },
  { code: 'UAE', name: 'UAE', flag: '🇦🇪' },
  { code: 'South Africa', name: 'South Africa', flag: '🇿🇦' },
  { code: 'Nigeria', name: 'Nigeria', flag: '🇳🇬' },
  { code: 'Philippines', name: 'Philippines', flag: '🇵🇭' },
  { code: 'Netherlands', name: 'Netherlands', flag: '🇳🇱' },
  { code: 'Sweden', name: 'Sweden', flag: '🇸🇪' },
  { code: 'Norway', name: 'Norway', flag: '🇳🇴' },
  { code: 'Denmark', name: 'Denmark', flag: '🇩🇰' },
  { code: 'Finland', name: 'Finland', flag: '🇫🇮' },
  { code: 'Poland', name: 'Poland', flag: '🇵🇱' },
  { code: 'Malaysia', name: 'Malaysia', flag: '🇲🇾' },
  { code: 'Indonesia', name: 'Indonesia', flag: '🇮🇩' },
  { code: 'Thailand', name: 'Thailand', flag: '🇹🇭' },
  { code: 'Vietnam', name: 'Vietnam', flag: '🇻🇳' },
  { code: 'Egypt', name: 'Egypt', flag: '🇪🇬' },
  { code: 'Saudi Arabia', name: 'Saudi Arabia', flag: '🇸🇦' },
  { code: 'Turkey', name: 'Turkey', flag: '🇹🇷' },
  { code: 'Russia', name: 'Russia', flag: '🇷🇺' },
  { code: 'New Zealand', name: 'New Zealand', flag: '🇳🇿' },
  { code: 'Ireland', name: 'Ireland', flag: '🇮🇪' },
  { code: 'Belgium', name: 'Belgium', flag: '🇧🇪' },
  { code: 'Switzerland', name: 'Switzerland', flag: '🇨🇭' },
  { code: 'Austria', name: 'Austria', flag: '🇦🇹' },
  { code: 'Portugal', name: 'Portugal', flag: '🇵🇹' },
  { code: 'Greece', name: 'Greece', flag: '🇬🇷' },
  { code: 'Czech Republic', name: 'Czech Republic', flag: '🇨🇿' },
  { code: 'Argentina', name: 'Argentina', flag: '🇦🇷' },
  { code: 'Chile', name: 'Chile', flag: '🇨🇱' },
  { code: 'Colombia', name: 'Colombia', flag: '🇨🇴' },
  { code: 'Peru', name: 'Peru', flag: '🇵🇪' },
  { code: 'Venezuela', name: 'Venezuela', flag: '🇻🇪' },
  { code: 'Pakistan', name: 'Pakistan', flag: '🇵🇰' },
  { code: 'Bangladesh', name: 'Bangladesh', flag: '🇧🇩' },
  { code: 'Sri Lanka', name: 'Sri Lanka', flag: '🇱🇰' },
  { code: 'Nepal', name: 'Nepal', flag: '🇳🇵' },
  { code: 'Other', name: 'Other', flag: '🏳️' },
];

export function LeaderboardPage({ user }: LeaderboardPageProps) {
  const [rankingType, setRankingType] = useState('overall');
  const [timeFilter, setTimeFilter] = useState('week');
  const [ageFilter, setAgeFilter] = useState('all');
  const [countryFilter, setCountryFilter] = useState('global');
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [searchCountry, setSearchCountry] = useState('');

  // Ranking types
  const rankingTypes = [
    { id: 'overall', label: 'Overall', icon: Trophy, description: 'Combined ranking from all activities' },
    { id: 'contest', label: 'Contest', icon: Target, description: 'Rankings from contest wins' },
    { id: 'weekly', label: 'Weekly', icon: Calendar, description: 'This week\'s top performers' },
    { id: 'monthly', label: 'Monthly', icon: TrendingUp, description: 'This month\'s champions' },
    { id: 'annual', label: 'Annual', icon: Crown, description: 'Year-long achievement rankings' },
  ];

  const timeFilters = [
    { id: 'week', label: 'This Week' },
    { id: 'month', label: 'This Month' },
    { id: 'all', label: 'All Time' },
  ];

  const ageFilters = [
    { id: 'all', label: 'All Ages' },
    { id: '6-8', label: '6-8 Years' },
    { id: '9-12', label: '9-12 Years' },
    { id: '13-17', label: '13-17 Years' },
  ];

  const viewOptions: { id: ViewMode; icon: typeof Grid3X3; label: string }[] = [
    { id: 'list', icon: List, label: 'List View' },
    { id: 'small', icon: Grid3X3, label: 'Small Icons' },
    { id: 'medium', icon: LayoutGrid, label: 'Medium Icons' },
    { id: 'large', icon: Maximize2, label: 'Large Icons' },
    { id: 'grid', icon: Square, label: 'Grid View' },
  ];

  const getGridClass = () => {
    switch (viewMode) {
      case 'list':
        return 'grid-cols-1';
      case 'small':
        return 'grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8';
      case 'medium':
        return 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5';
      case 'large':
        return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3';
      case 'grid':
      default:
        return 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4';
    }
  };

  const selectedCountry = countries.find(c => c.code === countryFilter);
  const filteredCountries = countries.filter(c => 
    c.name.toLowerCase().includes(searchCountry.toLowerCase())
  );

  // Get user's country for "Your Rank" section - check both code and name for flexibility
  const userCountry = user?.country 
    ? countries.find(c => c.code === user.country || c.name === user.country) 
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            <span className="text-green-600">Leaderboard</span> 🏆
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            See who's topping the charts! Compete globally or in your country.
          </p>
        </motion.div>

        {/* Your Rank Card - Only show when logged in */}
        {user && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl p-6 mb-8 text-white shadow-xl"
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-2xl font-bold border-2 border-white/40">
                  {user.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
                  ) : (
                    user.name.charAt(0).toUpperCase()
                  )}
                </div>
                <div>
                  <h3 className="text-xl font-bold">{user.name}</h3>
                  <div className="flex items-center gap-2 text-green-100">
                    {userCountry ? (
                      <>
                        <span>{userCountry.flag}</span>
                        <span>{userCountry.name}</span>
                      </>
                    ) : (
                      <span className="text-yellow-200">⚠️ Set your country in Settings</span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-6 text-center">
                <div className="bg-white/10 rounded-xl px-6 py-3 backdrop-blur-sm">
                  <div className="flex items-center gap-2 justify-center mb-1">
                    <Globe className="w-4 h-4" />
                    <span className="text-sm text-green-100">Global Rank</span>
                  </div>
                  <p className="text-2xl font-bold">--</p>
                  <p className="text-xs text-green-200">Complete activities to rank</p>
                </div>
                <div className="bg-white/10 rounded-xl px-6 py-3 backdrop-blur-sm">
                  <div className="flex items-center gap-2 justify-center mb-1">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm text-green-100">Country Rank</span>
                  </div>
                  <p className="text-2xl font-bold">--</p>
                  <p className="text-xs text-green-200">{userCountry?.name || 'Set in Settings'}</p>
                </div>
                <div className="bg-white/10 rounded-xl px-6 py-3 backdrop-blur-sm">
                  <div className="flex items-center gap-2 justify-center mb-1">
                    <Flame className="w-4 h-4" />
                    <span className="text-sm text-green-100">Total XP</span>
                  </div>
                  <p className="text-2xl font-bold">0</p>
                  <p className="text-xs text-green-200">Keep coloring!</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Ranking Type Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-2 shadow-lg border border-gray-100 mb-6"
        >
          <div className="flex flex-wrap gap-2">
            {rankingTypes.map((type) => {
              const Icon = type.icon;
              return (
                <motion.button
                  key={type.id}
                  onClick={() => setRankingType(type.id)}
                  className={`flex-1 min-w-[120px] px-4 py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                    rankingType === type.id
                      ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Icon className="w-4 h-4" />
                  <span>{type.label}</span>
                </motion.button>
              );
            })}
          </div>
          <p className="text-center text-sm text-gray-500 mt-2">
            {rankingTypes.find(t => t.id === rankingType)?.description}
          </p>
        </motion.div>

        {/* Filters Row */}
        <div className="flex flex-wrap gap-4 mb-6 items-center justify-between">
          {/* Left Side - Country & Filters */}
          <div className="flex flex-wrap gap-4 items-center">
            {/* Country Filter Dropdown */}
            <div className="relative">
              <motion.button
                onClick={() => setShowCountryDropdown(!showCountryDropdown)}
                className="flex items-center gap-2 bg-white px-4 py-3 rounded-xl shadow-md border border-gray-200 hover:border-green-300 transition-all min-w-[200px]"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <span className="text-2xl">{selectedCountry?.flag}</span>
                <span className="font-medium text-gray-700">{selectedCountry?.name}</span>
                <ChevronDown className={`w-4 h-4 text-gray-400 ml-auto transition-transform ${showCountryDropdown ? 'rotate-180' : ''}`} />
              </motion.button>

              <AnimatePresence>
                {showCountryDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-full left-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-gray-200 z-50 overflow-hidden"
                  >
                    {/* Search */}
                    <div className="p-3 border-b border-gray-100">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                          type="text"
                          placeholder="Search countries..."
                          value={searchCountry}
                          onChange={(e) => setSearchCountry(e.target.value)}
                          className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                        />
                      </div>
                    </div>
                    
                    {/* Country List */}
                    <div className="max-h-60 overflow-y-auto">
                      {filteredCountries.map((country) => (
                        <motion.button
                          key={country.code}
                          onClick={() => {
                            setCountryFilter(country.code);
                            setShowCountryDropdown(false);
                            setSearchCountry('');
                          }}
                          className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-green-50 transition-colors ${
                            countryFilter === country.code ? 'bg-green-100' : ''
                          }`}
                          whileHover={{ x: 5 }}
                        >
                          <span className="text-2xl">{country.flag}</span>
                          <span className="font-medium text-gray-700">{country.name}</span>
                          {countryFilter === country.code && (
                            <span className="ml-auto text-green-600">✓</span>
                          )}
                        </motion.button>
                      ))}
                    </div>

                    {/* My Country Shortcut */}
                    {user?.country && userCountry && (
                      <div className="border-t border-gray-100 p-2">
                        <motion.button
                          onClick={() => {
                            setCountryFilter(userCountry.code);
                            setShowCountryDropdown(false);
                          }}
                          className="w-full flex items-center gap-2 px-4 py-2 bg-green-50 rounded-lg text-green-700 hover:bg-green-100 transition-colors"
                          whileHover={{ scale: 1.02 }}
                        >
                          <MapPin className="w-4 h-4" />
                          <span className="font-medium">My Country ({userCountry.name})</span>
                          <span className="ml-auto">{userCountry.flag}</span>
                        </motion.button>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Age Filter */}
            <Select
              value={ageFilter}
              onChange={setAgeFilter}
              options={ageFilters.map(f => ({ value: f.id, label: f.label }))}
              placeholder="Age Group"
            />
          </div>

          {/* Right Side - Time Filter & View Options */}
          <div className="flex flex-wrap gap-4 items-center">
            {/* Time Filter - Only show for certain ranking types */}
            {(rankingType === 'overall' || rankingType === 'contest') && (
              <div className="flex bg-white rounded-xl p-1 shadow-md border border-gray-100">
                {timeFilters.map((filter) => (
                  <motion.button
                    key={filter.id}
                    onClick={() => setTimeFilter(filter.id)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all text-sm ${
                      timeFilter === filter.id
                        ? 'bg-green-500 text-white shadow-md'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {filter.label}
                  </motion.button>
                ))}
              </div>
            )}

            {/* View Options */}
            <div className="flex items-center gap-2 bg-white rounded-xl p-1 border border-gray-200 shadow-sm">
              {viewOptions.map((option) => (
                <motion.button
                  key={option.id}
                  onClick={() => setViewMode(option.id)}
                  className={`p-2 rounded-lg transition-all ${
                    viewMode === option.id
                      ? 'bg-green-500 text-white shadow-md'
                      : 'text-gray-500 hover:bg-gray-100'
                  }`}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  title={option.label}
                >
                  <option.icon className="w-5 h-5" />
                </motion.button>
              ))}
            </div>
          </div>
        </div>

        {/* Current Filter Summary */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-wrap items-center gap-2 mb-6 text-sm"
        >
          <Filter className="w-4 h-4 text-gray-400" />
          <span className="text-gray-500">Showing:</span>
          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">
            {rankingTypes.find(t => t.id === rankingType)?.label}
          </span>
          <span className="text-gray-300">•</span>
          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-medium flex items-center gap-1">
            {selectedCountry?.flag} {selectedCountry?.name}
          </span>
          <span className="text-gray-300">•</span>
          <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-medium">
            {ageFilters.find(f => f.id === ageFilter)?.label}
          </span>
          {(rankingType === 'overall' || rankingType === 'contest') && (
            <>
              <span className="text-gray-300">•</span>
              <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full font-medium">
                {timeFilters.find(f => f.id === timeFilter)?.label}
              </span>
            </>
          )}
        </motion.div>

        {/* Top 3 Podium - Empty State */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center items-end gap-4 mb-12"
        >
          {/* 2nd Place */}
          <motion.div
            whileHover={{ y: -5 }}
            className="flex flex-col items-center"
          >
            <div className="w-24 h-24 md:w-32 md:h-32 bg-gradient-to-br from-gray-200 to-gray-300 rounded-full flex items-center justify-center mb-4 shadow-lg border-4 border-gray-300">
              <Medal className="w-12 h-12 text-gray-400" />
            </div>
            <div className="bg-gradient-to-br from-gray-400 to-gray-500 w-28 md:w-36 h-24 rounded-t-xl flex flex-col items-center justify-center text-white">
              <span className="text-3xl font-bold">2</span>
              <span className="text-sm opacity-80">Awaiting</span>
            </div>
          </motion.div>

          {/* 1st Place */}
          <motion.div
            whileHover={{ y: -5 }}
            className="flex flex-col items-center"
          >
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <Crown className="w-10 h-10 text-yellow-400 mb-2" />
            </motion.div>
            <div className="w-28 h-28 md:w-40 md:h-40 bg-gradient-to-br from-yellow-200 to-yellow-300 rounded-full flex items-center justify-center mb-4 shadow-xl border-4 border-yellow-400">
              <Trophy className="w-16 h-16 text-yellow-500" />
            </div>
            <div className="bg-gradient-to-br from-yellow-400 to-amber-500 w-32 md:w-44 h-32 rounded-t-xl flex flex-col items-center justify-center text-white shadow-lg">
              <span className="text-4xl font-bold">1</span>
              <span className="text-sm opacity-80">Champion</span>
            </div>
          </motion.div>

          {/* 3rd Place */}
          <motion.div
            whileHover={{ y: -5 }}
            className="flex flex-col items-center"
          >
            <div className="w-20 h-20 md:w-28 md:h-28 bg-gradient-to-br from-orange-200 to-orange-300 rounded-full flex items-center justify-center mb-4 shadow-lg border-4 border-orange-400">
              <Star className="w-10 h-10 text-orange-400" />
            </div>
            <div className="bg-gradient-to-br from-orange-400 to-orange-500 w-24 md:w-32 h-20 rounded-t-xl flex flex-col items-center justify-center text-white">
              <span className="text-2xl font-bold">3</span>
              <span className="text-sm opacity-80">Awaiting</span>
            </div>
          </motion.div>
        </motion.div>

        {/* Rankings List - Empty State */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`grid ${getGridClass()} gap-4`}
        >
          <div className={`${viewMode === 'list' ? 'col-span-1' : 'col-span-full'}`}>
            <div className="bg-white rounded-2xl p-12 shadow-lg text-center border border-gray-100">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ repeat: Infinity, duration: 2 }}
              >
                <Users className="w-20 h-20 text-gray-300 mx-auto mb-4" />
              </motion.div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No Rankings Yet</h3>
              <p className="text-gray-400 mb-4">
                {countryFilter === 'global' 
                  ? 'Complete coloring activities to appear on the global leaderboard!'
                  : `Be the first from ${selectedCountry?.name} to rank!`}
              </p>
              <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500">
                <div className="flex items-center gap-2 bg-green-50 px-4 py-2 rounded-full">
                  <Trophy className="w-4 h-4 text-green-500" />
                  <span>Win contests to earn XP</span>
                </div>
                <div className="flex items-center gap-2 bg-emerald-50 px-4 py-2 rounded-full">
                  <Star className="w-4 h-4 text-emerald-500" />
                  <span>Practice daily for bonus points</span>
                </div>
                <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-full">
                  <Globe className="w-4 h-4 text-blue-500" />
                  <span>Compete in your country</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* View Mode Info */}
        <div className="mt-8 text-center text-sm text-gray-400">
          Currently viewing: <span className="font-medium text-gray-600">{viewOptions.find(v => v.id === viewMode)?.label}</span>
        </div>
      </div>

      {/* Click outside to close country dropdown */}
      {showCountryDropdown && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowCountryDropdown(false)}
        />
      )}
    </div>
  );
}
