import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Filter,
  Clock,
  Palette,
  Sparkles,
  Play,
  Grid3X3,
  List,
  LayoutGrid,
  Square,
  Maximize2
} from 'lucide-react';

type ViewMode = 'grid' | 'list' | 'small' | 'medium' | 'large';

type PracticePageProps = {
  onNavigate: (page: string) => void;
};

export function PracticePage({ onNavigate }: PracticePageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  const categories = ['All', 'Animals', 'Nature', 'Fantasy', 'Vehicles', 'Food', 'Space', 'Ocean'];
  const difficulties = ['All', 'Easy', 'Medium', 'Hard'];

  const viewOptions: { id: ViewMode; icon: typeof Grid3X3; label: string }[] = [
    { id: 'list', icon: List, label: 'List View' },
    { id: 'small', icon: Grid3X3, label: 'Small Icons' },
    { id: 'medium', icon: LayoutGrid, label: 'Medium Icons' },
    { id: 'large', icon: Maximize2, label: 'Large Icons' },
    { id: 'grid', icon: Square, label: 'Grid View' },
  ];

  const getGridClass = () => {
    switch (viewMode) {
      case 'list':
        return 'grid-cols-1';
      case 'small':
        return 'grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8';
      case 'medium':
        return 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5';
      case 'large':
        return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3';
      case 'grid':
      default:
        return 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Practice <span className="text-green-600">Coloring</span> 🎨
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Improve your skills with our collection of outline artworks
          </p>
        </motion.div>

        {/* Daily Challenge Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl p-6 text-white"
        >
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                <Sparkles className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Daily Challenge</h2>
                <p className="text-white/80">Complete today's artwork for bonus XP!</p>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onNavigate('color')}
              className="px-6 py-3 bg-white text-green-600 font-bold rounded-xl shadow-lg flex items-center gap-2"
            >
              <Play className="w-5 h-5" />
              Start Challenge
            </motion.button>
          </div>
        </motion.div>

        {/* Filters and View Options */}
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search artworks..."
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-green-400 transition-colors"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0">
            <Filter className="w-5 h-5 text-gray-400 flex-shrink-0" />
            {categories.map((category) => (
              <motion.button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  selectedCategory === category
                    ? 'bg-green-500 text-white shadow-md'
                    : 'bg-white text-gray-600 hover:bg-green-50 border border-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Difficulty and View Options Row */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          {/* Difficulty Pills */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500 mr-2">Difficulty:</span>
            {difficulties.map((difficulty) => (
              <motion.button
                key={difficulty}
                onClick={() => setSelectedDifficulty(difficulty)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedDifficulty === difficulty
                    ? difficulty === 'Easy'
                      ? 'bg-green-100 text-green-700 border-2 border-green-400'
                      : difficulty === 'Medium'
                      ? 'bg-yellow-100 text-yellow-700 border-2 border-yellow-400'
                      : difficulty === 'Hard'
                      ? 'bg-red-100 text-red-700 border-2 border-red-400'
                      : 'bg-green-500 text-white'
                    : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {difficulty}
              </motion.button>
            ))}
          </div>

          {/* View Options */}
          <div className="flex items-center gap-1 bg-white rounded-xl p-1 border border-gray-200">
            {viewOptions.map((option) => (
              <motion.button
                key={option.id}
                onClick={() => setViewMode(option.id)}
                className={`p-2 rounded-lg transition-all ${
                  viewMode === option.id
                    ? 'bg-green-500 text-white shadow-md'
                    : 'text-gray-500 hover:bg-gray-100'
                }`}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                title={option.label}
              >
                <option.icon className="w-5 h-5" />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Empty State */}
        <AnimatePresence mode="wait">
          <motion.div
            key="empty"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`grid ${getGridClass()} gap-4`}
          >
            {/* Empty State Card */}
            <div className={`${viewMode === 'list' ? 'col-span-1' : 'col-span-full'}`}>
              <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                >
                  <Palette className="w-20 h-20 text-gray-300 mx-auto mb-4" />
                </motion.div>
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No Practice Artworks Yet</h3>
                <p className="text-gray-400 mb-6">Check back soon for new coloring activities!</p>
                <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>New artworks added daily</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* View Mode Info */}
        <div className="mt-8 text-center text-sm text-gray-400">
          Currently viewing: <span className="font-medium text-gray-600">{viewOptions.find(v => v.id === viewMode)?.label}</span>
        </div>
      </div>
    </div>
  );
}
