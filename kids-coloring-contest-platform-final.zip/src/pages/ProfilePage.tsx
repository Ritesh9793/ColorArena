import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Trophy, 
  Star, 
  Palette, 
  Calendar,
  Flame,
  ImageOff,
  Settings,
  Edit,
  Camera,
  Upload,
  X,
  Check,
  Trash2,
  Image as ImageIcon,
  Crown,
  Zap,
  Clock,
  ChevronRight,
  Gift,
  AlertTriangle,
  Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import type { User } from '../App';

type ProfilePageProps = {
  user: User;
  streakDays?: number;
  onNavigate?: (page: string) => void;
  onUpdateUser?: (updates: Partial<NonNullable<User>>) => void;
};

// Profile Picture Upload Modal
function ProfilePictureModal({ 
  isOpen, 
  onClose, 
  currentAvatar,
  userName,
  onSave 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  currentAvatar?: string;
  userName: string;
  onSave: (imageUrl: string) => void;
}) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentAvatar || null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewUrl(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    handleFileSelect(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  };

  const handleSave = async () => {
    if (!previewUrl) return;
    
    setIsUploading(true);
    // Simulate Cloudinary upload
    for (let i = 0; i <= 100; i += 10) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    onSave(previewUrl);
    setIsUploading(false);
    onClose();
  };

  const handleRemove = () => {
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-6 text-white">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <Camera className="w-6 h-6" />
                Update Profile Picture
              </h3>
              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Current/Preview Avatar */}
            <div className="flex justify-center mb-6">
              <div className="relative">
                <motion.div
                  animate={previewUrl ? { scale: [1, 1.05, 1] } : {}}
                  className="w-32 h-32 rounded-full overflow-hidden border-4 border-green-200 shadow-lg bg-gradient-to-br from-green-100 to-emerald-100"
                >
                  {previewUrl ? (
                    <img 
                      src={previewUrl} 
                      alt="Preview" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl font-bold text-green-500">
                      {userName[0]?.toUpperCase()}
                    </div>
                  )}
                </motion.div>
                {previewUrl && (
                  <motion.button
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={handleRemove}
                    className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center shadow-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </motion.button>
                )}
              </div>
            </div>

            {/* Upload Area */}
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
                isDragging 
                  ? 'border-green-500 bg-green-50' 
                  : 'border-gray-300 hover:border-green-400 hover:bg-green-50/50'
              }`}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleInputChange}
                className="hidden"
              />
              
              <motion.div
                animate={isDragging ? { scale: 1.1 } : { scale: 1 }}
                className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
              >
                <Upload className={`w-8 h-8 ${isDragging ? 'text-green-600' : 'text-green-500'}`} />
              </motion.div>
              
              <p className="text-gray-700 font-medium mb-1">
                {isDragging ? 'Drop your image here!' : 'Drag & drop your image here'}
              </p>
              <p className="text-gray-500 text-sm mb-4">or click to browse</p>
              
              <div className="flex items-center justify-center gap-2 text-xs text-gray-400">
                <ImageIcon className="w-4 h-4" />
                <span>PNG, JPG, GIF up to 5MB</span>
              </div>
            </div>

            {/* Upload Progress */}
            {isUploading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4"
              >
                <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                  <span>Uploading to Cloudinary...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${uploadProgress}%` }}
                    className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
                  />
                </div>
              </motion.div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 mt-6">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onClose}
                className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-xl font-medium text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSave}
                disabled={!previewUrl || isUploading}
                className={`flex-1 px-4 py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors ${
                  previewUrl && !isUploading
                    ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                }`}
              >
                {isUploading ? (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                    />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Check className="w-5 h-5" />
                    Save Photo
                  </>
                )}
              </motion.button>
            </div>

            {/* Cloudinary Note */}
            <p className="text-center text-xs text-gray-400 mt-4">
              📸 Images are securely stored via Cloudinary
            </p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// Subscription Card Component
function SubscriptionCard({ 
  user, 
  onNavigate 
}: { 
  user: NonNullable<User>;
  onNavigate?: (page: string) => void;
}) {
  const subscription = user.subscription;
  const plan = subscription?.plan || 'free';
  const isFreeTrial = plan === 'free';
  
  // Calculate days remaining
  let daysRemaining = 14;
  let isExpired = false;
  
  if (subscription?.endDate) {
    const now = new Date();
    const end = new Date(subscription.endDate);
    daysRemaining = Math.max(0, Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
    isExpired = daysRemaining === 0;
  }

  const planDetails: Record<string, { name: string; icon: typeof Crown; color: string; bgColor: string }> = {
    free: { name: 'Free Trial', icon: Gift, color: 'text-gray-600', bgColor: 'from-gray-100 to-gray-200' },
    monthly: { name: 'Monthly', icon: Zap, color: 'text-green-600', bgColor: 'from-green-100 to-green-200' },
    quarterly: { name: 'Quarterly', icon: Star, color: 'text-emerald-600', bgColor: 'from-emerald-100 to-emerald-200' },
    halfYearly: { name: 'Half-Yearly', icon: Trophy, color: 'text-teal-600', bgColor: 'from-teal-100 to-teal-200' },
    annual: { name: 'Annual', icon: Crown, color: 'text-yellow-600', bgColor: 'from-yellow-100 to-yellow-200' },
  };

  const currentPlan = planDetails[plan] || planDetails.free;
  const PlanIcon = currentPlan.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl shadow-lg overflow-hidden"
    >
      {/* Header */}
      <div className={`bg-gradient-to-r ${currentPlan.bgColor} p-6`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-3 bg-white rounded-xl shadow-md`}>
              <PlanIcon className={`w-6 h-6 ${currentPlan.color}`} />
            </div>
            <div>
              <p className="text-sm text-gray-600">Current Plan</p>
              <h3 className="text-xl font-bold text-gray-800">{currentPlan.name}</h3>
            </div>
          </div>
          {!isFreeTrial && (
            <Badge className="bg-white/80 text-green-700">Active</Badge>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Days Remaining / Expiry Warning */}
        {isFreeTrial && (
          <div className={`p-4 rounded-xl mb-4 ${
            isExpired 
              ? 'bg-red-50 border border-red-200' 
              : daysRemaining <= 3 
              ? 'bg-amber-50 border border-amber-200' 
              : 'bg-green-50 border border-green-200'
          }`}>
            <div className="flex items-center gap-3">
              {isExpired ? (
                <>
                  <Lock className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="font-semibold text-red-700">Trial Expired</p>
                    <p className="text-sm text-red-600">Upgrade to access premium content</p>
                  </div>
                </>
              ) : daysRemaining <= 3 ? (
                <>
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                  <div>
                    <p className="font-semibold text-amber-700">Trial Ending Soon!</p>
                    <p className="text-sm text-amber-600">{daysRemaining} day{daysRemaining !== 1 ? 's' : ''} remaining</p>
                  </div>
                </>
              ) : (
                <>
                  <Clock className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="font-semibold text-green-700">Free Trial Active</p>
                    <p className="text-sm text-green-600">{daysRemaining} days remaining</p>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {/* Plan Benefits */}
        <div className="space-y-2 mb-6">
          <p className="text-sm font-medium text-gray-700 mb-3">Your Benefits:</p>
          {isFreeTrial || isExpired ? (
            <>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Check className="w-4 h-4 text-green-500" />
                <span>Access to free tier practices</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Check className="w-4 h-4 text-green-500" />
                <span>5 coloring pages per day</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <X className="w-4 h-4 text-gray-300" />
                <span>Premium practices (Locked)</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <X className="w-4 h-4 text-gray-300" />
                <span>Contest participation (Locked)</span>
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Check className="w-4 h-4 text-green-500" />
                <span>Unlimited practices</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Check className="w-4 h-4 text-green-500" />
                <span>Premium color palettes</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Check className="w-4 h-4 text-green-500" />
                <span>Contest participation</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Check className="w-4 h-4 text-green-500" />
                <span>Ad-free experience</span>
              </div>
            </>
          )}
        </div>

        {/* Renewal Info or Upgrade CTA */}
        {!isFreeTrial && subscription?.endDate && (
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
            <Calendar className="w-4 h-4" />
            <span>Renews on {new Date(subscription.endDate).toLocaleDateString()}</span>
          </div>
        )}

        {/* Upgrade Button */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onNavigate?.('subscription')}
          className={`w-full py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${
            isFreeTrial || isExpired
              ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg hover:shadow-xl'
              : 'border-2 border-green-200 text-green-600 hover:bg-green-50'
          }`}
        >
          {isFreeTrial || isExpired ? (
            <>
              <Crown className="w-5 h-5" />
              Upgrade to Premium
            </>
          ) : (
            <>
              Manage Subscription
              <ChevronRight className="w-5 h-5" />
            </>
          )}
        </motion.button>
      </div>
    </motion.div>
  );
}

// Streak Calendar Component
function StreakCalendar({ streakDays }: { streakDays: number }) {
  const weeks = 52;
  const daysPerWeek = 7;
  const today = new Date();
  
  // Generate empty calendar data
  const calendarData: { date: Date; active: boolean }[] = [];
  
  for (let i = weeks * daysPerWeek - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    // Only mark recent days as active based on streak
    const daysAgo = i;
    const active = daysAgo < streakDays;
    calendarData.push({ date, active });
  }
  
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const dayLabels = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl shadow-lg p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <Flame className="w-6 h-6 text-orange-500" />
          Activity Streak
        </h3>
        <Badge variant="secondary" className="text-lg px-4 py-2">
          🔥 {streakDays} Day{streakDays !== 1 ? 's' : ''}
        </Badge>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center p-4 bg-orange-50 rounded-xl">
          <p className="text-2xl font-bold text-orange-600">{streakDays}</p>
          <p className="text-sm text-gray-600">Current Streak</p>
        </div>
        <div className="text-center p-4 bg-green-50 rounded-xl">
          <p className="text-2xl font-bold text-green-600">{streakDays}</p>
          <p className="text-sm text-gray-600">Longest Streak</p>
        </div>
        <div className="text-center p-4 bg-emerald-50 rounded-xl">
          <p className="text-2xl font-bold text-emerald-600">{streakDays}</p>
          <p className="text-sm text-gray-600">Active Days</p>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="overflow-x-auto">
        <div className="min-w-[800px]">
          {/* Month Labels */}
          <div className="flex mb-2 pl-8">
            {months.map((month, i) => (
              <div key={i} className="flex-1 text-xs text-gray-400">{month}</div>
            ))}
          </div>
          
          {/* Calendar */}
          <div className="flex">
            {/* Day Labels */}
            <div className="flex flex-col gap-[3px] pr-2">
              {dayLabels.map((day, i) => (
                <div key={i} className="w-4 h-4 text-xs text-gray-400 flex items-center justify-center">
                  {i % 2 === 1 ? day : ''}
                </div>
              ))}
            </div>
            
            {/* Weeks */}
            <div className="flex gap-[3px]">
              {Array.from({ length: weeks }).map((_, weekIndex) => (
                <div key={weekIndex} className="flex flex-col gap-[3px]">
                  {Array.from({ length: daysPerWeek }).map((_, dayIndex) => {
                    const dataIndex = weekIndex * daysPerWeek + dayIndex;
                    const data = calendarData[dataIndex];
                    
                    if (!data) return <div key={dayIndex} className="w-4 h-4" />;
                    
                    return (
                      <motion.div
                        key={dayIndex}
                        whileHover={{ scale: 1.5 }}
                        className={`w-4 h-4 rounded-sm cursor-pointer transition-colors ${
                          data.active
                            ? 'bg-green-500'
                            : 'bg-gray-100 hover:bg-gray-200'
                        }`}
                        title={`${data.date.toLocaleDateString()}`}
                      />
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
          
          {/* Legend */}
          <div className="flex items-center justify-end gap-2 mt-4 text-xs text-gray-500">
            <span>Less</span>
            <div className="w-4 h-4 rounded-sm bg-gray-100" />
            <div className="w-4 h-4 rounded-sm bg-green-200" />
            <div className="w-4 h-4 rounded-sm bg-green-400" />
            <div className="w-4 h-4 rounded-sm bg-green-500" />
            <div className="w-4 h-4 rounded-sm bg-green-700" />
            <span>More</span>
          </div>
        </div>
      </div>

      {/* Streak Message */}
      <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl text-center">
        {streakDays >= 7 ? (
          <p className="text-green-700 font-medium">
            🔥 Amazing! You're on fire! Keep the streak going!
          </p>
        ) : streakDays >= 3 ? (
          <p className="text-green-700 font-medium">
            💪 Great job! Keep the momentum going!
          </p>
        ) : (
          <p className="text-green-700 font-medium">
            🎨 Color something today to build your streak!
          </p>
        )}
      </div>
    </motion.div>
  );
}

export function ProfilePage({ user, streakDays: propStreakDays, onNavigate, onUpdateUser }: ProfilePageProps) {
  const streakDays = propStreakDays ?? 0;
  const [showAvatarModal, setShowAvatarModal] = useState(false);

  const handleAvatarSave = (imageUrl: string) => {
    onUpdateUser?.({ avatar: imageUrl });
  };
  
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Star className="w-12 h-12 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Please Sign In</h2>
          <p className="text-gray-500 mb-6">Sign in to view your profile and track your progress</p>
          <Button size="lg">Sign In</Button>
        </motion.div>
      </div>
    );
  }

  // streakDays comes from props

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-3xl p-8 mb-8 text-white relative overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-4 text-6xl">🎨</div>
            <div className="absolute bottom-4 right-4 text-6xl">✨</div>
          </div>

          <div className="relative flex flex-col md:flex-row items-center gap-6">
            {/* Avatar */}
            <motion.div
              whileHover={{ scale: 1.1, rotate: 5 }}
              className="relative"
            >
              <Avatar className="w-28 h-28 border-4 border-white shadow-xl">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="text-3xl bg-green-600">{user.name[0]}</AvatarFallback>
              </Avatar>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowAvatarModal(true)}
                className="absolute bottom-0 right-0 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg cursor-pointer"
              >
                <Edit className="w-5 h-5 text-green-600" />
              </motion.button>
            </motion.div>

            {/* User Info */}
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
              <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                <Badge className="bg-white/20 text-white">
                  Level {user.level}
                </Badge>
                <Badge className="bg-orange-500/80 text-white">
                  🔥 {streakDays} Day Streak
                </Badge>
              </div>
              
              {/* XP Progress */}
              <div className="max-w-md">
                <div className="flex justify-between text-sm mb-2">
                  <span>{user.xp} XP</span>
                  <span>1000 XP</span>
                </div>
                <Progress value={(user.xp / 1000) * 100} className="h-3 bg-white/20" />
                <p className="text-sm mt-1 text-white/80">{1000 - user.xp} XP to Level {user.level + 1}</p>
              </div>
            </div>

            {/* Settings Button */}
            <motion.button
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => onNavigate?.('settings')}
              className="absolute top-4 right-4 w-10 h-10 bg-white/20 rounded-full flex items-center justify-center cursor-pointer"
            >
              <Settings className="w-5 h-5" />
            </motion.button>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          {[
            { icon: Star, label: 'Total XP', value: user.xp, color: 'from-yellow-400 to-orange-500' },
            { icon: Palette, label: 'Artworks', value: 0, color: 'from-green-400 to-emerald-500' },
            { icon: Trophy, label: 'Contests', value: 0, color: 'from-emerald-400 to-teal-500' },
            { icon: Calendar, label: 'Days Active', value: streakDays, color: 'from-teal-400 to-cyan-500' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-white rounded-xl p-6 shadow-lg text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.05 }}
            >
              <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Subscription & Streak Row */}
        <div className={`grid grid-cols-1 ${!user.isAdmin ? 'lg:grid-cols-3' : ''} gap-8 mb-8`}>
          {/* Subscription Card - Hidden for Admin */}
          {!user.isAdmin && (
            <div className="lg:col-span-1">
              <SubscriptionCard user={user} onNavigate={onNavigate} />
            </div>
          )}
          
          {/* Streak Calendar */}
          <div className={!user.isAdmin ? 'lg:col-span-2' : ''}>
            <StreakCalendar streakDays={streakDays} />
          </div>
        </div>

        {/* Recent Artworks - Empty State */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl shadow-lg p-6"
        >
          <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <Palette className="w-6 h-6 text-green-500" />
            Recent Artworks
          </h3>

          <div className="flex flex-col items-center justify-center py-12 text-center">
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ duration: 3, repeat: Infinity }}
              className="w-24 h-24 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full flex items-center justify-center mb-4"
            >
              <ImageOff className="w-12 h-12 text-green-400" />
            </motion.div>
            
            <h4 className="text-lg font-bold text-gray-900 mb-2">
              No Artworks Yet
            </h4>
            <p className="text-gray-500 mb-4 max-w-sm">
              Start coloring to see your creations here!
            </p>
            <Button className="gap-2">
              <Palette className="w-5 h-5" />
              Start Coloring
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Profile Picture Upload Modal */}
      <ProfilePictureModal
        isOpen={showAvatarModal}
        onClose={() => setShowAvatarModal(false)}
        currentAvatar={user.avatar}
        userName={user.name}
        onSave={handleAvatarSave}
      />
    </div>
  );
}
