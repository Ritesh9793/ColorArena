import { useState } from 'react';
import { Header } from './components/Header';
import Footer from './components/Footer';
import { HomePage } from './pages/HomePage';
import { GalleryPage } from './pages/GalleryPage';
import { ContestPage } from './pages/ContestPage';
import { ColoringPage } from './pages/ColoringPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { ProfilePage } from './pages/ProfilePage';
import { PracticePage } from './pages/PracticePage';
import { AdminPage } from './pages/AdminPage';
import SettingsPage from './pages/SettingsPage';
import SubscriptionPage from './pages/SubscriptionPage';
import AuthPage from './components/AuthPage';
import { Notification } from './components/NotificationDropdown';

export type Subscription = {
  plan: 'free' | 'monthly' | 'quarterly' | 'halfYearly' | 'annual';
  startDate: Date;
  endDate: Date;
  trialEndsAt?: Date;
};

export type User = {
  id: string;
  name: string;
  avatar: string;
  level: number;
  xp: number;
  badges: string[];
  isAdmin: boolean;
  subscription?: Subscription;
  country?: string;
  ageGroup?: string;
} | null;

export function App() {
  const [user, setUser] = useState<User>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [streakDays, setStreakDays] = useState(0);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const handleLogin = (name: string, isAdmin: boolean = false, country?: string, ageGroup?: string) => {
    if (isAdmin) {
      setUser({
        id: 'admin-1',
        name,
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=admin',
        level: 99,
        xp: 99999,
        badges: ['admin', 'moderator', 'creator'],
        isAdmin: true,
        subscription: undefined,
        country: undefined,
        ageGroup: undefined
      });
      // Admin starts with no notifications - real notifications come from backend
      setNotifications([]);
    } else {
      const trialStart = new Date();
      const trialEnd = new Date();
      trialEnd.setDate(trialEnd.getDate() + 14);
      
      setUser({
        id: '1',
        name,
        avatar: `https://api.dicebear.com/7.x/fun-emoji/svg?seed=${name}`,
        level: 1,
        xp: 0,
        badges: ['newcomer'],
        isAdmin: false,
        subscription: {
          plan: 'free',
          startDate: trialStart,
          endDate: trialEnd,
          trialEndsAt: trialEnd
        },
        country: country || 'United States',
        ageGroup: ageGroup || '9-12'
      });
      // User starts with no notifications - real notifications come from backend
      setNotifications([]);
      // Streak starts at 0 - real streak data comes from backend
      setStreakDays(0);
    }
    setShowAuthModal(false);
    if (isAdmin) {
      setCurrentPage('admin');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage('home');
    setNotifications([]);
  };

  const handleMarkNotificationAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const handleMarkAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
  };

  const handleNotificationClick = (notification: Notification) => {
    switch (notification.type) {
      case 'contest':
        setCurrentPage('contests');
        break;
      case 'activity':
        setCurrentPage('practice');
        break;
      case 'achievement':
      case 'streak':
        setCurrentPage('profile');
        break;
      case 'subscription':
        setCurrentPage('subscription');
        break;
      case 'user':
      case 'moderation':
        setCurrentPage('admin');
        break;
      default:
        break;
    }
  };

  const handleUpdateUser = (updates: Partial<NonNullable<User>>) => {
    if (user) {
      setUser({ ...user, ...updates });
    }
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage user={user} onLoginClick={() => setShowAuthModal(true)} onNavigate={handleNavigate} />;
      case 'practice':
        return <PracticePage onNavigate={handleNavigate} />;
      case 'gallery':
        return <GalleryPage onNavigate={handleNavigate} />;
      case 'contests':
        return <ContestPage />;
      case 'color':
        return <ColoringPage user={user} />;
      case 'leaderboard':
        return <LeaderboardPage user={user ? { name: user.name, email: '', avatar: user.avatar, ageGroup: user.ageGroup || '9-12', country: user.country } : null} />;
      case 'profile':
        return <ProfilePage user={user} streakDays={streakDays} onNavigate={handleNavigate} onUpdateUser={handleUpdateUser} />;
      case 'settings':
        return <SettingsPage user={user ? { name: user.name, email: `${user.name.toLowerCase().replace(' ', '')}@example.com`, isAdmin: user.isAdmin, age: 14, country: user.country, avatar: user.avatar } : null} onNavigate={handleNavigate} onLogout={handleLogout} onUpdateUser={handleUpdateUser} />;
      case 'subscription':
        // Don't show subscription page for admin
        if (user?.isAdmin) {
          return <AdminPage />;
        }
        return <SubscriptionPage user={user} onNavigate={handleNavigate} onUpdateUser={handleUpdateUser} />;
      case 'admin':
        return user?.isAdmin ? <AdminPage /> : <HomePage user={user} onLoginClick={() => setShowAuthModal(true)} onNavigate={handleNavigate} />;
      default:
        return <HomePage user={user} onLoginClick={() => setShowAuthModal(true)} onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 flex flex-col">
      <Header 
        currentPage={currentPage}
        onNavigate={handleNavigate}
        user={user ? user.name : null}
        isAdmin={user?.isAdmin}
        onLoginClick={() => setShowAuthModal(true)} 
        onLogout={handleLogout}
        streakDays={user && !user.isAdmin ? streakDays : 0}
        notifications={notifications}
        onMarkNotificationAsRead={handleMarkNotificationAsRead}
        onMarkAllNotificationsAsRead={handleMarkAllNotificationsAsRead}
        onClearAllNotifications={handleClearAllNotifications}
        onNotificationClick={handleNotificationClick}
      />
      <main className="flex-1">
        {renderPage()}
      </main>
      {!user && <Footer />}
      {showAuthModal && (
        <AuthPage 
          onClose={() => setShowAuthModal(false)} 
          onLogin={(userData) => handleLogin(userData.name, userData.isAdmin || false, userData.country, userData.ageGroup)}
        />
      )}
    </div>
  );
}
